# @storywithoutend/effect-ens

This package tests Effect implementations behind Promise-native APIs. `makeEnsClient` reads ownership and runs resumable second-level `.eth` registration and renewal workflows. The separate `makeEnsSubgraphClient` exposes `getSubgraphRecords`, `getNamesForAddress`, `getNameHistory`, `getRecordHistory`, and `getSubnames`.

The root export is Promise-native and contains no Effect types. The Effect-free `/chain` compatibility entry exposes the ENSjs 5.2.1 L1 metadata and helpers required by applications. `/public` provides resolver reads, batched records, ERC-165 interface detection, availability, renewal eligibility, and registrar pricing through Effect-native services. `/public/v1` provides legacy ownership, expiry, NameWrapper data, and direct reverse-record reads. `/public/v2` provides the eight V2 reads required by Portal: token ID, resource, subregistry, expiry, registry ancestry, exact owner, role checks, and account roles. The `/utils` compatibility entry provides name, content-hash, and V1 fuse helpers. `/utils/v2` provides registry and resolver roles, scoped resolver resources and calldata, canonical label IDs, and DNS name encoding. The Effect services and Layers remain available from `@storywithoutend/effect-ens/effect` for advanced composition. `EnsSubgraph` is the Effect service for the five subgraph operations. Pure protocol helpers, scripted Layers, and checkpoint internals remain under `@storywithoutend/effect-ens/testing`.

The required gate runs entirely offline and requires Node.js `^22.18.0 || >=24.11.0`, pnpm 11.3.0, and Anvil 1.8.1 on `PATH`.

```sh
pnpm verify        # required gate, packed-package smoke, and Anvil integration
pnpm pack:smoke    # rebuild, pack, install, and exercise an isolated consumer
pnpm mutation:dry  # validate the frozen historical mutation harness
pnpm mutation      # optional historical baseline plus report validation
pnpm mutation:subgraph:dry  # validate the separate subgraph harness
pnpm mutation:public-v2:dry # validate the separate public V2 harness
pnpm evidence      # required gate followed by the historical mutation baseline
```

## Subgraph fake benchmark

```sh
pnpm bench:fakes
pnpm bench:fakes:check
```

`pnpm bench:fakes` cleans, rebuilds, and prints one JSON report. It measures 100,000 pure planner and parser cases, 10,000 Effect runtime calls, and 1,000 Promise client calls against fake subgraph responses. `pnpm bench:fakes:check` runs that command and checks the report shape and counts.

The rates are local observations, not pass or fail thresholds. Each tier warms one untimed three-operation rotation first. Warmup calls do not count toward the reported totals.

## Promise API

`makeEnsClient` keeps its three transaction and ownership methods. Create a separate `makeEnsSubgraphClient` for the five subgraph operations. Both clients reject expected failures with `EnsError`.

```ts
import { makeEnsSubgraphClient } from "@storywithoutend/effect-ens";

const subgraph = makeEnsSubgraphClient({ url: "https://example.test/subgraph" });
const records = await subgraph.getSubgraphRecords({ name: "ens.eth" });
const names = await subgraph.getNamesForAddress({ address, pageSize: 100 });
const history = await subgraph.getNameHistory({ name: "ens.eth", orderDirection: "desc" });
const textHistory = await subgraph.getRecordHistory({ name: "ens.eth", key: "texts" });
const subnames = await subgraph.getSubnames({ name: "ens.eth", pageSize: 100 });
```

The client posts controlled GraphQL documents through the raw HTTP transport. It does not import ENSjs in production. `getNamesForAddress` applies expiry policy from the Effect clock; name history preserves the ENSjs 5.2.1 domain, registration, and current-resolver event sets; record history selects and decodes one resolver-record family.

For incremental ENSjs migration, `/subgraph` preserves the client-first Promise call shape used by ENSjs 5.2.1 while delegating to the same Effect implementation:

```ts
import { getSubnames } from "@storywithoutend/effect-ens/subgraph";

const subnames = await getSubnames(publicClient, { name: "ens.eth" });
```

It intentionally does not expose ENSjs's generic `createSubgraphClient`; application-owned GraphQL documents stay with the application's indexer client.

The `/chain` entry preserves ENSjs's static supported-chain metadata, ENS contract-address lookup, and `extendChainWithEns` behavior without importing ENSjs in production:

```ts
import {
  extendChainWithEns,
  getChainContractAddress,
} from "@storywithoutend/effect-ens/chain";
import { sepolia } from "viem/chains";

const chain = extendChainWithEns(sepolia);
const registry = getChainContractAddress({ chain, contract: "ensRegistry" });
```

Pure helpers are available from `/utils` and `/utils/v2`:

```ts
import { getNameType, normalize } from "@storywithoutend/effect-ens/utils";
import { encodeRoleBitmap, registryRoles } from "@storywithoutend/effect-ens/utils/v2";

const name = normalize("ALICE.eth");
const type = getNameType(name);
const roles = encodeRoleBitmap(["ROLE_REGISTRAR", "ROLE_RENEW"]);
const canRenew = (roles & registryRoles.ROLE_RENEW) !== 0n;
```

Public reads keep ENSjs's client-first Promise signatures:

```ts
import { getAddressRecord, getName, getRecords, getResolver } from "@storywithoutend/effect-ens/public";

const resolver = await getResolver(publicClient, { name: "alice.eth" });
const primary = await getName(publicClient, { address });
const ethAddress = await getAddressRecord(publicClient, { name: "alice.eth" });
const records = await getRecords(publicClient, {
  name: "alice.eth",
  texts: ["avatar", "description"],
  coins: [60],
});
```

V2 registry reads use the same client-first convention:

```ts
import { getResource, getTokenId, hasRoles } from "@storywithoutend/effect-ens/public/v2";

const tokenId = await getTokenId(publicClient, { label: "alice", registryAddress });
const resource = await getResource(publicClient, { label: "alice", registryAddress });
const canRenew = await hasRoles(publicClient, {
  registryAddress,
  label: "alice",
  roles: ["ROLE_RENEW"],
  account,
});
```

```ts
import { EnsError, makeEnsClient } from "@storywithoutend/effect-ens";

const ens = makeEnsClient({
  deployment,
  publicClient,
  sendTransaction: (intent) => walletClient.sendTransaction({ account, ...intent }),
});

const owner = await ens.getOwner({ name: "alice.eth" });
const registration = await ens.registerEth2ld({
  id: "registration-018f4d88",
  name: "alice.eth",
  owner: account.address,
  durationSeconds: 31_536_000n,
  payment: { kind: "buffered", basisPoints: 500, maximumWei: 200_000_000_000_000_000n },
});
const renewal = await ens.renewEth2ld({
  id: "renewal-018f4d88",
  name: "alice.eth",
  durationSeconds: 31_536_000n,
  payment: { kind: "exact", maximumWei: 200_000_000_000_000_000n },
});
```

The default checkpoint store is in memory and belongs to the returned client. Reuse the client for replay safety. Supply a `CheckpointStore` for durable state.

Expected failures reject with `EnsError`. It carries `code`, the complete tagged `failure`, a human-readable `message`, a stack, a plain-text Effect diagnostic, and an underlying JavaScript `cause` when the RPC or store supplied one. Unexpected defects remain ordinary `Error` or `AggregateError` values.

```ts
try {
  await ens.registerEth2ld(request);
} catch (error) {
  if (error instanceof EnsError && error.code === "PriceError") {
    console.error(error.failure.quotedWei, error.failure.maximumWei);
  }
}
```

The reader sends one Multicall3 request pinned to one block number.

## Effect API

### Register a name

```ts
import { Effect, Layer } from "effect";
import {
  EnsRegistration,
  EntropyLive,
  makeEnsRegistrationLayer,
  makeInMemoryRegistrationStoreLayer,
  makeViemRawEvmLayer,
  makeViemWalletLayer,
} from "@storywithoutend/effect-ens/effect";

const RegistrationLive = makeEnsRegistrationLayer(deployment).pipe(
  Layer.provide(
    Layer.mergeAll(
      EntropyLive,
      makeViemRawEvmLayer(publicClient),
      makeViemWalletLayer({
        sendTransaction: (intent) => walletClient.sendTransaction({ account, ...intent }),
      }),
      makeInMemoryRegistrationStoreLayer(),
    ),
  ),
);

const result = await Effect.runPromise(
  EnsRegistration.use((ens) =>
    ens.registerEth2ld({
      id: "registration-018f4d88",
      name: "alice.eth",
      owner: account.address,
      durationSeconds: 31_536_000n,
      payment: { kind: "buffered", basisPoints: 500, maximumWei: 200_000_000_000_000_000n },
    }),
  ).pipe(Effect.provide(RegistrationLive)),
);
```

Reuse the returned store Layer for every call with an operation ID. Its state survives separate `Effect.runPromise` calls in one process. The in-memory store does not survive a process restart.

### Renew a name

`EnsRenewal.renewEth2ld` quotes at a pinned block, enforces the payment ceiling, submits one renewal, waits for its receipt, and replays a completed operation without another wallet write.

```ts
import {
  EnsRenewal,
  makeEnsRenewalLayer,
  makeInMemoryRegistrationStoreLayer,
  makeViemRawEvmLayer,
  makeViemWalletLayer,
} from "@storywithoutend/effect-ens/effect";

const store = makeInMemoryRegistrationStoreLayer();
const RenewalLive = makeEnsRenewalLayer(deployment).pipe(
  Layer.provide(
    Layer.mergeAll(
      makeViemRawEvmLayer(publicClient),
      makeViemWalletLayer({
        sendTransaction: (intent) => walletClient.sendTransaction({ account, ...intent }),
      }),
      store,
    ),
  ),
);

const result = await Effect.runPromise(
  EnsRenewal.use((ens) =>
    ens.renewEth2ld({
      id: "renewal-018f4d88",
      name: "alice.eth",
      durationSeconds: 31_536_000n,
      payment: { kind: "exact", maximumWei: 200_000_000_000_000_000n },
    }),
  ).pipe(Effect.provide(RenewalLive)),
);
```

Registration and renewal IDs share one store namespace. Use a distinct ID for every logical operation.

## Persist operation checkpoints in Node.js

The Node-only export provides an encrypted file store. Each checkpoint uses AES-256-GCM with the operation ID as authenticated data. Writes use a per-operation lock, compare-and-swap revision check, file synchronization, and atomic rename.

```ts
import { makeEncryptedFileCheckpointStore } from "@storywithoutend/effect-ens/node";

const checkpointStore = makeEncryptedFileCheckpointStore({
  directory: ".effect-ens/checkpoints",
  encryptionKey, // exactly 32 bytes, loaded from durable secret storage
});
const ens = makeEnsClient({
  deployment,
  publicClient,
  sendTransaction,
  checkpointStore,
});
```

The Effect-native equivalent is `makeEncryptedFileRegistrationStoreLayer` from `@storywithoutend/effect-ens/effect/node`. The legacy `/promise` and `/promise/node` paths remain aliases of the root Promise API.

Keep the same 32-byte key across restarts and protect it separately from the checkpoint directory. Losing the key makes existing checkpoints unreadable. Reusing this key outside the checkpoint store is unsupported.

## Safety limits

- Registration and renewal accept only normalized second-level `.eth` names. Registration sets no records, reverse record, or referrer; renewal uses a zero referrer.
- Buffer values range from 0 through 10,000 basis points. Every request sets `maximumWei`.
- The workflow polls a receipt every 1 second, at most 120 times per invocation.
- Eligibility waits use chain timestamps and sleep in chunks of at most 60 seconds. The workflow fetches a new price after eligibility.
- A persisted write attempt without a hash returns `SubmissionUncertain`. The workflow never retries a wallet write.
- Registration checkpoint bytes contain the registration secret. The in-memory store leaves it in process memory. The Node file store encrypts them at rest, but callers still own key storage, backup, and rotation.

## Experiment scorecard

| Measure | Current result |
| --- | --- |
| Offline gate | `pnpm verify` |
| Consumer API | Promise-only declarations and structured `EnsError`; Effect services remain available separately |
| Fast-check replay | Failures include the seed and path; a fixture test checks both |
| ENSjs differential | Historical transaction comparisons use 4.3.1; all five subgraph operations compare exact requests and valid results with 5.2.1 |
| ENSjs inventory | 15 export-map keys, 14 JavaScript subpaths, 946 top-level exports, and 22 namespace members are classified and drift-checked |
| ENSjs comparison | Effect wins owned-workflow safety; ENSjs remains leaner for transaction primitives; ENSjs mutation score is not measured |
| Anvil | Effect-native and Promise-only registration, renewal, replay, and ownership plus repricing, expiry, mined revert, and wrapping |
| Mutation score | Historical: 87.56% with 796 mutants. Subgraph: 80.11% with 2,288 mutants. Public V2: 95.57% with 158 mutants |
| Durable storage | Node-only AES-256-GCM file store with atomic CAS writes |
| Process-restart safety | Fresh-process registration and renewal resume/replay verified without duplicate writes |
| Subgraph fakes | Scripted, immutable model, and fault-injection transports all implement the raw unknown-response boundary |
| Fault cases | Transport, GraphQL, malformed, partial, repeated-cursor, latency, timeout, stall, cancellation, transfer, deleted, and expired cases |
| Architecture rules | TypeScript AST checks with negative fixtures for imports, oracle versions, fake independence, ambient time, exports, and retry calls |

Measured details are in the [apps-monorepo replacement plan](docs/apps-monorepo-port.md), [subgraph design](docs/subgraph-design.md), [ENSjs 5.2.1 export inventory](docs/evidence/ensjs-5.2.1-exports.json), [ENSjs comparison](docs/evidence/ensjs-comparison.md), [Anvil integration evidence](docs/evidence/anvil-integration.md), [historical mutation baseline](docs/evidence/mutation-baseline.md), [subgraph mutation baseline](docs/evidence/subgraph-mutation-baseline.md), [public V2 mutation baseline](docs/evidence/public-v2-mutation-baseline.md), and [process-restart evidence](docs/evidence/process-restart.md). The offline integration provides focused real-contract scenarios, not full contract verification.
