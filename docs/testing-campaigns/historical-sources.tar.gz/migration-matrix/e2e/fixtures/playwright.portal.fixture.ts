import { existsSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { ensL1Contracts, supportedL1Chains } from '@ensdomains/ensjs/chain'
import {
  injectHeadlessWeb3Provider,
  type Web3ProviderBackend,
} from '@ensdomains/headless-web3-provider'
import type { Page } from '@playwright/test'
import { test as base } from '@playwright/test'
import {
  type Account,
  type Address,
  bytesToHex,
  encodeFunctionData,
  type Hash,
  parseAbi,
} from 'viem'
import {
  mnemonicToAccount,
  nonceManager,
  privateKeyToAccount,
} from 'viem/accounts'
import { sepolia } from 'viem/chains'
import {
  publicClient,
  testClient,
  walletClient,
} from '../helpers/anvil-client.js'
import { createBignameMock } from '../helpers/mock-bigname.js'
import {
  connectWithHeadlessWallet,
  type PortalAccounts,
} from '../helpers/portal-auth.js'
import { createMakeMigratedName } from './makeMigratedName.js'
import { createMakeName } from './makeName.js'
import { createMakeSubname, type MakeSubname } from './makeSubname.js'
import { createTime, type Time } from './time.js'
import { createWallets, type Wallets } from './wallets.js'

// Override Sepolia chain to point at the local Anvil fork.
// The headless provider's internal walletClient uses this RPC URL
// to estimate gas and submit transactions.
const ANVIL_RPC_URL = process.env.ANVIL_RPC_URL ?? 'http://127.0.0.1:8545'
const localSepolia = {
  ...sepolia,
  rpcUrls: {
    default: { http: [ANVIL_RPC_URL] },
  },
} as const

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// Load the e2e `.env` natively (replaces `dotenv`). `process.loadEnvFile`
// throws if the file is missing, so guard on existence to keep the previous
// silent-when-absent behaviour.
const envPath = path.resolve(__dirname, '..', '.env')
if (existsSync(envPath)) {
  process.loadEnvFile(envPath)
}

// ---------------------------------------------------------------------------
// Accounts — derived from the default Anvil mnemonic
// Account 0 (0xf39F…2266) has 10 000 ETH on any Anvil fork.
// ---------------------------------------------------------------------------
const DEFAULT_MNEMONIC =
  'test test test test test test test test test test test junk'
// Resolve payment-token addresses from the ensjs Sepolia chain config — the
// SAME source as `@ens-apps/transaction-manager`'s `SUPPORTED_TOKENS` (which
// the portal's payment-token picker reads) and the other e2e fixtures
// (see makeName.ts / makeV2Name.ts). Hardcoding drifts from the app's tokens.
const ensjsSepolia = ensL1Contracts[supportedL1Chains.sepolia]
const MOCK_USDC = ensjsSepolia.usdc.address
const MOCK_DAI = ensjsSepolia.dai.address
const ANVIL_FUNDER = privateKeyToAccount(
  '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
)
const ERC20_ABI = parseAbi([
  'function mint(address to, uint256 amount)',
  'function balanceOf(address owner) view returns (uint256)',
])

// Shared indexer mock. Always constructed, but only installed on a page when
// `E2E_MOCK_BIGNAME=true` globally OR the test opts in via
// `mockBignameEnabled` (see the `page` fixture override below).
const bignameMock = createBignameMock()

/** The shared mock, for helpers that register names outside a fixture. */
export const portalBignameMock: {
  readonly addName: typeof bignameMock.addName
} = bignameMock

const users = ['user', 'user2', 'user3', 'user4'] as const
export type User = (typeof users)[number]

const isUser = (value: string): value is User =>
  (users as readonly string[]).includes(value)

export function createAccounts(): PortalAccounts {
  const mnemonic = DEFAULT_MNEMONIC

  const { accounts, privateKeys } = users.reduce<{
    accounts: Account[]
    privateKeys: Hash[]
  }>(
    (acc, _, index) => {
      const { getHdKey } = mnemonicToAccount(mnemonic, {
        addressIndex: index,
      })
      const privateKey = bytesToHex(getHdKey().privateKey!)
      const account = privateKeyToAccount(privateKey, { nonceManager })
      return {
        accounts: [...acc.accounts, account],
        privateKeys: [...acc.privateKeys, privateKey],
      }
    },
    { accounts: [], privateKeys: [] },
  )

  return {
    getAddress: (user: User = 'user'): Address => {
      const index = users.indexOf(user)
      if (index < 0) throw new Error(`User not found: ${user}`)
      return accounts[index].address
    },
    getAllPrivateKeys: () => privateKeys,
    getPrivateKey: (user: User = 'user') => {
      const index = users.indexOf(user)
      if (index < 0) throw new Error(`User not found: ${user}`)
      return privateKeys[index]
    },
  }
}

async function waitForTx(hash: Hash) {
  await publicClient.waitForTransactionReceipt({ hash })
}

// Anvil's default mnemonic ("test test test ... junk") is public, so its
// derived addresses are widely known. Bots watch live Sepolia for funds
// landing on them and sweep automatically — some via an EIP-7702 delegation,
// which the fork inherits as real contract bytecode. That turns a plain
// recipient EOA into an ERC1155 receiver whose callback doesn't return the
// correct magic value, reverting any `safeTransferFrom` to it (e.g.
// transfer.spec.ts sending to `user2`). Wiping the code restores a plain EOA
// on the fork. Clear it for every test account, since any of them can end up
// as a transfer recipient or registration owner.
export async function clearAnvilSquattedCode(address: Address) {
  await testClient.setCode({ address, bytecode: '0x' })
}

async function ensurePortalStablecoinBalances(address: Address) {
  const [usdcBalance, daiBalance] = await Promise.all([
    publicClient.readContract({
      address: MOCK_USDC,
      abi: ERC20_ABI,
      functionName: 'balanceOf',
      args: [address],
    }),
    publicClient.readContract({
      address: MOCK_DAI,
      abi: ERC20_ABI,
      functionName: 'balanceOf',
      args: [address],
    }),
  ])

  if (usdcBalance < 10_000_000_000n) {
    const mintUsdcData = encodeFunctionData({
      abi: ERC20_ABI,
      functionName: 'mint',
      args: [address, 10_000_000_000n], // 10_000 USDC (6 decimals)
    })
    const hash = await walletClient.sendTransaction({
      account: ANVIL_FUNDER,
      to: MOCK_USDC,
      data: mintUsdcData,
    })
    await waitForTx(hash)
  }

  if (daiBalance < 10_000_000_000_000_000_000_000n) {
    const mintDaiData = encodeFunctionData({
      abi: ERC20_ABI,
      functionName: 'mint',
      args: [address, 10_000_000_000_000_000_000_000n], // 10_000 DAI (18 decimals)
    })
    const hash = await walletClient.sendTransaction({
      account: ANVIL_FUNDER,
      to: MOCK_DAI,
      data: mintDaiData,
    })
    await waitForTx(hash)
  }
}

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------
export type PortalFixtures = {
  /** Headless web3 wallet backend — use to authorize transactions. */
  wallet: Web3ProviderBackend
  /** Test accounts derived from the Anvil mnemonic. */
  accounts: PortalAccounts
  /** Page with the headless wallet already injected (but NOT connected). */
  portalPage: Page
  /** Time fixture for syncing anvil block time with the browser clock. */
  time: Time
  /** Register names on the anvil fork (supports expired / premium states). */
  makeName: ReturnType<typeof createMakeName>
  /** Register a V1 name and migrate it to V2 (unwrapped / unlocked / locked). */
  makeMigratedName: ReturnType<typeof createMakeMigratedName>
  /**
   * Named participants (owner / manager / stranger) with mid-test switching.
   * Every authorization negative case needs this — see `fixtures/wallets.ts`.
   */
  wallets: Wallets
  /** Create N-deep V2 subnames through UserRegistry — see `makeSubname.ts`. */
  makeSubname: MakeSubname
  /**
   * Per-test/per-file opt-in for the mock indexer (an "option" fixture — set
   * with `test.use({ mockBignameEnabled: true })`, not overridden directly).
   * Off by default: the portal suite exercises the real local bigname end to
   * end. A test opts in when it needs deterministic control over an
   * indexer-backed count instead of waiting on real indexing — see
   * transfer.spec.ts's registry-detach tests.
   */
  mockBignameEnabled: boolean
  /**
   * Mock indexer control, for tests running with `mockBignameEnabled: true`.
   * Configuring a response with these has no effect if the mock was never
   * installed on the page.
   */
  mockBigname: {
    setRegistryOccupants: typeof bignameMock.setRegistryOccupants
    setSubregistryHistory: typeof bignameMock.setSubregistryHistory
    enabled: boolean
  }
}

export const test = base.extend<PortalFixtures>({
  mockBignameEnabled: [false, { option: true }],

  // The portal reads bigname like the manager (#1354), so the shared bigname
  // mock goes in whenever `E2E_MOCK_BIGNAME=true` (CI). A test can still opt
  // in on its own with `mockBignameEnabled` while the rest of a run uses the
  // local bigname.
  page: async ({ page, mockBignameEnabled }, use) => {
    if (mockBignameEnabled) await bignameMock.install(page)
    else await bignameMock.installIfEnabled(page)
    await use(page)
  },

  accounts: async ({}, use) => {
    await use(createAccounts())
  },

  wallet: async ({ page, accounts }, use) => {
    await Promise.all(
      users.map((user) => clearAnvilSquattedCode(accounts.getAddress(user))),
    )
    await ensurePortalStablecoinBalances(accounts.getAddress('user'))
    const privateKeys = accounts.getAllPrivateKeys()
    const wallet = await injectHeadlessWeb3Provider({
      page,
      privateKeys,
      chains: [localSepolia],
    })
    await use(wallet)
  },

  portalPage: async ({ page, wallet }, use) => {
    const baseURL = process.env.PORTAL_APP_URL ?? 'http://localhost:3001'
    await page.goto(baseURL)
    // Brief wait for app initialisation
    await Promise.race([
      page.waitForLoadState('networkidle'),
      page.waitForTimeout(5_000),
    ]).catch(() => {})
    await use(page)
  },

  time: async ({ page }, use) => {
    await use(createTime({ page }))
  },

  makeName: async ({ accounts, time }, use) => {
    const inner = createMakeName({ accounts, time })
    await use(async (config, options) => {
      const name = await inner(config, options)
      // Registered on the fork only, so the bigname mock has to be told.
      if (bignameMock.enabled)
        bignameMock.addName({
          name,
          owner: accounts.getAddress(
            config.owner && isUser(config.owner) ? config.owner : 'user2',
          ),
          records: config.records,
          ...(config.duration !== undefined && {
            expiryDate: Math.floor(Date.now() / 1000) + config.duration,
          }),
        })
      return name
    })
  },

  makeMigratedName: async ({ accounts }, use) => {
    await use(createMakeMigratedName({ accounts }))
  },

  wallets: async ({ page, wallet, accounts }, use) => {
    await use(createWallets({ page, wallet, accounts }))
  },

  makeSubname: async ({ wallets }, use) => {
    await use(createMakeSubname({ account: wallets.account('owner') }))
  },

  mockBigname: async ({ mockBignameEnabled }, use) => {
    await use({
      setRegistryOccupants: bignameMock.setRegistryOccupants,
      setSubregistryHistory: bignameMock.setSubregistryHistory,
      enabled: mockBignameEnabled,
    })
  },
})

export { expect } from '@playwright/test'
export { connectWithHeadlessWallet } from '../helpers/portal-auth.js'
