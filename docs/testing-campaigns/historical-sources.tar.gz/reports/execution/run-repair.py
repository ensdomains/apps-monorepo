import os,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent
while True:
 try: os.kill(63092,0)
 except ProcessLookupError: break
 time.sleep(5)
stem='rebased-retained-manager-repair'
env={**os.environ,'E2E_MOCK_BIGNAME':'false','E2E_MOCK_INDEXER':'false','E2E_EXPLORER_INDEXER':'bigname','PLAYWRIGHT_JSON_OUTPUT_NAME':str(r/(stem+'.json'))}
cmd=['/Users/sg/.nvm/versions/node/v24.13.1/bin/node','node_modules/@playwright/test/cli.js','test','--config','projects/parity/playwright.config.ts','--grep','REG-02|L027|L283','--reporter=list,json','--output='+str(r/(stem+'-artifacts'))]
print('Starting '+stem,flush=True)
with (r/(stem+'.log')).open('w') as log:
 result=subprocess.run(cmd,cwd='/Users/sg/ens/worktrees/ens-manager-replacement-parity/e2e',env=env,stdout=log,stderr=subprocess.STDOUT)
print('Finished '+stem+' exit '+str(result.returncode),flush=True)
subprocess.run(['python3',str(r/'update-report.py')],check=True)
