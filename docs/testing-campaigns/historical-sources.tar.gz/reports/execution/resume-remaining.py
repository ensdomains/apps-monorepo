"""Resume the saved non-stateful, non-DNS batches with an overlap guard."""
import json
import os
from pathlib import Path
import signal
import sys
import subprocess
import time

ROOT = Path(__file__).resolve().parent
WORKTREE = Path('/Users/sg/ens/worktrees/ens-manager-replacement-parity/e2e')
NODE = '/Users/sg/.nvm/versions/node/v24.13.1/bin/node'

def other_runs(own_pid=None):
    lines = subprocess.check_output(['ps', '-axo', 'pid=,command='], text=True).splitlines()
    return [line.strip() for line in lines if 'playwright/test/cli.js test ' in line
            and int(line.split()[0]) != own_pid]

for name, args in json.loads((ROOT / (sys.argv[1] if len(sys.argv) > 1 else 'remaining-batches.json')).read_text()):
    active = other_runs()
    if active:
        raise SystemExit('Shared chain is occupied; no batch launched:\n' + '\n'.join(active))
    env = {**os.environ, 'E2E_MOCK_BIGNAME': 'false', 'E2E_MOCK_INDEXER': 'false',
           'E2E_EXPLORER_INDEXER': 'bigname',
           'PLAYWRIGHT_JSON_OUTPUT_NAME': str(ROOT / f'fullhistory-{name}.json')}
    with (ROOT / f'fullhistory-{name}.log').open('w') as log:
        proc = subprocess.Popen([NODE, 'node_modules/@playwright/test/cli.js', 'test', *args,
                                 '--workers=1', '--reporter=list,json',
                                 '--output=' + str(ROOT / f'fullhistory-{name}-artifacts')],
                                cwd=WORKTREE, env=env, stdout=log, stderr=subprocess.STDOUT)
        try:
            while proc.poll() is None:
                time.sleep(5)
                active = other_runs(proc.pid)
                if active:
                    proc.send_signal(signal.SIGINT)
                    proc.wait(timeout=45)
                    raise SystemExit('Another run started; batch interrupted. Repeat after exclusive chain access.')
        except BaseException:
            if proc.poll() is None:
                proc.send_signal(signal.SIGINT)
                proc.wait(timeout=45)
            raise
    print(name, 'exit', proc.returncode, flush=True)
    subprocess.run(['python3', str(ROOT / 'update-report.py')], check=True)
