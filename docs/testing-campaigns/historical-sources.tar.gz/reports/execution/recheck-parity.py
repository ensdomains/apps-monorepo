import os,signal,time,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent
try:
 while not (r/'fullhistory-parity.json').exists(): time.sleep(3)
 env={**os.environ,'E2E_MOCK_BIGNAME':'false','E2E_MOCK_INDEXER':'false','E2E_EXPLORER_INDEXER':'bigname','PLAYWRIGHT_JSON_OUTPUT_NAME':str(r/'fullhistory-parity-recheck.json')}
 with (r/'fullhistory-parity-recheck.log').open('w') as log:
  result=subprocess.run(['/Users/sg/.nvm/versions/node/v24.13.1/bin/node','node_modules/@playwright/test/cli.js','test','--config','projects/parity/playwright.config.ts','--grep','L086|L090|REG-02','--workers=1','--reporter=list,json','--output='+str(r/'fullhistory-parity-recheck-artifacts')],cwd='/Users/sg/ens/worktrees/ens-manager-replacement-parity/e2e',env=env,stdout=log,stderr=subprocess.STDOUT)
 print('Adapter recheck exit',result.returncode,flush=True)
 subprocess.run(['python3',str(r/'update-report.py')],check=True)
finally:
 os.kill(27147,signal.SIGCONT)
