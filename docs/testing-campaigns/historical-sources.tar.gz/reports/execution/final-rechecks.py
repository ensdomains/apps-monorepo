import os,subprocess,time,json
from pathlib import Path
r=Path(__file__).resolve().parent
while not (r/'fullhistory-migration.json').exists(): time.sleep(10)
time.sleep(5)
for name,args in json.loads((r/'recheck-batches.json').read_text()):
 env={**os.environ,'E2E_MOCK_BIGNAME':'false','E2E_MOCK_INDEXER':'false','E2E_EXPLORER_INDEXER':'bigname','PLAYWRIGHT_JSON_OUTPUT_NAME':str(r/('fullhistory-'+name+'.json'))}
 with (r/('fullhistory-'+name+'.log')).open('w') as log:
  proc=subprocess.Popen(['/Users/sg/.nvm/versions/node/v24.13.1/bin/node','node_modules/@playwright/test/cli.js','test',*args,'--workers=1','--reporter=list,json','--output='+str(r/('fullhistory-'+name+'-artifacts'))],cwd='/Users/sg/ens/worktrees/ens-manager-replacement-parity/e2e',env=env,stdout=log,stderr=subprocess.STDOUT)
  while proc.poll() is None:
   time.sleep(10)
   state=json.loads(subprocess.check_output(['docker','inspect','infra-anvil-1']))[0]['State']
   if not state['Running']:
    proc.send_signal(2);proc.wait(timeout=30);raise RuntimeError('Chain stopped')
 print(name,'exit',proc.returncode,flush=True)
 subprocess.run(['python3',str(r/'update-report.py')],check=True)
