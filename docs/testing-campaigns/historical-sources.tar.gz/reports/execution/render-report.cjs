const { chromium } = require('/Users/sg/ens/worktrees/ens-manager-replacement-parity/e2e/node_modules/@playwright/test');
(async()=>{
 const browser=await chromium.launch({headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:1150}});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.goto('file:///Users/sg/Documents/ChatGPT/ENS/replacement-readiness/execution/Execution%20results.html');
 await page.screenshot({path:'/Users/sg/Documents/ChatGPT/ENS/replacement-readiness/execution/report-preview.png'});
 await page.goto('file:///Users/sg/Documents/ChatGPT/ENS/replacement-readiness/ENS%20replacement%20test%20plan.html');
 await page.locator('#query').fill('L031');
 await page.locator('#L031 > summary').click();
 console.log(JSON.stringify({errors,matched:await page.locator('#count').innerText(),v1Outcome:await page.locator('select[aria-label="L031 v1 outcome"]').inputValue()}));
 await page.screenshot({path:'/Users/sg/Documents/ChatGPT/ENS/replacement-readiness/execution/ledger-preview.png'});
 await browser.close();
})();
