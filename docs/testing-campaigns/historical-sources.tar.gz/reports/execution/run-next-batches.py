import os, subprocess, time, json
from pathlib import Path
r=Path(__file__).resolve().parent
cwd='/Users/sg/ens/worktrees/ens-manager-replacement-parity/e2e'
# The Explorer batch already owns the shared test chain. Wait for it to exit.
while True:
 try: os.kill(92853,0)
 except ProcessLookupError: break
 time.sleep(5)
batches=[
 ('legacy-parity',['--config','projects/parity/playwright.config.ts']),
 ('resolver-adapted',['--config','projects/portal/playwright.config.ts','--project=portal-e2e','--no-deps','--grep','@scenario:E10']),
 ('portal-lts',['--config','projects/portal/playwright.config.ts','--project=portal-e2e','--no-deps','transfer.spec.ts','subnames.spec.ts','records.spec.ts','resolver.spec.ts','roles.spec.ts','fuses.spec.ts']),
 ('cross-app',['--config','projects/cross-app/playwright.config.ts']),
 ('manager-core',['--config','projects/manager/playwright.config.ts','--project=manager-e2e','--no-deps']),
 ('migration-managers',['--config','projects/manager/playwright.migration.config.ts','--project=manager-migration','--no-deps','migration-managers.spec.ts']),
]
for name,args in batches:
 stem='rebased-'+name
 env={**os.environ,'E2E_MOCK_BIGNAME':'false','E2E_MOCK_INDEXER':'false','E2E_EXPLORER_INDEXER':'bigname','PLAYWRIGHT_JSON_OUTPUT_NAME':str(r/(stem+'.json'))}
 command=['/Users/sg/.nvm/versions/node/v24.13.1/bin/node','node_modules/@playwright/test/cli.js','test',*args,'--max-failures=3','--reporter=list,json','--output='+str(r/(stem+'-artifacts'))]
 print('Starting '+stem,flush=True)
 with (r/(stem+'.log')).open('w') as log:
  result=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('Finished '+stem+' exit '+str(result.returncode),flush=True)
 subprocess.run(['python3',str(r/'update-report.py')],check=True)
