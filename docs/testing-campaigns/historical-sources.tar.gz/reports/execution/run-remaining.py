import os,subprocess,time,json
from pathlib import Path
r=Path(__file__).resolve().parent
while True:
 try: os.kill(78410,0)
 except ProcessLookupError: break
 time.sleep(5)
# Finish the previously unattempted cases; exclude the V1 transfer group already
# covered by the preceding batch. Each fixture creates its own fresh names.
batches=[
 ('legacy-deletion',['--config','projects/parity/playwright.config.ts','v1-delete-subname.spec.ts']),
 ('manager-remaining',['--config','projects/manager/playwright.config.ts','--project=manager-e2e','--no-deps','primaryName.spec.ts','profile.spec.ts','registration-resume.spec.ts','registration-rhinestone.spec.ts','registration.spec.ts','transaction-history.spec.ts','transfer-observers.spec.ts','--grep-invert','primary name is automatically']),
 ('portal-transfer-remaining',['--config','projects/portal/playwright.config.ts','--project=portal-e2e','--no-deps','transfer.spec.ts','--grep-invert','unmigrated V1 names']),
]
for name,args in batches:
 stem='rebased-'+name
 env={**os.environ,'E2E_MOCK_BIGNAME':'false','E2E_MOCK_INDEXER':'false','E2E_EXPLORER_INDEXER':'bigname','PLAYWRIGHT_JSON_OUTPUT_NAME':str(r/(stem+'.json'))}
 cmd=['/Users/sg/.nvm/versions/node/v24.13.1/bin/node','node_modules/@playwright/test/cli.js','test',*args,'--reporter=list,json','--output='+str(r/(stem+'-artifacts'))]
 print('Starting '+stem,flush=True)
 with (r/(stem+'.log')).open('w') as log:
  result=subprocess.run(cmd,cwd='/Users/sg/ens/worktrees/ens-manager-replacement-parity/e2e',env=env,stdout=log,stderr=subprocess.STDOUT)
 print('Finished '+stem+' exit '+str(result.returncode),flush=True)
 subprocess.run(['python3',str(r/'update-report.py')],check=True)
