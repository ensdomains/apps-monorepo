import json, html, re, subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
W=Path('/Users/sg/ens/worktrees/ens-manager-replacement-parity')
TEST_COMMIT=subprocess.check_output(['git','rev-parse','--short=9','HEAD'],cwd=W,text=True).strip()
if subprocess.check_output(['git','status','--porcelain','--','e2e'],cwd=W,text=True).strip(): TEST_COMMIT += ' + local test changes'
ledger=R.parent/'parity-ledger.json'
d=json.loads(ledger.read_text())
rows=[]
for p in sorted([*R.glob('rebased-*.json'), *R.glob('fullhistory-*.json')]):
 try: report=json.loads(p.read_text())
 except (ValueError,OSError): continue
 def walk(suites,parents=()):
  for s in suites:
   for spec in s.get('specs',[]):
    for t in spec.get('tests',[]):
     rs=t.get('results',[]); last=rs[-1] if rs else {}; actual=last.get('status','not-run'); expected=t.get('expectedStatus','passed')
     verdict=('Expected failure (not a pass)' if actual in ('failed','timedOut') and expected=='failed' else 'Pass' if actual=='passed' and expected=='passed' else 'Unexpected pass — review annotation' if actual=='passed' else 'Skipped' if actual=='skipped' else 'Not run' if not rs else 'Failed / needs triage')
     row=dict(batch=p.stem,project=t.get('projectName'),title=' > '.join((*parents,s.get('title',''),spec['title'])),file=str((Path(report['config']['rootDir'])/spec.get('file',s.get('file'))).resolve()),line=spec.get('line'),expected=expected,actual=actual,verdict=verdict,duration_ms=last.get('duration'),error=re.sub(r'\x1b\[[0-9;]*m','','\n\n'.join(x.get('message','') for x in last.get('errors',[]) or [last.get('error') or {}])),attachments=last.get('attachments',[]),report=str(p),started_at=last.get('startTime',report.get('stats',{}).get('startTime','')))
     if row['batch'].startswith('rebased-') and row['project']=='legacy-parity' and (R/'indexer-history-blocker.json').exists():
      if re.search(r' > L03[126] ',row['title']) and actual!='passed': row['verdict']='Blocked environment'
      if ' > L036 ' in row['title'] and actual=='passed' and row['batch']=='rebased-legacy-parity': row['verdict']='Superseded assertion — rerun required'
     if row['batch'].startswith('rebased-') and (R/'chain-oom-blocker.json').exists() and actual in ('failed','timedOut','interrupted') and (('HTTP request failed' in row['error'] and '127.0.0.1:8545' in row['error']) or row['started_at'] >= '2026-10-21T17:50:40Z'):
      row['verdict']='Blocked environment'
      row['blocker']='chain-oom-blocker.json'
     if row['batch']=='fullhistory-legacy-ownership-restrictions' and actual in ('failed','timedOut'):
      row['verdict']='Test adapter issue — registration minimum duration; rerun required'
     if row['batch']=='fullhistory-legacy-ownership-restrictions-recheck' and actual in ('failed','timedOut'):
      row['verdict']='Test adapter issue — extra owner-display assertion; original action oracle rerun separately'
     if row['batch']=='fullhistory-legacy-root-fuses' and actual in ('failed','timedOut'):
      row['verdict']='Test adapter issue — icon text in resolver link accessible name; rerun required'
     if row['batch']=='fullhistory-legacy-sync-and-denied-corrected' and re.search(r' > (L135|L180) ',row['title']) and actual in ('failed','timedOut'):
      row['verdict']='Test adapter issue — wrapped child under unwrapped parent fixture; rerun required'
     if row['batch']=='fullhistory-legacy-renew-referrer' and actual in ('failed','timedOut') and ('strict mode violation' in row['error'] or 'I Understand' in row['error']):
      row['verdict']='Test adapter issue — overlapping dialog animation or disappearing ownership disclaimer; rerun required'
     if row['batch']=='fullhistory-legacy-expiry-sections' and actual in ('failed','timedOut') and re.search(r' > (L134|L136|L144|L148|L152|L154|L158) ',row['title']):
      row['verdict']='Test adapter issue — parent expiry oracle must follow original per-case expectations; rerun required'
     if row['batch']=='fullhistory-parity' and actual in ('failed','timedOut') and re.search(r' > (L086|L090|L036) ',row['title']): row['verdict']='Test adapter issue — rerun required'
     if row['batch']=='fullhistory-manager-core' and actual in ('failed','timedOut') and expected=='passed':
      if 'Nonce provided' in row['error']:
       row['verdict']='Fixture nonce collision — rerun required'
      elif 'favourite' in row['title']:
       row['verdict']='Backend unavailable — rerun required'
      elif any(x in row['title'] for x in ['bulk-renew only','renewing with no USDC','never offers a renewal date','ends on "Name No Longer Available"','reveal failure nobody else','a wallet short of the remainder','a renewal archived']):
       row['verdict']='Test adapter issue — rerun required'
     if row['batch']=='fullhistory-portal-transfer-remaining' and actual in ('failed','timedOut') and expected=='passed':
      if any(x in row['title'] for x in ['ENS name owned by wallet B','own address or its own ENS name','new owner edit records','repoints the ETH address','updates the ETH address and detaches','resume after a rejected step','third-party manager role grant','surfaces an error when the recipient']):
       row['verdict']='Test adapter issue — rerun required'
     if row['batch']=='fullhistory-portal-transfer-remaining' and 'writes the ETH address to a resolver' in row['title'] and 'setAddr' in row['error']:
      row['verdict']='Fixture setup failed before expected assertion — rerun required'
     if row['batch']=='fullhistory-portal-additional' and actual in ('failed','timedOut') and expected=='passed' and any(x in row['title'] for x in ['crafted link is ignored even','a real registration still shows the banner','does not ask a wallet on another network','Extend keeps Next disabled','the Extend confirm step offers no token']):
      row['verdict']='Test adapter issue — rerun required'
     if row['batch']=='fullhistory-portal-additional' and actual=='interrupted':
      row['verdict']='Interrupted for test adapter update — rerun queued'
     if row['batch']=='fullhistory-migration' and 'migration-grace.spec.ts' in row['file'] and actual in ('failed','timedOut') and expected=='passed':
      row['verdict']='Fixture assumptions — isolated rerun required'
     if row['batch']=='fullhistory-primary-fresh-wallet' and actual in ('failed','timedOut'):
      row['verdict']='Fixture funding missing — funded rerun queued'
     if row['batch']=='fullhistory-migration' and 'a wrapped name is never offered a manager' in row['title'] and actual in ('failed','timedOut'):
      row['verdict']='Fixture selection — rerun required'
     if row['batch']=='fullhistory-v1-primary' and actual in ('failed','timedOut') and 'Nonce provided' in row['error']:
      row['verdict']='Concurrent local run — repeat required'
     if row['batch']=='fullhistory-registration-copy-recheck' and actual in ('failed','timedOut') and 'getByText' in row['error']:
      row['verdict']='Search setup failure — direct-entry rerun queued'
     if row['batch'] in ('fullhistory-transfer-history-recheck','fullhistory-portal-transfer-adapter-recheck','fullhistory-portal-banner-recheck') and actual=='passed':
      row['verdict']='Provisional pass — concurrent run; isolated repeat queued'
     if row['batch']=='fullhistory-startup-endpoint-mismatch' and actual in ('failed','timedOut','interrupted'):
      row['verdict']='Startup endpoint mismatch — environment failure'
     if row['batch']=='fullhistory-portal-renewal-remaining' and 'a name past its grace' in row['title'] and actual!='passed':
      row['verdict']='Test adapter issue — optional disclaimer; rerun queued'
     if row['batch']=='fullhistory-migration-wrapped-manager-recheck' and actual!='passed':
      row['verdict']='Test helper retained partial selection — rerun queued'
     if row['batch']=='fullhistory-primary-funded-wallet' and actual!='passed':
      row['verdict']='Commitment submission failed — chain-clock rerun queued'
     if row['batch']=='fullhistory-primary-chain-clock-recheck' and actual!='passed':
      row['verdict']='Ambiguous dashboard selector — final rerun queued'
     if row['batch']=='fullhistory-legacy-profile-records' and actual in ('failed','timedOut'):
      row['verdict']='Test adapter issue — legacy fixture multicall or inline delete confirmation; rerun queued'
     if row['batch']=='fullhistory-legacy-send-matrix' and actual in ('failed','timedOut') and 'Clicking the checkbox did not change its state' in row['error']:
      row['verdict']='Test adapter issue — empty profile has nothing to bulk-select; rerun queued'
     if row['batch']=='fullhistory-legacy-resolver-profiles' and actual in ('failed','timedOut') and any((' '+i+' ') in row['title'] for i in ('L217','L218','L222')):
      row['verdict']='Test adapter issue — unset ETH may be empty bytes; rerun queued'
     if row['batch']=='fullhistory-legacy-address-target-recheck' and actual in ('failed','timedOut'):
      row['verdict']='Test adapter issue — landing search fill lost during hydration; rerun queued'
     if row['batch'] in ('fullhistory-legacy-address-errors','fullhistory-legacy-address-rpc-recheck') and actual in ('failed','timedOut') and 'L023 ' in row['title']:
      row['verdict']='Test adapter issue — RPC matcher intercepted no calls; rerun queued'
     if row['batch']=='fullhistory-legacy-resolver-choice' and actual in ('failed','timedOut') and 'L282 ' in row['title']:
      row['verdict']='Test adapter issue — unrelated unchanged-value assertion removed; rerun queued'
     if row['batch']=='fullhistory-legacy-resolver-choice-recheck' and actual in ('failed','timedOut') and 'L282 ' in row['title']:
      row['verdict']='Test adapter issue — hidden duplicate resolver link; rerun queued'
     if row['batch']=='fullhistory-legacy-metamask-connect-recheck' and actual in ('failed','timedOut') and any(i in row['title'] for i in ('L308 ', 'L313 ')):
      row['verdict']='Test adapter issue — Manager Connect icon text or post-assertion screenshot timeout; rerun queued'
     if row['batch']=='fullhistory-legacy-metamask-connect' and actual in ('failed','timedOut') :
      row['verdict']='Test adapter issue — MetaMask popup/Connect selector; rerun queued'
     if row['batch']=='fullhistory-legacy-unregistered-links-recheck' and actual in ('failed','timedOut') and 'L067 ' in row['title']:
      row['verdict']='Test adapter issue — disconnected registration offers Connect to register; rerun queued'
     if row['batch']=='fullhistory-legacy-renew-links' and actual in ('failed','timedOut') and re.search(r' > (L066|L067) ',row['title']):
      row['verdict']='Test adapter issue — registration heading contains name only; rerun queued'
     if row['batch']=='fullhistory-legacy-renew-dates' and actual=='passed' and re.search(r' > (L061|L063) ',row['title']):
      row['verdict']='Test adapter issue — full displayed date must supplement chain expiry; rerun queued'
     if row['batch']=='fullhistory-legacy-desync' and actual in ('failed','timedOut'):
      row['verdict']='Test adapter issue — reserve once after registrar-only extension; rerun queued'
     if row['batch']=='fullhistory-legacy-outdated-constructor-recheck' and actual in ('failed','timedOut') and 'L213 ' in row['title']:
      row['verdict']='Test adapter issue — V3 storage layout differs; verify resolver authority through supported writes'
     if row['batch']=='fullhistory-legacy-outdated-resolver' and actual in ('failed','timedOut') and 'InvalidFEOpcode' in row['error']:
      row['verdict']='Test adapter issue — archived creation code includes old constructor argument; rerun queued'
     if row['batch']=='fullhistory-legacy-bulk-renew' and actual in ('failed','timedOut') and 'L077 ' in row['title']:
      row['verdict']='Test adapter issue — checkout abbreviates a single label; rerun queued'
     if row['batch']=='fullhistory-legacy-indexer-errors' and actual in ('failed','timedOut') :
      row['verdict']='Test adapter issue — Delete accessible name or fault matcher intercepted a Vite module; rerun queued'
     if row['batch']=='fullhistory-legacy-authorization' and actual in ('failed','timedOut') and 'L231 ' in row['title']:
      row['verdict']='Test adapter issue — test the original edit-entry restriction, not presence of an empty editor button; rerun queued'
     if row['batch']=='fullhistory-legacy-history-expanded-recheck' and actual in ('failed','timedOut') and 'toContainText' in row['error']:
      row['verdict']='Test adapter issue — history identifies transactions by hash, not transferred-name text; rerun queued'
     if row['batch']=='fullhistory-legacy-history-completion-recheck' and actual in ('failed','timedOut') and 'toContainText' in row['error']:
      row['verdict']='Test adapter issue — expand grouped history events before inspecting names; rerun queued'
     if row['batch']=='fullhistory-legacy-history-empty-resolver-recheck' and actual in ('failed','timedOut','interrupted'):
      row['verdict']='Test adapter issue — completion observer raced the Done click; rerun queued'
     if row['batch']=='fullhistory-legacy-transaction-history' and actual in ('failed','timedOut') and 'Detach the resolver' in row['error']:
      row['verdict']='Test adapter issue — zero resolver has no detach switch; rerun queued'
     rows.append(row)
   walk(s.get('suites',[]),(*parents,s.get('title','')))
 walk(report.get('suites',[]))
from collections import Counter
rows.sort(key=lambda r:r['started_at'])
counts=dict(Counter(r['verdict'] for r in rows))
latest={}
for r in rows:
 key=(r['project'],r['file'],r['title'])
 if r['verdict']=='Not run' and key in latest: continue
 latest[key]=r
unique_counts=dict(Counter(r['verdict'] for r in latest.values()))
d['execution']={'branch':'test/ens-manager-replacement-parity','test_commit':TEST_COMMIT,'base_commit':'081dff188','main_commit':'279c31002','scope':'294 active legacy rows; 18 stateful excluded; DNS deferred; related tests are not one-to-one parity certification','counts':counts,'unique_latest_counts':unique_counts,'runs':rows}
for case in d['tests']:
 candidates=[]
 for rel in case.get('related_tests',[]):
  for row in rows:
   if Path(row['file'] or '').name==Path(rel['file']).name and row['title'].endswith(rel['title'].split(' > ')[-1]): candidates.append({k:row[k] for k in ['batch','title','verdict','report']})
 case['related_executions']=candidates
# Only purpose-built legacy ports can change a legacy lane's outcome.
for row in rows:
 match=re.search(r" > (L\d{3}) ",row['title'])
 if row['project']!='legacy-parity' or not match or row['actual'] not in ('passed','failed','timedOut'): continue
 case=next((c for c in d['tests'] if c['id']==match[1]),None)
 if not case: continue
 out=case['results']['v1']
 out['decision_reason']=''
 if row['verdict'].startswith('Test adapter issue'):
  out.update(status='Not run',actual_result=row['title']+' — '+row['verdict'],evidence=row['report'],failed_step=row['error'],tester='Automated Playwright parity port')
  continue
 out.update(status=('Blocked environment' if row['verdict']=='Blocked environment' else ('Pass with workaround' if match[1] in ('L031','L032','L036','L215') else 'Pass') if row['actual']=='passed' else 'Fail'),actual_surface='Explorer',actual_result=row['title']+' — '+row['verdict'],evidence=row['report'],tester='Automated Playwright parity port',run_date=row['started_at'][:10],build='081dff188 plus parity tests',chain_id='11155111',fixture=row['file']+':'+str(row['line']),failed_step=row['error'])
 if match[1] in ('L031','L032'): out['workaround_steps']='Create the child in Explorer, then open its Edit records page and save the original name, description and ETH records. The old single wizard is split into two flows.'
 if match[1]=='L215': out['workaround_steps']='The record editor does not guide resolver setup. Open Explorer Resolver → Set/Change resolver, enter the V1 public resolver address, save, then return to Edit records. The new UI requires supplying the address.'
 if match[1] in ('L272','L273') or any(x in row['file'] for x in ('v1-legacy-wrapping','v1-legacy-wrap-restrictions','v1-legacy-expiry-sections','v1-legacy-permission-entrypoints')): out['actual_surface']='Explorer + Manager'
 if 'v1-legacy-role-transfer' in row['file']:
  out['workaround_steps']='Use Explorer Reclaim manager for manager-to-self, or Transfer with resolver retained and ETH update disabled for the selected ownership change. On-chain authority was checked after completion.'
 if row['actual']=='passed' and any(x in row['file'] for x in ('v1-legacy-role-transfer','v1-legacy-edit-roles','v1-legacy-send','v1-legacy-profile-records','v1-legacy-primary-repair','v1-legacy-renew-referrer','v1-legacy-expiry-sections')):
  out['status']='Pass with workaround'
  if 'v1-legacy-send' in row['file'] or 'v1-legacy-edit-roles' in row['file']: out['workaround_steps']='Explorer Transfer replaces Send/Edit Roles. Where needed, use Edit records first to reset the profile or add a previously absent ETH record; keep the resolver and disable duplicate ETH writes. Exact per-case steps are in the attached workflow-adaptation/workaround evidence and test source.'
  if 'v1-legacy-profile-records' in row['file']: out['workaround_steps']='Use Explorer typed Edit records. Remove/add a record to replace its value; select records and Remove to delete. The original resolver is retained and all record types are checked on chain.'
  if 'v1-legacy-primary-repair' in row['file']: out['workaround_steps']='Use Explorer address Reverse resolution → Mainnet; first repair ETH through Edit records when required. Verify the primary name in Manager.'
  if 'v1-legacy-renew-referrer' in row['file']: out['workaround_steps']='Open the Explorer address Names list, search and select the V1 name, then Extend. The V1 profile offers upgrade instead. Payment uses the current V1 renewer and USDC.'
  if 'v1-legacy-expiry-sections' in row['file']: out['workaround_steps']='Follow the linked parent profile to inspect parent expiry; use address Names → Extend for V1 renewal. Check failures separately for missing grace-end or reminder information.'
 if row['actual']=='passed':
  adaptations={
   'v1-legacy-resolver-profiles':'Explorer Resolver → Change with the explicit public resolver address. Keep the latest profile, or reset/copy through separate Edit records transactions. Exact record values checked on chain; per-case trace contains the sequence.',
   'v1-legacy-outdated-resolver':'Manually change the outdated resolver in Explorer; keep its latest profile or reset via Edit records. No guided upgrade wizard is assumed.',
   'v1-legacy-resolver-choice':'Choose the resolver by explicit address in Explorer instead of the legacy latest/custom selector.',
   'v1-legacy-primary-resolver':'Explorer: repair resolver, add ETH only when absent, then set Mainnet reverse only when needed. Manager verifies the resulting primary name.',
   'v1-legacy-encrypted-primary':'Hashed-label Edit records rejects the bracketed label. Open the known plaintext form of the same node, edit ETH, then enter it in Mainnet reverse settings. Verify in Manager.',
   'v1-legacy-profile-display':'Use Manager for the profile and Explorer Records/Edit records for the full legacy record set; see exact per-case assertions.',
   'v1-legacy-renew-dates':'Explorer address Names → select → Extend. Stablecoin quote replaces historic mocked ETH/fiat amounts. Registrar expiry verifies the selected duration.',
   'v1-legacy-bulk-renew':'Explorer address Names → select the exact group → Extend. Verify every registrar expiry; current V1 stablecoin renewer replaces legacy controller selection.',
   'v1-legacy-transaction-history':'Transaction overview and Done replace the old modal/toast; Explorer address History supplies confirmed transaction history.',
   'v1-legacy-advanced-editor':'Close the unstarted transaction overview and return to pending record edits, then save again; chain records verify persistence.',
   'v1-legacy-metamask-actions':'Actual isolated MetaMask extension against the local fork. Explorer address Names → Extend or parent Subnames replaces the legacy entry point.',
  }
  for filename,steps in adaptations.items():
   if filename in row['file']: out.update(status='Pass with workaround',workaround_steps=steps)
 if any(x in row['file'] for x in ('v1-legacy-desync','v1-legacy-primary-resolver','v1-legacy-encrypted-primary','v1-legacy-profile-display','v1-legacy-custom-rpc','v1-legacy-renew-links','v1-legacy-authorization','v1-legacy-transaction-history')): out['actual_surface']='Explorer + Manager'
 if 'v1-legacy-address-errors' in row['file']: out['actual_surface']='Manager'
 if 'v1-legacy-name-list' in row['file'] or match[1]=='L308': out['actual_surface']='Manager'
 if row['actual']=='passed':
  refresh_tags={'delayed-refresh-workaround','record-refresh-workaround','resolver-key-refresh'}
  if refresh_tags & {a.get('name') for a in row['attachments']}:
   out['status']='Pass with workaround'
   out['workaround_steps'] += ' The immediate page had stale data: wait 65 seconds after indexer catch-up and reload before continuing. The final UI and chain assertions passed after this delay.'
 if row['actual']=='passed' and match[1]=='L274': out['workaround_steps']='Explorer shows the real manager-handover/owner-transfer plan and visible Done completion instead of the legacy mock transaction and toast. Both on-chain ownership and the exact transfer receipt are verified.'
 if match[1]=='L036': out['workaround_steps']='Explorer creation does not include a profile wizard. Open the created child Records page to verify the empty profile.'
# Link exact outcomes to the findings; related suites never establish these links.
finding_cases = {
 'G02': ['L040','L043','L045','L046','L192','L198'],
 'G03': ['L264'], 'G05': ['L094','L174','L175','L176'],
 'G10': ['L057','L058','L059','L061','L063','L187','L206','L208','L212','L220'],
 'G14': ['L034','L035'], 'G15': ['L037'],
 'G16': ['L288','L289','L290','L291','L292','L293','L294','L296','L297','L299','L301','L303','L304'],
 'G17': ['L189','L193','L194'],
 'G20': ['L088','L092','L095','L098','L102','L106','L110','L114','L118','L122','L126','L130','L134','L136'], 'G19': ['L071','L073','L074','L075','L079'],
 'G21': ['L026'], 'G22': ['L101','L105'], 'G23': ['L025','L203'],
 'G24': ['L201','L232','L233'], 'G25': ['L062','L064','L306','L307'],
 'G26': ['L065','L068','L069','L070'], 'G27': ['L202','L204'], 'G28': ['L214'], 'G29': ['L280'], 'G30': ['L281'], 'G31': ['L050','L051','L052','L053','L054','L055'], 'G32': ['L284','L285'], 'G33': ['L231'], 'G34': ['L270'], 'G35': ['L221','L225'], 'G36': ['L276','L277','L278'],
}
for finding, ids in finding_cases.items():
 for case in d['tests']:
  out = case['results']['v1']
  if case['id'] in ids and out['status'] in ('Fail','Pass with workaround'):
   existing = [x.strip() for x in out.get('issue','').split(',') if x.strip()]
   if finding not in existing: existing.append(finding)
   out['issue'] = ', '.join(existing)
if (R/'indexer-history-blocker.json').exists():
 d['execution']['environment_blocker']=json.loads((R/'indexer-history-blocker.json').read_text())
 for case in d['tests']:
  if case['id'] in ('L031','L032','L036') and not any(r['batch'].startswith('fullhistory-') and (' > '+case['id']+' ') in r['title'] and r['actual'] in ('passed','failed','timedOut') for r in rows):
   out=case['results']['v1']
   out.update(status='Blocked environment',actual_result='V1 child creation succeeds, but the local indexer lacks root .eth history and incorrectly hides descendant records.',evidence=str(R/'indexer-history-blocker.json'),decision_reason='UniversalResolver succeeds while the indexer returns ens_v2_path_no_resolver. Full-history indexer retest required.')

if (R/'chain-oom-blocker.json').exists():
 d['execution']['chain_blocker']=json.loads((R/'chain-oom-blocker.json').read_text())
 d['execution']['status']='Blocked: local chain killed for memory; scope incomplete'
 for row in latest.values():
  match=re.search(r' > (L\d{3}) ',row['title'])
  if row.get('blocker') and match:
   case=next((c for c in d['tests'] if c['id']==match[1]),None)
   if case:
    case['results']['v1'].update(status='Blocked environment', actual_result='The chain became unavailable before this case could complete; Docker confirms Anvil was OOM-killed.', evidence=row['report'], decision_reason='Rebuild a consistent test environment and rerun. This is not an app failure.')

if (R/'rebuild/status.json').exists():
 d['execution']['rebuild']=json.loads((R/'rebuild/status.json').read_text())
 d['execution']['status']=d['execution']['rebuild']['status']
for reg in d['regressions']:
 if reg['id']=='REG-02':
  reg['verified_subcases']=[r for r in rows if 'REG-02 ' in r['title']]
  reg['execution_note']='Fresh split-owner migration with retained manager, denial of record editing, and Explorer resolver-replacement recovery. Empty profile only; preservation of existing records and owner-granted resolver roles are separate unverified variants.'
 if reg['id']=='REG-01':
  reg['verified_subcases']=[r for r in rows if r['batch']=='rebased-split-transfer']
  reg['execution_note']='F28 checks split registrant/controller transfer and both resulting addresses. Rejection/resumption and both-app variations remain unverified.'
 if reg['id']=='REG-03':
  reg['verified_subcases']=[r for r in rows if 'REG-03 ' in r['title']]
  reg['execution_note']='Wrapped and unwrapped V1 roots create children and grandchildren in Explorer, then read grandchild records in both apps. Transfer and deletion variants remain separate and unverified.'
 if reg['id']=='REG-05':
  reg['verified_subcases']=[r for r in rows if 'REG-05 ' in r['title']]
  reg['execution_note']='Unmigrated wrapped and unwrapped V1 names: observe Manager candidate availability, set Mainnet reverse resolution in Explorer, then verify UniversalResolver and Manager dashboard. Other primary-name variants remain unverified.'
 if reg['id']=='REG-04':
  reg['verified_subcases']=[r for r in rows if 'REG-04 ' in r['title']]
  reg['execution_note']='Wrapped and unwrapped v1 records via Explorer → Manager are tested separately. The broader zero/outdated/custom/unauthorized resolver repair matrix is not thereby certified.'

if (R/'continuous-scope.json').exists():
 scope_ids={x['id'] for x in json.loads((R/'continuous-scope.json').read_text())}
 scope_cases=[c for c in d['tests'] if c['id'] in scope_ids]
 scope_counts=dict(Counter(c['results']['v1']['status'] for c in scope_cases))
 completed=[dict(id=c['id'],title=c['legacy_title'],result=c['results']['v1']) for c in scope_cases if c['results']['v1']['status']!='Not run']
 remaining=[dict(id=c['id'],title=c['legacy_title'],file=c['legacy_file']) for c in scope_cases if c['results']['v1']['status']=='Not run']
 finished=(R/'continuation-complete.json').exists()
 if finished: d['execution']['status']='Execution finished; recorded gaps and Safe fixture blocker remain'
 continuation=dict(summary=('Final outcomes for the requested 227 legacy cases: ' if finished else 'Continuous execution of the remaining 227 legacy cases: ')+', '.join(str(v)+' '+k for k,v in scope_counts.items())+'. Stateful and DNS excluded. '+('Failures are unresolved parity checks, including behavior differences requiring a product decision; blocked cases are unverified, not passes. See each case for workarounds and evidence.' if finished else 'Running batch results appear after each batch finishes.'),counts=scope_counts,cases=completed,remaining=remaining,remaining_count=len(remaining))
 (R/'legacy-continuation-summary.json').write_text(json.dumps(continuation,indent=2))
ledger.write_text(json.dumps(d,indent=2)+'\n')
e=html.escape
blocker=d['execution'].get('environment_blocker',{})
blocker_html='<h2>Missing indexer history</h2><p>'+e(blocker.get('diagnosis',''))+'</p><p>'+e(blocker.get('required_retest',''))+'</p>' if blocker else ''
if d['execution'].get('chain_blocker'):
 cb=d['execution']['chain_blocker']
 blocker_html='<h2>Execution stopped: local chain unavailable</h2><p>'+e(cb['diagnosis'])+'</p><p>'+e(cb['required_retest'])+'</p><p><a href="chain-oom-blocker.json">Docker evidence</a></p>'+blocker_html
exact=[c for c in d['tests'] if c['scope']=='In scope' and c['results']['v1']['tester']=='Automated Playwright parity port']
exact_html='<h2>Direct legacy ports — V1 lane</h2><ul>'+''.join('<li id="case-'+e(c['id'])+'"><b>'+e(c['id'])+' — '+e(c['results']['v1']['status'])+'</b>: '+e(c['legacy_title'])+'</li>' for c in exact)+'</ul><p>Other legacy lanes remain unverified unless their ledger records a separate result. Outcomes include failures and unverified cases; this is not replacement sign-off.</p>'
# Build the finding-to-failure view from final ledger outcomes, never historical reruns.
failed_cases=[c for c in d['tests'] if c['scope']=='In scope' and c['results']['v1']['status']=='Fail']
continuation_ids={c['id'] for c in json.loads((R/'continuous-scope.json').read_text())}
failed_by_finding={}
for c in failed_cases:
 ids=[x.strip() for x in c['results']['v1'].get('issue','').split(',') if x.strip()]
 assert ids, 'Failed case without a finding: '+c['id']
 for fid in ids: failed_by_finding.setdefault(fid,[]).append(c)
finding_lookup={f['id']:f for f in d['findings']}
assert set(failed_by_finding)<=set(finding_lookup), 'Unknown finding reference'
mapping_rows=[]
for fid,cases in sorted(failed_by_finding.items()):
 f=finding_lookup[fid]
 links=' · '.join('<a href="#case-'+e(c['id'])+'">'+e(c['id'])+'</a>' for c in cases)
 details=''.join('<li><b>'+e(c['id'])+' — '+e(c['legacy_title'])+'</b><p>'+e(c['results']['v1'].get('failed_step') or c['results']['v1'].get('actual_result',''))+'</p><a href="'+e(c['results']['v1'].get('evidence',''))+'">Execution evidence</a></li>' for c in cases)
 mapping_rows.append('<tr><td><b>'+e(fid)+' — '+e(f['title'])+'</b><p>'+e(f.get('priority',''))+'</p>'+('<p><b>'+('<a href="'+e(f['tracking_url'])+'">'+e(f['tracking_status'])+'</a>' if f.get('tracking_url') else e(f['tracking_status']))+'</b></p>' if f.get('tracking_status') else '')+'</td><td>'+str(len(cases))+'</td><td>'+str(sum(c['id'] in continuation_ids for c in cases))+'</td><td>'+links+'<details><summary>Test titles, failed steps and evidence</summary><ul>'+details+'</ul></details></td></tr>')
mapping_html='<section id="finding-failed-tests"><h2>Findings → failed legacy test cases</h2><p>'+str(len(failed_cases))+' distinct failed cases across '+str(len(failed_by_finding))+' findings; '+str(sum(c['id'] in continuation_ids for c in failed_cases))+' are from the latest 227-case continuation. Includes earlier failures. Stateful and DNS tests are excluded. Passed, workaround, blocked and not-applicable outcomes are not counted here. Expand a row for original test titles, failed steps and evidence.</p><table class="failure-map"><thead><tr><th>Finding</th><th>All failed</th><th>Latest 227</th><th>Failed legacy cases</th></tr></thead><tbody>'+''.join(mapping_rows)+'</tbody></table></section>'
lane_counts=dict(Counter(c['results']['v1']['status'] for c in d['tests'] if c['scope']=='In scope'))
summary_html='<h2>Exact legacy V1 ledger</h2><p>'+e(' · '.join(k+': '+str(v) for k,v in lane_counts.items()))+'</p><p>Application and harness checks above include related coverage; they do not imply exact legacy parity. V2 adaptations remain separate.</p>'
if d['execution'].get('rebuild'):
 rebuild=d['execution']['rebuild']
 summary_html='<h2>Environment rebuild</h2><p>'+e(rebuild['status'])+'</p><p>'+e(rebuild.get('detail',''))+'</p>'+summary_html
 blocker_html='<details><summary>Previous environment failures (historical evidence)</summary>'+blocker_html+'</details>'
body=''.join(f'<tr><td>{e(r["batch"])}</td><td>{e(r["verdict"])}</td><td>{e(r["title"])}<details><summary>Evidence</summary><p>{e(str(r["file"]))}:{r["line"]}</p><p>Expected {e(r["expected"])}, actual {e(r["actual"])}</p><pre>{e(r["error"])}</pre><a href="{e(r["report"])}">Full result JSON</a>'+''.join(f'<p><a href="{e(a["path"])}">{e(a["name"])}</a></p>' for a in r['attachments'] if 'path' in a)+'</details></td></tr>' for r in sorted(latest.values(), key=lambda r:r['started_at'], reverse=True))
pending = json.loads((R/'remaining-batches.json').read_text()) if (R/'remaining-batches.json').exists() else []
pending_html = '<details><summary>Saved execution queues</summary><p>These are reproducible command lists, not a list of unexecuted tests. Current remaining cases are listed in the continuation results.</p><p><a href="continuation-next-batches.json">Continuation batches</a> · <a href="continuation-final-rechecks.json">Corrected and recovery reruns</a> · <a href="rebuild/final-health.json">Environment health</a></p></details>'
findings_summary='<h2>Current findings</h2><ul>'+''.join('<li><b>'+e(f['id']+' — '+f['title'])+'</b> ('+e(f['kind'])+'). '+e(f['detail'])+'</li>' for f in d['findings'] if f['id'] in ('G01','G02','G03','G05','G08','G10','G11','G12','G13','G14','G15','G16','G17','G18','G19','G20','G21','G22','G23','G24','G25','G26','G27','G28','G29','G30','G31','G32','G33','G34','G35','G36'))+'</ul>'
continuation_html=''
if (R/'legacy-continuation-summary.json').exists():
 continuation=json.loads((R/'legacy-continuation-summary.json').read_text())
 continuation_html='<h2>Latest exact legacy continuation</h2><p>'+e(continuation['summary'])+'</p><p><a href="legacy-continuation-summary.json">Case results and remaining scope</a></p>'
resumed_html = '<h2>Earlier October 22 resumed execution</h2><p><b>40 passed · 1 failed</b> across 41 unique checks from the nine saved batches, after correcting test setup and selectors. All queued batches finished. The transfer-rejection failure remains open. <a href="resumed-summary.json">Per-check results</a>. This does not complete the full legacy ledger.</p>' if (R/'resumed-summary.json').exists() else ''
page=f'''<!doctype html><meta charset="utf-8"><title>ENS replacement execution</title><style>body{{font:16px system-ui;margin:40px;color:#18332d;background:#fafbf8}}table{{border-collapse:collapse;width:100%}}td,th{{padding:14px;border-bottom:1px solid #ccd5ce;text-align:left;vertical-align:top}}td:nth-child(1){{width:18%}}td:nth-child(2){{width:18%}}.failure-map td:nth-child(1){{width:33%}}.failure-map td:nth-child(2),.failure-map td:nth-child(3){{width:7%}}.failure-map td:nth-child(4){{width:53%}}.failure-map details{{margin-top:12px}}.failure-map li{{margin-bottom:16px}}:target{{background:#fff2c6}}pre{{white-space:pre-wrap;font-size:12px}}h1{{font-size:32px}}a{{color:#126653}}</style><h1>ENS replacement execution</h1><p><a href="V1 ownership test report.html">V1 ownership testing report — actions before migration and preservation afterward</a></p><p><a href="roles-audit/Roles and migration audit.html">Owner, manager and subname migration audit — active and grace-period names</a></p><p>Branch <b>test/ens-manager-replacement-parity</b>, rebased baseline 081dff188 on main 279c31002; test commit {e(TEST_COMMIT)}. Local test chain 11155111.</p><p>Scope: 294 active legacy rows. 18 stateful tests excluded; DNS deferred. This is an execution log, not replacement sign-off. Related tests do not certify the original assertions. No legacy row is marked passed merely because a related test passes.</p>{continuation_html}{mapping_html}<details><summary>Broader application checks and historical reruns</summary><p><b>Latest unique checks:</b> {' · '.join(e(k)+': '+str(v) for k,v in unique_counts.items())}</p><p>All executions: {e(str(counts))}</p></details>{resumed_html}{summary_html}{findings_summary}{pending_html}{blocker_html}{exact_html}<p><a href="../ENS replacement test plan.html">Original case-by-case ledger</a></p><h2>Latest result for each check</h2><p>Earlier executions are retained in the ledger JSON and batch result files.</p><table><tr><th>Batch</th><th>Outcome</th><th>Test / evidence</th></tr>{body}</table>'''
(R/'Execution results.html').write_text(page)
p=R.parent/'ENS replacement test plan.html'
s=p.read_text(); marker='<section id="execution-results"><h2>Execution evidence</h2><p><a href="execution/Execution results.html">Open executed tests, failures and evidence</a>. Running related coverage does not certify one-to-one legacy parity.</p></section>'
s=re.sub(r'<section id="execution-results">.*?</section>','',s,flags=re.S)
s=s.replace('<section id="gate">',marker+'<section id="gate">')
findings='<section id="findings"><h2>Findings and revalidation</h2><p>Current observations below supersede the planning snapshot. Source restrictions and environment blockers are not runtime-confirmed product failures.</p>'+''.join('<article class="finding"><div class="eyebrow">'+e(f['id']+' · '+f['priority']+' · '+f['kind'])+'</div><h3>'+e(f['title'])+'</h3><p>'+e(f['detail'])+'</p><p><b>Next:</b> '+e(f['recovery'])+'</p><p class="source"><a href="/Users/sg/ens/worktrees/ens-manager-replacement-parity/'+e(f['source'])+'">'+e(f['source'])+':'+str(f['line'])+'</a></p></article>' for f in d['findings'])+'</section>'
s=re.sub(r'<section id="findings">.*?</section>',lambda m:findings,s,flags=re.S)
s=s.replace('Execution is in progress; see the execution evidence and updated lane outcomes.','Execution is blocked by the local chain being killed for memory. See the execution evidence and updated lane outcomes; the plan has not been completed.')
s=re.sub(r'(<script[^>]*id="data"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(d).replace('</','<\\/')+m[2],s,flags=re.S)
if d['execution'].get('rebuild'):
 s=s.replace('Execution is blocked by the local chain being killed for memory. See the execution evidence and updated lane outcomes; the plan has not been completed.', 'Execution resumed with a full-history environment rebuild. See current execution evidence; the plan has not been completed.')
if (R/'continuation-complete.json').exists():
 s=s.replace('Execution resumed with a full-history environment rebuild. See current execution evidence; the plan has not been completed.', 'The requested non-stateful, non-DNS continuation has finished. See the execution report for passes, workarounds, gaps and the unverified Safe integration.')
p.write_text(s)
print(counts)
