import os,json,subprocess,time,urllib.request
from pathlib import Path
R=Path(__file__).resolve().parent
C=Path('/Users/sg/ens/worktrees/ens-manager-replacement-parity/e2e')
NODE='/Users/sg/.nvm/versions/node/v24.13.1/bin/node'
ROOT='0xb458d6a3a77919449d03e7a6903c26827c1ec43f'
def rpc(method,params=[]):
 req=urllib.request.Request('http://127.0.0.1:8545',json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),{'Content-Type':'application/json'})
 return json.load(urllib.request.urlopen(req,timeout=10))['result']
def index():
 return json.load(urllib.request.urlopen('http://127.0.0.1:5660/v1/status',timeout=10))
def root_count():
 return int(subprocess.check_output(['docker','exec','infra-bigname-postgres-1','psql','-U','bigname','-d','bigname','-tAc',f"SELECT count(*) FROM bigname_phase.project_ens_v2_entry_owner WHERE registry='{ROOT}' AND entry_key='0x4f5b812789fc606be1b3b16908db13fc7a9adf7ca72641f84d75b47000000000' AND status='registered'"],stderr=subprocess.DEVNULL,text=True).strip())
print('Waiting for full-history index and root-registry entry',flush=True)
started=time.time()
while True:
 try:
  head=int(rpc('eth_blockNumber'),16);status=index();indexed=status['data']['chains']['11155111'].get('indexed_block') or 0
  if indexed>=head and root_count()>0:break
 except Exception:pass
 if time.time()-started>14400:raise RuntimeError('Full-history validation did not finish within 4 hours')
 time.sleep(10)
meta={'status':'Full-history environment validated; remaining tests running','detail':'48 GiB OrbStack limit; indexer starts at block 11820280. Root registry history is present and published head has caught up. Stateful and DNS excluded.','head':head,'indexed':indexed,'root_rows':root_count(),'docker_memory_bytes':int(subprocess.check_output(['docker','info','--format','{{.MemTotal}}'],text=True)),'validated_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
(R/'rebuild/status.json').write_text(json.dumps(meta,indent=2))
(R/'rebuild/validated-index.json').write_text(json.dumps(status,indent=2))
subprocess.run(['python3',str(R/'update-report.py')],check=True)
portal=['--config','projects/portal/playwright.config.ts','--project=portal-e2e','--no-deps']
manager=['--config','projects/manager/playwright.config.ts','--project=manager-e2e','--no-deps']
batches=[
 ('portal-harness',['--config','projects/portal/playwright.config.ts','--project=harness']),
 ('manager-harness',['--config','projects/manager/playwright.config.ts','--project=harness-manager']),
 ('parity',['--config','projects/parity/playwright.config.ts']),
 ('manager-core',manager+['--grep-invert','sets the newly registered name as primary after a successful registration|[Dd][Nn][Ss]']),
 ('portal-transfer-remaining',portal+['transfer.spec.ts','--grep-invert','unmigrated V1 names|[Dd][Nn][Ss]']),
 ('portal-renewal-recheck',portal+['roles.spec.ts','--grep','suppresses every privilege|raises nothing for a fully privileged']),
 ('cross-app',['--config','projects/cross-app/playwright.config.ts','--grep-invert','[Dd][Nn][Ss]']),
 ('portal-additional',portal+['history.spec.ts','registration.spec.ts','migrated-fuses.spec.ts','--grep-invert','[Dd][Nn][Ss]']),
 ('migration',['--config','projects/manager/playwright.migration.config.ts','--project=manager-migration','--no-deps','--grep-invert','[Dd][Nn][Ss]']),
]
for name,args in batches:
 rpc('eth_chainId')
 stem='fullhistory-'+name
 env={**os.environ,'E2E_MOCK_BIGNAME':'false','E2E_MOCK_INDEXER':'false','E2E_EXPLORER_INDEXER':'bigname','PLAYWRIGHT_JSON_OUTPUT_NAME':str(R/(stem+'.json'))}
 cmd=[NODE,'node_modules/@playwright/test/cli.js','test',*args,'--workers=1','--reporter=list,json','--output='+str(R/(stem+'-artifacts'))]
 print('Starting '+stem,flush=True)
 with (R/(stem+'.log')).open('w') as log:
  proc=subprocess.Popen(cmd,cwd=C,env=env,stdout=log,stderr=subprocess.STDOUT)
  while proc.poll() is None:
   time.sleep(10)
   state=json.loads(subprocess.check_output(['docker','inspect','infra-anvil-1']))[0]['State']
   if not state['Running']:
    proc.send_signal(2);proc.wait(timeout=30)
    raise RuntimeError('Chain stopped; batch interrupted to preserve evidence')
 result=proc.returncode
 print('Finished '+stem+' exit '+str(result),flush=True)
 subprocess.run(['python3',str(R/'update-report.py')],check=True)
 if 'harness' in name and result:raise RuntimeError('Harness gate failed; investigate before continuing')
print('All scheduled full-history batches finished',flush=True)
