"""Add current retention evidence without overwriting historical or priority checks."""
from pathlib import Path
import html, json

ROOT = Path(__file__).resolve().parent
DIRECTORY = 'retention-continuation-20261026'
FIELDS = ['continuation_result', 'continuation_before_result', 'continuation_after_result',
          'continuation_records_result', 'continuation_permissions_result', 'continuation_activity_result',
          'continuation_checks', 'continuation_findings', 'continuation_workaround',
          'continuation_evidence', 'continuation_commit', 'continuation_scope']

def load():
    p = ROOT / DIRECTORY / 'results.json'
    return json.loads(p.read_text()) if p.exists() else None

def merge(execution, data):
    if not data: return
    for aid, r in execution['rows'].items():
        excluded = r['overall_result'].startswith('EXCLUDED')
        for field in FIELDS: r[field] = ('EXCLUDED — 4LD' if excluded else 'NOT RUN') if field.endswith('_result') else ''
        d = data['rows'].get(aid)
        if not d or excluded: continue
        r['continuation_result'] = d['result'] + '; remaining row coverage incomplete'
        for group, value in d['results'].items(): r[f'continuation_{group}_result'] = value
        r['continuation_checks'] = '\n'.join(f'{c["group"]}: {c["check"]} — {c["result"]}' for c in d['checks'])
        r['continuation_findings'] = 'Accepted: ' + (', '.join(d['accepted_findings']) or 'none matched') + '; New: ' + (', '.join(d.get('new_findings', [])) or 'none identified') + f'; {len(d["untriaged_failures"])} failed assertions awaiting classification'
        r['continuation_workaround'] = ' '.join(d['workarounds'])
        r['continuation_evidence'] = '; '.join(d['sources'])
        r['continuation_commit'] = data['candidate_commit']
        r['continuation_scope'] = d.get('migration_scope', 'Named assertion scope only; no whole-row completion.')
        r['overall_result'] = 'FAIL — retention continuation; row incomplete' if d['result'].startswith('FAIL') else 'PARTIAL — retention continuation; previous failures retained'
    execution['metadata'].update(status='IN PROGRESS — retention continuation; full 2LD/3LD matrix incomplete', retention_continuation_candidate=data['candidate_commit'], retention_continuation_wallets=len(data['rows']), retention_continuation_jobs=data['job_status_counts'], retention_continuation_ledger=DIRECTORY + '/results.json')
    execution['metadata'].pop('retention_infrastructure', None)
    if data.get('infrastructure'):
        execution['metadata'].update(status=data['infrastructure']['status'] + '; full 2LD/3LD matrix incomplete', retention_infrastructure=data['infrastructure'])

def panel(data, prefix='', config=None):
    if not data: return ''
    if config and not any(aid.startswith(config + '-A') for aid in data['rows']): return ''
    e = lambda v: html.escape(str(v))
    counts = ' · '.join(f'{value} {key.lower()}' for key, value in data['job_status_counts'].items())
    issue = data.get('infrastructure')
    status = '<b>' + e(issue['status']) + '.</b> ' + e(issue['reason']) + '<br>' if issue else '<b>In progress.</b> '
    return '<section id="retention-latest" style="background:white;border:2px solid #7dada0;border-radius:8px;padding:20px;margin-bottom:20px"><h2>Record, permission and activity retention — current execution</h2><p>' + status + e(counts) + '. Each queued workflow can contain several wallets and many assertions; these are not counts of unique assertions.</p><p>Actual completed checks now map to ' + str(len(data['rows'])) + ' wallet rows on <code>' + e(data['candidate_commit'][:12]) + '</code>. PASS applies only to the named checks. Failed assertions remain failed, including accepted findings; blocked and unexecuted checks remain unverified.</p><p><a href="' + prefix + DIRECTORY + '/Retention%20continuation%20results.html">Detailed before/after results, gaps and workarounds</a> · <a href="' + prefix + DIRECTORY + '/queue.json">Remaining workflow queue</a></p><p>DNS, stateful suites and all 4LDs are excluded. The older PR-approval and historical campaign evidence below is preserved.</p></section>'
