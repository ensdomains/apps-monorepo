"""Reconcile completed follow-up evidence with exact full-matrix wallet rows."""
from pathlib import Path
from collections import Counter
import hashlib
import json

ROOT = Path(__file__).resolve().parent
P = ROOT / '2ld-3ld-priority'
source = json.loads((P / 'results.json').read_text())
flat = json.loads((ROOT / 'flattened-matrix.json').read_text())
wallets = {(r['config_id'], r['actor']): r for r in flat['rows']}
findings = json.loads((P / 'new-findings.json').read_text())['findings']
accepted = json.loads((ROOT / 'pr-approval-36/accepted-findings.json').read_text())

# These are evidence mappings, not inferred passes for all actors in a fixture.
mapping = {}
for cfg in ['CFG-0015', 'CFG-0711']:
    for actor in ['W2', 'W1', 'Unrelated']:
        mapping[f'control-{cfg}-{actor}'] = {
            'config': cfg, 'stage': 'S2 — after migration', 'families': ['P-04', 'P-08'],
            'actors': {actor: 'Explorer: child deletion ' + ('denied; registration unchanged.' if actor == 'Unrelated' else 'submitted successfully; parent records and original child resolver storage preserved.')},
            'limit': 'Only the named wallet’s Explorer deletion route. Deletion deliberately removes the V2 child; stored V1 values are not proof of continued public resolution after deletion.'}
mapping['retained-manager-revoke'] = {
    'config': 'CFG-0003', 'stage': 'S2 — independent permission revocation', 'families': ['P-02', 'P-06', 'P-08'],
    'actors': {'W1': 'Owner revokes resolver-record and registry Set Resolver grants independently, then still writes successfully.',
               'W2': 'Retained manager loses only the revoked access; actual record/resolver-change transactions revert after the respective revocations. Fresh Manager and Explorer editors deny access.'},
    'limit': 'Named grant/revoke transactions, authorization checks and editor access only; not every setter or delegation route.'}
for suffix, cfg in [('unwrapped', 'CFG-0015'), ('unlocked', 'CFG-0711')]:
    mapping['parent-reclaim-' + suffix] = {
        'config': cfg, 'stage': 'S2 — reclaim and re-registration', 'families': ['P-02', 'P-04', 'P-06'],
        'actors': {'W1': 'Parent unregisters W2’s child and registers the label to W3; all parent and child values remain exact.',
                   'W2': 'Child holder grants then revokes an operator role. Former holder has zero token roles after re-registration; its actual Set Resolver transaction reverts.',
                   'Operator': 'Revoked Set Resolver grant stays revoked after re-registration; actual transaction reverts.',
                   'Unrelated': 'Actual unregister and Set Resolver transactions revert.'},
        'limit': 'Reclaim/re-register and authorization tests are direct contract transactions, not Explorer workflows. W3 is a new holder introduced by this scenario, not a new baseline matrix row. V2 role cleanup does not prove revocation inside the retained V1 resolver.'}
for case in ['import-cancel-review', 'import-reject-first', 'import-reject-after-setup']:
    mapping[case] = {
        'config': 'CFG-0015', 'stage': 'S4 — optional resolver copy and replacement', 'families': ['T-07'],
        'actors': {'W2': 'Child holder cancels/rejects the specified resolver-copy step, then completes a fresh or resumed publish. Original pointer and seven supported values survive interruption; all seven match after replacement.'},
        'limit': 'Seven-record supported bundle only; no additional ABI-format credit. Rejection after one completed transaction does not imply that transaction was a deployment. Earlier setup/transport failures remain preserved; the final fresh attempt supplies the result.'}
for case, family in [('record-before-submit', 'T-05'), ('record-at-signing', 'T-06')]:
    mapping[case] = {
        'config': 'CFG-0003', 'stage': 'Final review → wallet submission', 'families': [family],
        'actors': {'W1': 'Owner migration proceeds without a fresh review and publishes the older reviewed description.',
                   'W2': 'Manager’s newer V1 description remains stored at the original resolver but is not the public value after migration.'},
        'limit': 'MIGRATION-SOURCE-01 failure for the named timing boundary. Other 17 record values match. No recovery was executed and later mempool/inclusion races were not tested.'}
mapping['child-owner-at-signing'] = {
    'config': 'CFG-0015', 'stage': 'Final review → wallet submission', 'families': ['T-06'],
    'actors': {'W1': 'Parent migration continues without fresh review and recreates the child under the previously reviewed W2.',
               'W2': 'Source child controller transfers to W3 while the request waits, but V2 ownership is recreated under W2.'},
    'limit': 'W3 is introduced by the source transfer, not a baseline wallet row. Parent and child each retain all 18 record values; failure concerns fresh review and ownership, not record loss.'}
mapping['child-added-at-signing'] = {
    'config': 'CFG-0035', 'stage': 'Final review → wallet submission', 'families': ['T-06'],
    'actors': {'W1': 'Parent migration uses the old inventory without fresh review; the later direct child is not recreated.',
               'W2': 'Separate parent manager adds a direct child after review; the reviewed discovery inventory intentionally remains unchanged.',
               'W3': 'Existing child controller also receives the added V1 child. Existing child migrates; added child has no V2 registration and 17 populated public values no longer match.'},
    'limit': 'All 18 added-child source values remain in V1 storage. One matching empty value does not prove resolution. This is a seeded stale-inventory scenario, not a measurement of live indexer latency.'}
mapping['destination-conflict'] = {
    'config': 'CFG-0015', 'stage': 'Before migration — destination conflict', 'families': ['T-05'],
    'actors': {'W1': 'Manager blocks Upgrade with no pending wallet request and preserves source/destination state, but shows a generic preparation error instead of the conflict.'},
    'limit': 'Safety PASS; explanation FAIL. Existing destination child belongs to W3. This pre-existing destination-registry fixture does not cover every partial migration, atomic failure or recovery path.'}

assert set(mapping) == {r['id'] for r in source['rows']}
assert source['counts'] == {'PASS': 12, 'FAIL': 5}
rows = []
for r in source['rows']:
    m = mapping[r['id']]
    raw_path = P / r['source']
    raw = json.loads(raw_path.read_text())
    assert raw.get('completedAt') and m['config'] in raw['configurations']
    assert bool(raw.get('assertionErrors') or raw.get('error')) == (r['result'] == 'FAIL'), r['id']
    for actor in m['actors']:
        baseline = wallets[m['config'], actor]
        assert baseline['level'] in ['2LD', '3LD']
    checks = [{'check': k, 'result': v['result']} for k, v in r['checks'].items()]
    assert all(c['result'] in ['PASS', 'FAIL'] for c in checks)
    assert any(c['result'] == 'FAIL' for c in checks) == (r['result'] == 'FAIL')
    row = {k: r[k] for k in ['id', 'title', 'group', 'initial', 'action', 'expected', 'result', 'summary', 'workaround', 'completedAt']}
    row.update(config_id=m['config'], level=wallets[m['config'], next(iter(m['actors']))]['level'],
               candidate_commit=source['candidate'], stage=m['stage'], family_ids=m['families'],
               checks=checks, limit=m['limit'], activity_result='NOT RUN — this follow-up does not verify indexed history',
               evidence=str(raw_path.relative_to(ROOT)), evidence_sha256=hashlib.sha256(raw_path.read_bytes()).hexdigest(),
               report='2ld-3ld-priority/2LD and 3LD priority results.html#' + r['id'],
               previous_evidence=['2ld-3ld-priority/' + p for p in ([r['previousEvidence']] if r.get('previousEvidence') else []) + r.get('extraAttempts', [])],
               finding_ids=[f['id'] for f in findings if r['id'] in f['cases']],
               wallet_mappings=[{'case_id': wallets[m['config'], actor]['case_id'], 'actor': actor, 'observed': detail,
                                 'result_scope': 'Linked scenario result; only the named wallet observations are credited, not all actions or all assertions.'}
                                for actor, detail in m['actors'].items()])
    rows.append(row)
ledger = {'title': 'Full-matrix integration of the 17 focused 2LD/3LD scenarios',
          'candidate_commit': source['candidate'], 'historical_candidate_commit': flat['metadata']['candidate_commit'],
          'source': '2ld-3ld-priority/results.json',
          'source_sha256': hashlib.sha256((P / 'results.json').read_bytes()).hexdigest(),
          'scenario_counts': dict(Counter(r['result'] for r in rows)),
          'scenario_count': len(rows), 'configuration_ids': sorted({r['config_id'] for r in rows}),
          'wallet_row_count': len({w['case_id'] for r in rows for w in r['wallet_mappings']}),
          'excluded': ['DNS', 'legacy stateful suites', 'all 4LD'],
          'excluded_configuration_ids': sorted({r['config_id'] for r in flat['rows'] if r['level'] == '4LD'}),
          'counting_rule': 'Count scenario IDs once. Actor mappings and individual assertions are not additional scenarios. No whole configuration or wallet row is newly complete.',
          'accepted_basis': accepted['basis'],
          'accepted_findings': [{'id': f['id'], 'title': f['title']} for f in accepted['findings']],
          'new_findings': findings, 'rows': rows}
(ROOT / 'execution/priority-integration.json').write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: ledger[k] for k in ['scenario_counts', 'configuration_ids', 'wallet_row_count']}))
