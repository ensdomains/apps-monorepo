"""Shared, evidence-scoped integration for the full matrix and campaign pages."""
from pathlib import Path
import hashlib
import html
import json
from collections import Counter
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent
FIELDS = ['historical_result', 'followup_result', 'followup_commit', 'followup_scenarios',
          'followup_checks', 'followup_gaps', 'followup_evidence', 'coverage_scope']

def load():
    path = ROOT / 'execution/priority-integration.json'
    if not path.exists():
        return None
    data = json.loads(path.read_text())
    assert hashlib.sha256((ROOT / data['source']).read_bytes()).hexdigest() == data['source_sha256'], 'Refresh the integration ledger after changing priority results.'
    for row in data['rows']:
        assert hashlib.sha256((ROOT / row['evidence']).read_bytes()).hexdigest() == row['evidence_sha256'], row['id']
    return data

def merge(result, data):
    if not data:
        return
    by_wallet = {}
    for scenario in data['rows']:
        for wallet in scenario['wallet_mappings']:
            by_wallet.setdefault(wallet['case_id'], []).append((scenario, wallet))
    for aid, row in result['rows'].items():
        historical = row.get('historical_result', row['overall_result'])
        row.update(historical_result=historical, overall_result=historical,
                   followup_result='NOT RUN — in this follow-up', followup_commit='',
                   followup_scenarios='', followup_checks='', followup_gaps='', followup_evidence='',
                   coverage_scope='Earlier campaign evidence only; this follow-up adds no result for this wallet.')
        if aid.rsplit('-A', 1)[0] in data['excluded_configuration_ids']:
            row.update(overall_result='EXCLUDED — 4LD; historical evidence retained',
                       followup_result='EXCLUDED — 4LD',
                       coverage_scope='All 4LD cases excluded from current work; earlier evidence is retained for reference.')
            continue
        items = by_wallet.get(aid, [])
        if not items:
            continue
        failures = [s for s, _ in items if s['result'] == 'FAIL']
        row.update(followup_result='FAIL — linked scenario; row incomplete' if failures else 'PARTIAL PASS — named checks only',
                   followup_commit=data['candidate_commit'],
                   followup_scenarios='; '.join(s['id'] for s, _ in items),
                   followup_checks='\n'.join(f"{s['id']} [{s['result']}; {s['stage']}]: {w['observed']}" for s, w in items),
                   followup_gaps='; '.join(sorted({f for s, _ in items for f in s['finding_ids']})) or 'No new finding in the named checks.',
                   followup_evidence='; '.join(s['evidence'] for s, _ in items),
                   coverage_scope='Named scenarios on ' + data['candidate_commit'][:12] + '; other results remain from the earlier campaign. No new indexed-history result or whole-row PASS.')
        row['overall_result'] = ('FAIL — newer scenario; remaining checks partial' if failures else
                                'PARTIAL — newer checks pass; earlier failures retained' if historical.startswith('FAIL') else
                                'PARTIAL — newer checks pass; row incomplete')
    assert set(by_wallet) <= set(result['rows'])
    result['metadata'].update(
        status='PARTIAL — 2LD/3LD follow-up merged; full matrix incomplete',
        historical_candidate_commit=data['historical_candidate_commit'], followup_candidate_commit=data['candidate_commit'],
        exclusions=data['excluded'], followup_scenario_counts=data['scenario_counts'],
        followup_configurations=data['configuration_ids'], followup_wallet_rows=data['wallet_row_count'],
        integration_ledger='execution/priority-integration.json',
        execution_note='Earlier campaign checks retain their original commit and results. The 17 newer scenarios are mapped to exact wallets and actions; activity and untested actions receive no new credit.')

def merge_findings(gaps, data):
    if not data:
        return gaps
    accepted = {f['id'] for f in data['accepted_findings']}
    out = [{**g, 'accepted_for_pr_approval': g['id'] in accepted} for g in gaps if not g['id'].startswith('FOLLOWUP-')]
    for f in data['new_findings']:
        scenarios = [s for s in data['rows'] if s['id'] in f['cases']]
        out.append({**f, 'scenario_ids': f['cases'],
                    'cases': sorted({w['case_id'] for s in scenarios for w in s['wallet_mappings']}),
                    'status': 'FAIL — new finding; not accepted', 'accepted_for_pr_approval': False,
                    'candidate_commit': data['candidate_commit'],
                    'workaround': ' '.join(dict.fromkeys(s['workaround'] for s in scenarios)),
                    'limit': ' '.join(dict.fromkeys(s['limit'] for s in scenarios)),
                    'evidence': ['../' + s['evidence'] for s in scenarios]})
    return out

def panel(data, prefix='', config=None):
    if not data:
        return ''
    e = lambda value: html.escape(str(value))
    link = lambda path, label: '<a href="' + e(prefix + quote(path, safe='/#')) + '">' + e(label) + '</a>'
    rows = [r for r in data['rows'] if config is None or r['config_id'] == config]
    if not rows:
        return ''
    counts = Counter(r['result'] for r in rows)
    title = 'Priority results merged into this configuration' if config else 'Earlier 17-scenario priority follow-up — preserved evidence'
    out = '<section class="priority-panel" id="priority-latest"><style>.priority-panel{margin:20px 0;padding:20px;background:#fff;border:2px solid #7dada0;border-radius:8px}.priority-panel table{width:100%;table-layout:fixed;border-collapse:collapse}.priority-panel td,.priority-panel th{position:static!important;min-width:0!important;max-width:none!important;overflow-wrap:anywhere;border:1px solid #cbd9d1;padding:10px;vertical-align:top}.priority-panel th{height:auto}.priority-panel .fail{color:#a42828;font-weight:bold}.priority-panel .pass{color:#08674e;font-weight:bold}.priority-panel p{max-width:none}.priority-panel ul{padding-left:18px}.priority-panel summary{cursor:pointer}</style>'
    out += '<h2>' + e(title) + '</h2><p><b>' + str(len(rows)) + ' scenarios: ' + str(counts['PASS']) + ' PASS · ' + str(counts['FAIL']) + ' FAIL.</b> Tested commit <code>' + e(data['candidate_commit'][:12]) + '</code>.</p>'
    out += '<p>These are named action and timing checks, not completed configuration or wallet rows. Earlier results below retain commit <code>' + e(data['historical_candidate_commit'][:12]) + '</code>. DNS, stateful suites and all 4LDs are excluded from current work. No indexed-history pass is added.</p>'
    out += '<p>' + link('execution/priority-integration.json', 'Exact scenario → wallet → assertion mappings') + ' · ' + link('2ld-3ld-priority/2LD and 3LD priority results.html', 'Detailed 17-scenario evidence') + '</p>'
    if not config:
        out += '<p><b>Current scope:</b> 186 configurations / 1,082 wallet rows (2LD and 3LD). Older 4LD evidence stays available in the archive filter. The new evidence maps to four configurations and ' + str(data['wallet_row_count']) + ' wallet rows. It does not subtract 17 from the unfinished configuration count.</p>'
    out += ('<details open>' if config else '<details>') + '<summary>Executed scenarios, actual assertions, gaps and workarounds</summary><table><tr><th>Scenario / matrix wallets</th><th>Initial state → action → expectation</th><th>Actual result and assertions</th><th>Gap / workaround / limits</th></tr>'
    for r in rows:
        out += '<tr id="priority-' + e(r['id']) + '"><td><b>' + e(r['id']) + '</b><br>' + link('execution/cases/' + r['config_id'] + '.html#priority-latest', r['config_id']) + '<br>' + e(', '.join(r['family_ids']))
        for w in r['wallet_mappings']:
            out += '<p><b>' + e(w['case_id'] + ' / ' + w['actor']) + '</b><br>' + e(w['observed']) + '</p>'
        out += '</td><td><b>Before:</b> ' + e(r['initial']) + '<p><b>Action:</b> ' + e(r['action']) + '</p><p><b>Expected:</b> ' + e(r['expected']) + '</p></td>'
        out += '<td><b class="' + r['result'].lower() + '">' + e(r['result']) + '</b><p>' + e(r['summary']) + '</p><ul>'
        out += ''.join('<li><b class="' + c['result'].lower() + '">' + e(c['result']) + '</b> — ' + e(c['check']) + '</li>' for c in r['checks']) + '</ul>'
        out += link(r['evidence'], 'Final attempt: raw assertions') + ' · ' + link(r['report'], 'Detailed before/after evidence')
        for prior in r['previous_evidence']:
            out += '<br>' + link(prior, 'Preserved earlier attempt — not counted again')
        out += '</td><td><b>' + e(', '.join(r['finding_ids']) or 'No new finding in this scenario') + '</b><p>' + e(r['workaround'] or 'No workaround needed for the named checks.') + '</p><p><b>Limit:</b> ' + e(r['limit']) + '</p></td></tr>'
    out += '</table></details>'
    new = [f for f in data['new_findings'] if any(s['id'] in f['cases'] for s in rows)]
    out += '<h3>New findings — not included in accepted findings</h3><table><tr><th>Finding</th><th>Failed scenarios / wallets</th><th>Observed impact</th></tr>'
    for f in new:
        affected = [s for s in rows if s['id'] in f['cases']]
        out += '<tr><td><b>' + e(f['id'] + ' — ' + f['title']) + '</b></td><td>'
        out += '<br>'.join(e(s['id']) + '<br>' + e(', '.join(w['case_id'] for w in s['wallet_mappings'])) for s in affected)
        out += '</td><td>' + e(f['observed']) + '</td></tr>'
    out += '</table>' if new else '<tr><td colspan="3">No new finding in this configuration’s follow-up.</td></tr></table>'
    out += '<details><summary>Previously accepted findings — separate from the new results</summary><p>' + e(data['accepted_basis']) + '</p><table><tr><th>Accepted finding</th><th>Disposition</th></tr>'
    for f in data['accepted_findings']:
        out += '<tr><td>' + e(f['id'] + ' — ' + f['title']) + '</td><td>Temporarily accepted for PR evaluation. Original failed assertions remain; this is not a fix verification.</td></tr>'
    out += '</table><p>' + link('pr-approval-36/accepted-findings.json', 'Accepted-finding record') + '</p></details>'
    out += '<p><b>Still untested by this follow-up:</b> other wallet/action combinations, broader grace and fuse boundaries, all resolver/record variants, large inventories, later inclusion races and complete indexed activity. Fresh review after source changes remains required (MIGRATION-SOURCE-01).</p></section>'
    return out
