from pathlib import Path
from collections import Counter
import fcntl
_lock=open(Path(__file__).with_suffix('.lock'),'w');fcntl.flock(_lock,fcntl.LOCK_EX)
import json, html, subprocess, re, copy
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
import sys
sys.path.insert(0, str(ROOT))
import priority_matrix_integration as priority
import retention_matrix_integration as retention_report
retention_integration=retention_report.load()
priority_integration=priority.load()
esc=lambda x:html.escape(re.sub(r'\x1b\[[0-9;]*m', '', str(x)))
def write_changed(path, content):
 if path.exists() and path.read_text()==content:return
 tmp=path.with_name(path.name+'.tmp');tmp.write_text(content);tmp.replace(path)
CANDIDATE=Path('/Users/sg/ens/worktrees/migration-retention-matrix/e2e')
INDEPENDENT_GRACE_RULE='MIGRATION-GRACE-01 — user confirmed independent migration of an active emancipated child despite V2 ancestor grace'
def independent_grace_migration(c):
 return c.get('level')!='2LD' and c.get('root_type')=='Locked' and c.get('wrapping')=='Wrapped' and c.get('lock') in ['Locked','Detached'] and c.get('name_expiry')=='Active' and c.get('parent_migrated')=='Yes' and c.get('root_lifecycle_version')=='V2' and c.get('root_lifecycle')=='Grace'
subprocess.run(['node','--import',str(CANDIDATE/'node_modules/tsx/dist/loader.mjs'),'scripts/assert-matrix-evidence.mts',str(OUT)],cwd=CANDIDATE,stdout=subprocess.DEVNULL,check=False)
assertion_file=OUT/'retention-assertions.json'
assertions_by_file={o['file']:o['checks'] for o in json.loads(assertion_file.read_text()).get('observations',[])} if assertion_file.exists() else {}
history_api_failures=json.loads((OUT/'history-api-transient-failures.json').read_text()).get('failures',[]) if (OUT/'history-api-transient-failures.json').exists() else []
history_evidence_corrections=json.loads((OUT/'history-evidence-corrections.json').read_text()) if (OUT/'history-evidence-corrections.json').exists() else []
history_readiness_recoveries=json.loads((OUT/'history-readiness-recoveries.json').read_text()) if (OUT/'history-readiness-recoveries.json').exists() else []
supplements={}
ancestor_record_items={}
for sf in sorted(OUT.glob('matrix-*/supplemental/*.json')):
 try:sd=json.loads(sf.read_text())
 except (OSError,json.JSONDecodeError):continue
 if sd.get('id','').startswith('ANCESTOR-RECORDS-'):
  key=sd['id'];prior=ancestor_record_items.get(key)
  if not prior or sd.get('startedAt','')>prior[1].get('startedAt',''):ancestor_record_items[key]=(sf,copy.deepcopy(sd))
 if sd.get('harnessInvalid') or (sd.get('id','').startswith('HISTORY-') and sd.get('activityOracleVersion')!='semantic-activity-v3'):continue
 for failure in history_api_failures:
  if failure['source']!=str(sf.relative_to(OUT)):continue
  for label,value in sd.get('checks',{}).items():
   if label.startswith(failure['subject']+':') and value.get('result')=='BLOCKED' and 'HTTP 500' in value.get('detail',''):
    value.update(originalResult='BLOCKED',originalDetail=value['detail'],result='FAIL',detail=failure['detail'])
 for correction in history_evidence_corrections:
  if correction['source']!=str(sf.relative_to(OUT)):continue
  value=sd.get('checks',{}).get(correction['check'])
  if value:
   value.update(originalResult=value.get('result'),originalDetail=value.get('detail'),result=correction['result'],detail=correction['reason'])
 key=sd.get('id',sf.stem)
 # Keep separate history attempts, including a failure followed by a successful
 # read of the same original fixture. A retry must not erase the first result.
 if sd.get('id','').startswith('HISTORY-'):key+='|'+sf.parent.parent.name
 # An owner and an approved operator exercise different permission routes.
 # A later operator attempt must not replace the owner's re-issue evidence.
 if sd.get('id','').startswith('EXPIRED-REISSUE-'):key+='|'+sd.get('actor','unspecified')
 if key not in supplements or sd.get('startedAt',sd.get('completedAt',''))>supplements[key][1].get('startedAt',supplements[key][1].get('completedAt','')):supplements[key]=(sf,sd)

action_corrections=json.loads((OUT/'action-evidence-corrections.json').read_text()) if (OUT/'action-evidence-corrections.json').exists() else []
def assessed_action(sf, check):
 value={'result':check['result'],'detail':check.get('detail',''),'evidence':str(sf.relative_to(OUT))}
 if value['result']=='PASS' and check.get('action')=='full name transfer' and 'Reclaim the parent first' in check.get('evidence',{}).get('screen',''):
  value['detail']+=' The app directs this registrant to reclaim the manager role on the parent, then return. This PASS verifies the current transfer gate only; that multi-step recovery was not submitted in this check.'
 if value['result']=='PASS' and check.get('action')=='full name transfer' and 'Reassigning across that line would forcibly wrap or unwrap the subname' in check.get('evidence',{}).get('screen',''):
  value['detail']+=' This PASS covers the direct transfer gate while preserving the existing wrapping state. Explorer directs the user to make the parent and child wrapping match first; that preparation workflow was not executed here. Parent registry reassignment that changes wrapping is a separate capability.'
 if value['result']=='FAIL' and check.get('action')=='full name transfer' and 'reassigning this subname' in check.get('evidence',{}).get('screen','') and 'getByText(/Not authorized' in value['detail']:
  value.update(originalResult='FAIL',originalDetail=value['detail'],result='BLOCKED',detail='The old assertion checked only child-holder transfer authority and expected a denial. The loaded app offers the separate legitimate parent-reassignment route. This attempt did not submit that transfer; a fresh holder-and-parent assertion must verify it. The original strict failure is retained, not counted as an app permission defect.')
 if value['result']=='FAIL' and check.get('action')=='retain reverse and verified primary after migration/refusal' and 'Before-stage reverse claim must have actually executed' in value['detail']:
  value.update(originalResult='FAIL',originalDetail=value['detail'],result='BLOCKED',detail='The required before-stage reverse claim was never established. The after-stage assertion failed its setup prerequisite, so reverse/primary retention was not tested. This is not evidence of lost reverse data. Original strict failure retained; a fresh exact-wallet paired workflow is required.')
 if value['result']=='FAIL' and 'Local matrix wallet request did not settle' in value['detail']:
  value.update(originalResult='FAIL',originalDetail=value['detail'],result='BLOCKED',detail='The local headless wallet did not settle its request before the transaction deadline. The action was not verified; this is not a confirmed app permission failure. '+value['detail'])
 if value['result']=='BLOCKED' and check.get('action')=='change resolver' and value['detail'].startswith('Error: Loaded app error: could not find registry') and 'Could not find registry for this name.' in check.get('evidence',{}).get('screen',''):
  value.update(originalResult='BLOCKED',originalDetail=value['detail'],result='FAIL',detail='The resolver page loaded an explicit missing-registry error, preventing the workflow. This is an app error, not a successful permission/renewal gate or an infrastructure blocker. Contract authority and record retention remain separately assessed.')
 for correction in action_corrections:
  if correction['source']==value['evidence'] and all(correction[k]==check.get(k) for k in ['actor','app','stage','action']):
   value.update(originalResult=value['result'],originalDetail=value['detail'],result=correction['result'],detail=correction['reason'])
 return value

def app_assertion_scope(data, error):
 # Full-fixture soft assertions include every wallet. Their non-zero exit must
 # not turn a different wallet's successful checks into an unexplained failure.
 # Unknown errors remain configuration-wide and are never silently discarded.
 message=re.sub(r'\x1b\[[0-9;]*m', '', str(error)).removeprefix('Error: ')
 actors=data['configuration']['actors']
 for actor in actors:
  aid=actor['case_id']
  for stage in ['beforeUI','afterUI']:
   for app in data.get('actors',{}).get(aid,{}).get(stage,[]):
    for action in app.get('checks',{}):
     if message.startswith(f"{aid} {stage} {app['app']} {action}: "):return [aid]
 for check in data.get('appChecks',[]):
  if message.startswith(f"{check.get('actor')} {check.get('stage')} {check.get('action')}: "):
   return [actor['case_id'] for actor in actors if check.get('actor') in [actor['actor'],'Public view']]
 return None

def action_checks(c, actor, app, stage):
 selected={}
 for sf,sd in sorted(runs.get(c['config_id'],[]),key=lambda v:v[1].get('startedAt','')):
  if sd.get('harnessInvalid'):continue
  for check in sd.get('appChecks',[]):
   if check.get('actor') in [actor,'Public view'] and check.get('app')==app and check.get('stage')==stage:
    selected[check['action']]=assessed_action(sf,check)
 item=supplements.get('ACTIONS-'+c['config_id'])
 if item:
  sf,sd=item
  owner=c['root_owner'] if c['level']=='2LD' else c['name_holder'] if c['name_holder'].startswith('W') else c['name_manager']
  for label,value in sd.get('checks',{}).items():
   if not label.startswith(stage+':'):continue
   target_app='Manager' if 'primary forward' in label else 'Explorer'
   who='W1' if 'primary' in label else next((a['actor'] for a in c['actors'] if label.split(': ',1)[1].startswith(a['actor']+' ')),None) if 'change-resolver workflow' in label else owner
   if who!=actor or target_app!=app:continue
   selected[label.split(': ',1)[1]]={'result':value['result'],'detail':value.get('triage',value.get('error','Submitted through the app and checked against actual chain state.')),'evidence':str(sf.relative_to(OUT))}
 for sf,sd in supplements.values():
  if c['config_id'] not in sd.get('configurations',[]):continue
  for check in sd.get('appChecks',[]):
   if check.get('actor') in [actor,'Public view'] and check.get('app')==app and check.get('stage')==stage:
    selected[check['action']]=assessed_action(sf,check)
  if sd.get('id','').startswith('V1-GRACE-RECOVERY-') and actor==sd.get('configuration',{}).get('root_manager') and stage=='before' and sd.get('checks',{}).get('Actual V1 renewal preserves every record and controller',{}).get('result')=='PASS':
   for view in sd.get('afterRenewalUI',[]):
    check=view.get('checks',{}).get('editRecords')
    if view.get('app')==app and check:selected['edit records after V1 renewal']={'result':check['result'],'detail':check.get('detail','')+' This is the separately renewed, active checkpoint, not editing during grace.','evidence':str(sf.relative_to(OUT))}
 return selected

observations={}
runs={}
execution_interruptions=[]
execution_corrections=json.loads((OUT/'execution-evidence-corrections.json').read_text()) if (OUT/'execution-evidence-corrections.json').exists() else []
for file in sorted(OUT.glob('matrix-*/observations/CFG-*.json')):
 try:
  data=json.loads(file.read_text())
 except (OSError,json.JSONDecodeError):continue
 id=data['configuration']['config_id']
 if independent_grace_migration(data['configuration']):
  data['confirmedMigrationPolicy']=INDEPENDENT_GRACE_RULE
  data['originalRequirementDecisionPending']=data.pop('requirementDecisionPending',None)
  data['configuration']['expected_migration']='Native migration — independent despite V2 ancestor grace'
  data['effectiveExpectation']=INDEPENDENT_GRACE_RULE
  fresh_policy=any(a.get('check','').startswith('MIGRATION-GRACE-01:') for a in data.get('retentionAssertions',[]))
  data['requirementReassessment']='Fresh strict execution includes the user-confirmed independent-migration assertion.' if fresh_policy else 'Saved observations reassessed against the user-confirmed rule. Original raw evidence is unchanged; this reassessment is not a fresh app execution.'
 if not data.get('phase','').startswith('completed selected') and (re.search(r'Timeout|Target page, context or browser has been closed|HTTP request failed|fetch failed',str(data.get('error','')),re.I) or any(re.search(r'Test timeout of',str(error),re.I) for error in data.get('assertionErrors',[]))):
  data['executionIncomplete']={'result':'BLOCKED','reason':'The fixture did not finish because navigation, RPC, browser availability or the total test deadline interrupted execution. Completed individual assertions remain visible; no unexecuted action is treated as a product failure.'}
  execution_interruptions.append({'source':str(file.relative_to(OUT)),'configuration':id,'phase':data.get('phase'),'originalError':data.get('error'),'assessment':data['executionIncomplete']})
 if not data.get('phase','').startswith('completed selected') and (file.parent.parent/'strict-results.json').exists():
  log=file.parent.parent/'run.log'
  if log.exists() and 'JavaScript heap out of memory' in log.read_text():
   data['executionIncomplete']={'result':'BLOCKED','reason':'The local test worker exhausted its JavaScript heap and aborted before this fixture finished. Completed assertions remain evidence; missing checkpoints require a fresh run. This is not an app or migration failure. Subsequent runs use the verified response-handle asset cache and an 8 GiB test heap; see test-worker-memory-recovery.json.'}
   execution_interruptions.append({'source':str(file.relative_to(OUT)),'configuration':id,'phase':data.get('phase'),'originalError':'Playwright worker heap exhaustion / SIGABRT','assessment':data['executionIncomplete']})
 for correction in execution_corrections:
  if correction['source']==str(file.relative_to(OUT)):
   data['executionIncomplete']={'result':correction['result'],'reason':correction['reason']}
   execution_interruptions.append({'source':correction['source'],'configuration':id,'phase':data.get('phase'),'originalError':data.get('error'),'assessment':data['executionIncomplete']})
 context_file=file.parent.parent/'run-context.json'
 audit_file=OUT/'chain-clock-audit.json'
 if context_file.exists() and audit_file.exists() and data.get('afterActivity'):
  context=json.loads(context_file.read_text());ready=context.get('readyPath','')
  if ready and not Path(ready).is_absolute():ready=str((CANDIDATE.parent/ready).resolve())
  clock=next((x for x in json.loads(audit_file.read_text()).get('chains',[]) if x.get('readyPath')==ready and x.get('timestampRegressions')),None)
  if clock and int(data['afterActivity']['toBlock'])>=clock['timestampRegressions'][0]['block']:
   data['historyClockInvalid']={'result':'BLOCKED','firstBackwardsBlock':clock['timestampRegressions'][0]['block'],'detail':'Recovered local chain timestamps moved backwards; fresh monotonic-chain history proof is required.'}
 runs.setdefault(id,[]).append((file,data))
 if id not in observations or data.get('startedAt','')>observations[id][1].get('startedAt',''):
  observations[id]=(file,data)
# Keep an earlier completed observation visible while an independent rerun is
# still executing. A completed rerun replaces it, including any new failure.
for id, versions in runs.items():
 latest=max(versions,key=lambda x:x[1].get('startedAt',''))
 completed=[v for v in versions if v[1].get('completedAt') and not v[1].get('harnessInvalid')]
 if (not latest[1].get('completedAt') or latest[1].get('harnessInvalid')) and completed:
  observations[id]=max(completed,key=lambda x:x[1].get('startedAt',''))

# Record profiles and UI runs use separate fresh fixtures. Keep completed UI
# evidence when a later core/record run has no UI observations; cite each source.
assessment_corrections=json.loads((OUT/'app-evidence-corrections.json').read_text()) if (OUT/'app-evidence-corrections.json').exists() else []
def assessed_app(file, candidate, aid, stage, actor, original):
 app=copy.deepcopy(original)
 checks=app.get('checks',{})
 owner_check=checks.get('ownerDisplay',{})
 if candidate['configuration'].get('wrapping')=='Wrapped' and candidate['configuration'].get('name_expiry','').startswith('Expired') and owner_check.get('evidence',{}).get('oracleVersion')!='live-wrapper-holder-v1' and owner_check.get('result')=='FAIL':
  owner_check.update(originalResult='FAIL',originalDetail=owner_check.get('detail',''),result='BLOCKED',detail='The old assertion expected the fixture holder even after wrapper expiry. Fresh checking must compare the actual current wrapper holder, which can be zero, and distinguish current ownership from a previous owner. The original displayed address remains recorded; this is not evidence of split-owner/manager parity failure.')
 for value in checks.values():
  detail=value.get('detail','')
  if value.get('result')=='FAIL' and 'Verify your wallet' in detail and re.search(r'locator handler has finished|intercepting action to run the handler',detail):
   value.update(originalResult='FAIL',originalDetail=detail,result='BLOCKED',detail='The local test backend-auth dismissal handler did not finish before this assertion. The owner/action assertion was not completed; this is not a confirmed wrong-ownership or missing-action result. A fresh app run is required.')
 for correction in assessment_corrections:
  if correction['source']==str(file.relative_to(OUT)) and correction['caseId']==aid and correction['stage']==stage and correction['app']==app['app'] and correction['check'] in checks:
   value=checks[correction['check']];value['originalResult']=value.get('result');value['originalDetail']=value.get('detail');value.update(result=correction['result'],detail=correction['reason'])
 inventory_affected=app.get('inventoryVersion')!='actual-protocol-and-chain-time-v3' and ((stage=='afterUI' and (candidate.get('afterState') or {}).get('status')!=2) or (stage=='beforeUI' and candidate['configuration'].get('parent_migrated')=='Yes'))
 if inventory_affected:
  for value in checks.values():
   value['originalResult']=value.get('result');value['originalDetail']=value.get('detail')
   value.update(result='BLOCKED',detail='Fresh app run required: discovery must use actual protocol per name, including unchanged V1 names after refusal and V1 children below a V2 ancestor. Original UI evidence is retained; independent on-chain retention checks remain separate.')
 prior=actor.get('before') or {}
 independent=checks.get('independentManagerEdit',{})
 if stage=='beforeUI' and independent.get('result')=='PASS' and not prior.get('assignManagerAsOwner') and (prior.get('reclaim') or {}).get('result')=='ALLOWED' and (prior.get('editManager') or {}).get('result')=='DENIED':
  independent['originalResult']='PASS';independent['originalDetail']=independent.get('detail')
  independent.update(result='BLOCKED',detail='The old check considered only direct registry edits. This wallet can reclaim through the registrar; a fresh check now explicitly probes assigning a different manager without transferring ownership. No expected-denial pass is claimed for this incomplete assertion.')
 lifecycle=candidate['configuration'].get('root_lifecycle')=='Grace' or candidate['configuration'].get('name_expiry','').startswith('Expired')
 records=candidate.get('beforeRecords' if stage=='beforeUI' else 'afterRecords',[])
 description=next((record for record in records if record.get('what')=='text "description"'),None)
 visibility=checks.get('recordsVisible',{})
 if lifecycle and description and description.get('got')!=description.get('want') and visibility.get('result')=='FAIL' and 'getByText' in visibility.get('detail',''):
  visibility['originalFailure']=visibility.get('detail')
  visibility.update(result='BLOCKED',detail='This UI assertion required a value that already fails live resolution at the saved grace/expiry checkpoint. Source storage and migration retention are assessed separately. A fresh lifecycle-aware display check is required; this timeout is not migration data loss.')
 edit=checks.get('editRecords',{})
 if edit.get('result')=='FAIL' and 'getByLabel' in edit.get('detail','') and 'Type' in edit.get('detail','') and app.get('screens',{}).get('editRecords-failed',None)=='':
  edit.update(originalResult='FAIL',originalDetail=edit.get('detail'),result='BLOCKED',detail='The saved Explorer editor-readiness assertion timed out on an empty page. Neither an editor nor a permission denial was loaded, so no authorization outcome was established. Fresh runs allow 60 seconds and capture app exceptions and request hosts. Original evidence is retained; this is not a confirmed permission failure.')
 if edit.get('result')=='FAIL' and 'function:  text(bytes name, string key)' in edit.get('detail',''):
  edit['originalResult']=edit.get('result');edit['originalDetail']=edit.get('detail')
  edit.update(result='BLOCKED',detail='The test cleanup used an unsupported PermissionedResolver text(bytes,string) getter. The corrected test reads through resolve(name, getter calldata). This does not establish a failed app edit or missing record; an independent fresh app run is required. See configured-resolver-readback-correction.json.')
 if candidate['configuration'].get('root_lifecycle')=='Grace':
  detail=edit.get('detail','')
  completed_denial=(edit.get('result')=='FAIL' and 'no usable edit entry although the exact resolver call is authorized' in detail) or (edit.get('result')=='BLOCKED' and detail.startswith('Acceptance rule pending:'))
  completed_write=edit.get('result')=='PASS' and detail.startswith('Submitted a distinct record')
  if completed_denial or completed_write:
   edit['originalResult']=edit.get('result');edit['originalDetail']=detail
   edit['acceptanceDecision']='acceptance-decisions.json#GRACE-EDIT-01'
   edit.update(result='PASS' if completed_denial else 'FAIL',detail=('Renewal required before editing: the saved completed observation found no usable editor during grace, matching the policy confirmed by the user on 2026-10-24. This is a reassessment of the saved evidence, not a fresh test run; original results are retained.' if completed_denial else 'The saved app transaction edited a record during grace without renewal, contrary to the policy confirmed by the user on 2026-10-24. The written value and restoration were verified. This is a reassessment of the saved evidence; original results are retained.'))
 if app.get('app')=='Manager' and 'This name is in grace period' in app.get('screens',{}).get('records','') and 'Wait for the actual connected-wallet resolver permission query' in edit.get('detail',''):
  edit['originalFailure']=edit.get('detail')
  edit.update(result='BLOCKED',detail='Test readiness waited for a permission query that Manager disables behind its visible grace-period gate. No edit assertion completed. A fresh run with the explicit grace gate is required; this timeout is not a product failure.')
 return app

def combined_probe(d, aid):
 result=dict(d.get('actors',{}).get(aid,{}));sources={}
 for file, candidate in sorted(runs.get(d['configuration']['config_id'],[]),key=lambda v:v[1].get('startedAt','')):
  if candidate.get('harnessInvalid'):continue
  actor=candidate.get('actors',{}).get(aid,{})
  for stage in ['beforeUI','afterUI']:
   if actor.get(stage):
    result[stage]=[assessed_app(file,candidate,aid,stage,actor,app) for app in actor[stage]]
    sources[stage]={'file':str(file.relative_to(OUT)),'subject':candidate.get('subject','fixture'),'recordProfile':candidate.get('recordProfile','baseline-7')}
 result['uiSources']=sources
 return result

def role_result(role_assertions,probe,actor):
 if actor=='Disconnected':return 'N/A — no connected wallet for contract role assertions; disconnected app access is tested separately'
 if any(a['result']=='FAIL' for a in role_assertions):return 'FAIL — role/permission assertion'
 if any(a['result']=='BLOCKED' for a in role_assertions):return 'BLOCKED — at least one contract authority read did not complete'
 if any(a['result']=='NOT RUN' for a in role_assertions):return 'PARTIAL — some post-attempt role/authority assertions are unexecuted'
 if role_assertions:return f"PASS — {len(role_assertions)} exact role/authority assertions; app delegation workflows separate"
 if probe.get('after'):return 'PARTIAL — exact role reads; expectations pending'
 if probe.get('afterRefusal'):return 'PARTIAL — post-refusal reads exist; exact preservation assertions pending'
 return 'NOT RUN — post-attempt role/authority comparison'

def permission_change_summary(probe,migrated):
 if not migrated:return ''
 before=probe.get('before') or {};after=probe.get('after') or {}
 actions={'records':'direct record editing','setResolver':'resolver changes','transfer':'holder transfer','createSubname':'child creation'}
 lost=[];gained=[]
 for action,label in actions.items():
  b=before.get(action);a=after.get(action)
  if not isinstance(b,dict) or not isinstance(a,dict):continue
  if b.get('result')=='ALLOWED' and a.get('result')=='DENIED':lost.append(label)
  elif b.get('result')=='DENIED' and a.get('result')=='ALLOWED':gained.append(label)
 changes=[]
 if lost:changes.append('NOT PRESERVED after migration: '+', '.join(lost)+' (allowed before, denied after)')
 if gained:changes.append('NEW AUTHORITY after migration: '+', '.join(gained)+' (denied before, allowed after)')
 return '; '.join(changes)+'. These are measured contract-permission changes; expected role grants and app workflows are assessed separately. ' if changes else ''

def ui_result(probe, stage, app):
 observations=probe.get(stage,[])
 data=next((x for x in observations if x['app']==app),None)
 if not data:return 'NOT RUN'
 checks=data.get('checks',{})
 edit=checks.get('editRecords',{})
 view=checks.get('recordsVisible',{})
 detail=edit.get('detail','')
 outcome='edit completed and read back' if detail.startswith('Submitted a distinct record') else 'editing refused as expected' if detail.startswith('Direct record editing is unavailable') else 'renewal required before editing' if detail.startswith('Renewal required before editing:') else 'edit completed before required renewal' if edit.get('result')=='FAIL' and ('edited a record during grace without renewal' in detail or 'committed a record edit during grace without renewal' in detail) else 'authorized edit unavailable' if edit.get('result')=='FAIL' and ('authorized' in detail or 'authorizes' in detail) else 'permission read blocked' if edit.get('result')=='BLOCKED' else 'record-edit check'
 return f"{edit.get('result','NOT RUN')} — {outcome}; viewer {view.get('result','NOT RUN')}; remaining actions pending"

def combined_edit(probe, stage):
 apps={item['app']:item.get('checks',{}).get('editRecords',{}) for item in probe.get(stage,[])}
 completed=[app for app,check in apps.items() if check.get('result')=='PASS' and check.get('detail','').startswith('Submitted a distinct record')]
 if completed:
  workaround=any(check.get('result')=='FAIL' for check in apps.values())
  return {'result':'PASS','detail':('Verified workaround: ' if workaround else 'Completed through ')+', '.join(completed)+' submitted the edit and exact readback passed. Individual app gaps remain visible.','workaround':workaround}
 if len(apps)==2 and all(check.get('result')=='PASS' and check.get('detail','').startswith(('Direct record editing is unavailable','Renewal required before editing:')) for check in apps.values()):
  return {'result':'PASS','detail':'Both apps withheld direct editing as required: renewal is needed while in grace, and unauthorized/disconnected wallets remain denied.'}
 if any(check.get('result')=='FAIL' and ('edited a record during grace without renewal' in check.get('detail','') or 'committed a record edit during grace without renewal' in check.get('detail','')) for check in apps.values()):return {'result':'FAIL','detail':'An app committed a record edit before the required renewal. The other app withholding its editor does not satisfy this policy for both apps.'}
 if any(check.get('result')=='FAIL' for check in apps.values()):return {'result':'FAIL','detail':'No completed record-edit workaround was verified for this wallet at this stage.'}
 return {'result':'NOT RUN' if not apps else 'BLOCKED','detail':'Combined record-edit capability has not been proved at this stage.'}

def actor_table(d):
 after_label='After attempt — still V1' if str(d.get('migrationOutcome','')).startswith(('blocked','expired subject')) else 'After migration'
 result='<h3>Before and after, by wallet</h3><p>After columns show the outcome actually reached: '+after_label+'. Each separately executed action links its own evidence.</p><table><tr><th>Wallet</th><th>App</th><th>Check</th><th>Before</th><th>After</th></tr>'
 for actor in d.get('configuration',{}).get('actors',[]):
  probe=combined_probe(d,actor['case_id'])
  for app in ['Manager','Explorer']:
   before=next((x.get('checks',{}) for x in probe.get('beforeUI',[]) if x['app']==app),{})
   after=next((x.get('checks',{}) for x in probe.get('afterUI',[]) if x['app']==app),{})
   before={**before,**action_checks(d['configuration'],actor['actor'],app,'before')}
   after={**after,**action_checks(d['configuration'],actor['actor'],app,'after')}
   for action in sorted(set(before)|set(after)|{'recordsVisible','editRecords'}):
    cells=[]
    for stage_name,checks in [('beforeUI',before),('afterUI',after)]:
     value=checks.get(action,{})
     source=probe.get('uiSources',{}).get(stage_name,{})
     source_link=(f'<br><a href="{esc(source["file"])}">Fixture: {esc(source["subject"])}</a>' if source and action in (probe.get(stage_name) and next((u.get('checks',{}) for u in probe[stage_name] if u['app']==app),{}) or {}) else f'<br><a href="{esc(value["evidence"])}">Action evidence</a>' if value.get('evidence') else '')
     cells.append(f"<td><b>{esc(value.get('result','NOT RUN'))}</b><br>{esc(value.get('detail','No runtime evidence yet.'))}{source_link}</td>")
    result+=f"<tr><td>{esc(actor['actor'])}</td><td>{app}</td><td>{esc(action)}</td>{''.join(cells)}</tr>"
  combined=[combined_edit(probe,stage) for stage in ['beforeUI','afterUI']]
  result+=f'<tr><td>{esc(actor["actor"])}</td><td><b>Manager + Explorer</b></td><td>Combined record-edit workflow</td>'+''.join(f'<td><b>{item["result"]}</b><br>{esc(item["detail"])}</td>' for item in combined)+'</tr>'
 return result+'</table>'

def contract_table(d):
 result='<h3>Contract authorization, before and after</h3><p>These are actual call simulations. ALLOWED / DENIED describe contract authority; they do not claim a completed app workflow. For refused migrations, unchanged authority remains V1 authority and does not prove V2 permission retention. A parent set-owner call can also authorize re-issuing an expired label whose effective holder is zero. That is separate from transferring an existing held name; the app transfer refusal and parent re-issue workflow are tested separately.</p><table><tr><th>Wallet</th><th>Action</th><th>Before</th><th>After</th><th>Preservation assertion</th></tr>'
 for actor in d.get('configuration',{}).get('actors',[]):
  probe=d.get('actors',{}).get(actor['case_id'],{})
  before=probe.get('before') or {}; after=probe.get('afterRefusal') or probe.get('after') or {}
  if isinstance(before.get('transferAsParent'),dict):
   def transfer_routes(values):
    outcomes=[values.get(key,{}).get('result') for key in ['transfer','transferAsParent']]
    return 'ALLOWED' if 'ALLOWED' in outcomes else 'BLOCKED' if 'BLOCKED' in outcomes else 'DENIED' if all(v=='DENIED' for v in outcomes) else 'NOT RUN'
   bv=transfer_routes(before)
   av=transfer_routes(after) if probe.get('afterRefusal') else after.get('unsafeTransfer',{}).get('result','NOT RUN')
   if 'NOT RUN' in [bv,av]:verdict='NOT COMPARED — one checkpoint is absent'
   elif 'BLOCKED' in [bv,av]:verdict='BLOCKED — authority was not established'
   elif bv==av:verdict='PASS — the same direct transfer/reassignment capability was measured'
   elif bv=='ALLOWED':verdict='NOT PRESERVED AS A DIRECT ACTION — allowed before, denied after. Separate parent deletion/recreation powers and any workaround require their own executed evidence; this alone does not establish a requirement violation.'
   else:verdict='NEW DIRECT AUTHORITY — denied before, allowed after'
   result+=f'<tr><td>{esc(actor["actor"])}</td><td><b>Direct transfer / parent reassignment capability</b><br>V1 holder or preserving parent intent; V2 app transfer intent</td><td>{bv}</td><td>{av}</td><td>{verdict}</td></tr>'
  for action in sorted(set(before)|set(after)):
   b=before.get(action);a=after.get(action)
   if not isinstance(b,dict) and not isinstance(a,dict):continue
   bv=b.get('result','NOT RUN') if isinstance(b,dict) else 'NOT RUN'; av=a.get('result','NOT RUN') if isinstance(a,dict) else 'NOT RUN'
   if isinstance(b,dict) and isinstance(a,dict):
    if 'BLOCKED' in [bv,av]:verdict='BLOCKED — a permission read did not complete'
    elif bv==av and bv in ['ALLOWED','DENIED']:verdict='PASS — same effective permission in these simulations'
    elif probe.get('afterRefusal'):verdict='FAIL — permission changed despite refused migration'
    elif bv=='ALLOWED' and av=='DENIED':verdict='NOT PRESERVED — allowed before, denied after. Compare with the explicit keep/remove and approval requirements; this is a measured power change, not automatically an unexpected bug.'
    elif bv=='DENIED' and av=='ALLOWED':verdict='NEW AUTHORITY — denied before, allowed after. Exact expected grants are checked below.'
    else:verdict='See exact role/permission assertions below'
   else:verdict='NOT COMPARED — action not measured in both protocols; no retention claim'
   result+=f'<tr><td>{esc(actor["actor"])}</td><td>{esc(action)}</td><td>{bv}</td><td>{av}</td><td>{verdict}</td></tr>'
 return result+'</table>'

def record_bundle_runs(config_id):
 return [(file,data) for file,data in runs.get(config_id,[]) if data.get('completedAt') and not data.get('harnessInvalid') and data.get('beforeRecords') and data.get('afterRecords')]

def record_lifecycle_diagnostic(config_id):
 path=OUT/f'expired-child-historical-resolution-{config_id.replace("CFG-","CFG")}.json'
 if not path.exists():return ''
 evidence=json.loads(path.read_text())
 result='<h3>Ancestor migration and child expiry: separate checkpoints</h3><p><b>'+esc(evidence.get('assessment',{}).get('result','NOT VERIFIED'))+'</b> — '+esc(evidence['assessment']['conclusion'])+'</p><p>Read-only historical replay of the <a href="'+esc(evidence['source'])+'">original fixture</a>; this is separate contract evidence, not another app migration. <a href="'+esc(path.name)+'">Exact values, block hashes and validation</a>.</p><table><tr><th>Checkpoint</th><th>Child holder</th><th>Ancestor records resolving</th><th>Child records resolving</th><th>Original stored values</th></tr>'
 for point in evidence['checkpoints']:
  ancestors,child=point['names'][:-1],point['names'][-1]
  ancestor_counts='<br>'.join(f'{len(n["name"].split("."))}LD: {n["publicMatches"]}/{len(n["reads"])}' for n in ancestors)
  holder='None — expired' if point['childWrapper'][0]=='0x0000000000000000000000000000000000000000' else 'Original holder retained'
  stored=sum(n['sourceMatches'] for n in point['names']);total=sum(len(n['reads']) for n in point['names'])
  result+=f'<tr><td>{esc(point["label"])}<br>Block {esc(point["blockNumber"])}</td><td>{holder}</td><td>{ancestor_counts}</td><td>{child["publicMatches"]}/{len(child["reads"])}</td><td>{stored}/{total} unchanged</td></tr>'
 return result+'</table>'

def ancestor_grace_record_diagnostic(config_id):
 path=OUT/f'ancestor-grace-historical-resolution-{config_id.replace("CFG-","CFG")}.json'
 if not path.exists():return ''
 evidence=json.loads(path.read_text())
 assessment=evidence.get('assessment',{})
 result='<h3>Ancestor migration and ancestor grace: separate record checkpoints</h3><p><b>'+esc(assessment.get('result','NOT VERIFIED'))+'</b> — '+esc(assessment.get('conclusion',''))+'</p><p>Read-only historical replay of the <a href="'+esc(evidence['source'])+'">original fixture</a>. This checks the cause of unavailable resolution; it does not turn the failed child migration into a PASS. <a href="'+esc(path.name)+'">Exact values, block hashes and assertions</a>.</p><table><tr><th>Checkpoint</th><th>Child status</th><th>Ancestor subregistry visible</th><th>Public records resolving</th><th>Original stored values</th></tr>'
 for point in evidence['checkpoints']:
  active=int(point['timestamp'])<int(point['childWrapper'][2])
  holder=point['childWrapper'][0]!='0x0000000000000000000000000000000000000000'
  def count(n):
   unreadable=any(r.get('resolved',{}).get('blocked') or 'missing bytecode for code hash' in r.get('resolved',{}).get('error','') for r in n['reads']) or (point.get('historicalReadStatus') and n['publicMatches']!=len(n['reads']))
   return f'{len(n["name"].split("."))}LD: '+('BLOCKED — historical read unavailable' if unreadable else f'{n["publicMatches"]}/{len(n["reads"])}')
  counts='<br>'.join(count(n) for n in point['names'])
  stored=sum(n['sourceMatches'] for n in point['names']);total=sum(len(n['reads']) for n in point['names'])
  result+=f'<tr><td>{esc(point["label"])}<br>Block {esc(point["blockNumber"])}</td><td>{"Active" if active else "Expired"}; {"holder present" if holder else "no holder"}</td><td>{"Yes" if point["visibleRootSubregistry"]!="0x0000000000000000000000000000000000000000" else "No"}</td><td>{counts}</td><td>{stored}/{total} exact</td></tr>'
 return result+'</table>'

def live_ancestor_record_checkpoints(config_id):
 item=ancestor_record_items.get('ANCESTOR-RECORDS-'+config_id)
 if not item:return ''
 file,data=item
 result='<h3>Fresh record checkpoints captured during ancestor migration</h3><p><b>'+esc(data.get('result','IN PROGRESS'))+'</b>. '+esc(data['scope'])+' <a href="'+esc(str(file.relative_to(OUT)))+'">Exact assertions, values and receipts</a>.</p><table><tr><th>Checkpoint</th><th>Child status</th><th>Public record values</th><th>Original source values</th></tr>'
 for point in data.get('checkpoints',[]):
  public=[];stored=[]
  for name in point['names']:
   label=f'{len(name["name"].split("."))}LD'
   reads=name['reads'];blocked=any(r['resolved'].get('blocked') for r in reads)
   unavailable=all(r['resolved'].get('errorName')=='ResolverNotFound' for r in reads)
   public.append(label+': '+('BLOCKED — RPC read unavailable' if blocked else 'ResolverNotFound — ancestor in grace' if unavailable else f'{name["publicMatches"]}/{len(reads)} exact'))
   stored.append(f'{label}: {name["sourceMatches"]}/{len(reads)} exact')
  child=point['childWrapper'];active=int(point['timestamp'])<int(child[2]) and child[0]!='0x0000000000000000000000000000000000000000'
  result+=f'<tr><td>{esc(point["label"])}<br>Block {esc(point["blockNumber"])}</td><td>{"Active, holder present" if active else "Inspect exact ownership/expiry evidence"}</td><td>{"<br>".join(public)}</td><td>{"<br>".join(stored)}</td></tr>'
 return result+'</table><p>A PASS here verifies record continuity during ancestor migration and the later routing change at grace. The active child’s separate migration eligibility result remains unchanged.</p>'

def ancestor_record_checkpoint_summary():
 path=OUT/'historical-rpc-readiness.json'
 if not path.exists():return ''
 rows=json.loads((OUT/'independent-grace-execution-summary.json').read_text())['rows']
 result='<section id="ancestor-record-checkpoints"><h2>Records before and after each ancestor migration</h2><p>Some older historical calls could not run because saved contract bytecode was unavailable. They remain <b>BLOCKED</b>, not record-loss findings. Fresh independent tests capture each checkpoint immediately on the live chain. <a href="historical-rpc-readiness.json">Original limitation and evidence</a>.</p><p>This table covers record continuity while ancestors migrate, followed by their grace boundary. It does not turn the active child’s separate failed app migration into a PASS.</p><table><tr><th>Configuration</th><th>Fresh checkpoint result</th><th>Assertions</th><th>Evidence</th></tr>'
 for row in rows:
  cid=row['configuration'];item=ancestor_record_items.get('ANCESTOR-RECORDS-'+cid)
  if item:
   file,data=item;status=data.get('result','IN PROGRESS');counts=dict(Counter(c['result'] for c in data.get('checks',{}).values()))
   detail=', '.join(f'{k}: {v}' for k,v in counts.items()) or 'No completed assertions yet'
   link='<a href="'+esc(str(file.relative_to(OUT)))+'">Exact fresh fixture</a>'
  else:
   active=next((c for c in action_queue.get('claimed',[]) if c.get('id')==cid and c.get('layer')=='ancestor-records' and c.get('status')=='running'),None)
   status='WAITING FOR FIRST CHECKPOINT' if active else 'NOT RUN — queued';detail='No completed checkpoint assertions yet'
   link='<a href="'+esc(active['output']+'/run-context.json')+'">Run setup</a>' if active else '—'
  result+=f'<tr><td><a href="cases/{esc(cid)}.html">{esc(cid)}</a></td><td>{esc(status)}</td><td>{esc(detail)}</td><td>{link}</td></tr>'
 return result+'</table></section>'

def source_record_table(data):
 before=data.get('beforeSourceRecords');after=data.get('afterSourceRecords')
 result='<h3>Original resolver records, independent of public resolution</h3><p>These are direct reads of the subject’s original resolver. They distinguish inaccessible resolution from changed stored records. Unchanged original values do not prove migration occurred or that the new resolver retained them. The public resolution comparison above remains separate.</p>'
 if before is None:return result+'<p><b>NOT RUN</b> — the original-resolver baseline was not captured.</p>'
 rows='';after_map={r['what']:r for r in after or []}
 for b in before:
  a=after_map.get(b['what']);readable=lambda r:bool(r and r.get('raw') and not str(r.get('got','')).startswith('read failed:'))
  baseline='BLOCKED' if not readable(b) else 'PASS' if b.get('got')==b.get('want') else 'FAIL — differs from seeded value'
  comparison='NOT RUN' if after is None else 'FAIL — record missing from snapshot' if a is None else 'BLOCKED' if not readable(b) or not readable(a) or baseline!='PASS' else 'PASS — decoded value and return bytes unchanged' if a.get('got')==b.get('got') and a.get('raw')==b.get('raw') else 'FAIL — original value or return bytes changed'
  rows+=f'<tr><td>{esc(b["what"])}</td><td>{baseline}</td><td>{comparison}</td><td><details><summary>Values and bytes</summary><b>Expected</b><pre>{esc(b.get("want"))}</pre><b>Before</b><pre>{esc(b.get("got"))}</pre><b>After</b><pre>{esc(a.get("got") if a else "NOT RUN")}</pre><b>Before return bytes</b><pre>{esc(b.get("raw","NOT READ"))}</pre><b>After return bytes</b><pre>{esc(a.get("raw","NOT READ") if a else "NOT RUN")}</pre></details></td></tr>'
 return result+'<table><tr><th>Record</th><th>Baseline</th><th>Original storage comparison</th><th>Details</th></tr>'+rows+'</table>'

def independent_grace_table():
 path=OUT/'independent-grace-execution-summary.json'
 if not path.exists():return ''
 data=json.loads(path.read_text());rows=''
 for item in data['rows']:
  subject_type='Emancipated; may unwrap' if item['subjectType']=='Detached' else 'Emancipated; cannot unwrap'
  owners=f'Root: {esc(item["rootOwner"])}<br>Immediate parent: {esc(item["parentOwner"])}<br>Subject: {esc(item["subjectOwner"])}'
  source=item['originalSourceRecords'];source_scope='Asserted within fresh test' if source['freshRunIncludedSourceAssertion'] else 'Comparison of saved live reads'
  rows+=f'<tr><td><a href="cases/{esc(item["configuration"])}.html">{esc(item["configuration"])}</a><br>{esc(item["level"])}</td><td>{subject_type}</td><td>{owners}</td><td><b>FAIL</b><br>Required migration refused<br><a href="{esc(item["source"])}">Fresh execution evidence</a></td><td><b>PASS — {source["records"]} unchanged</b><br>Original resolver only<br>{source_scope}</td><td><b>NOT RUN</b><br>Subject did not migrate</td></tr>'
 return '<section id="independent-grace"><h2>Independent migration during V2 ancestor grace</h2><p><b>14 fresh migration checks: 14 FAIL.</b> The confirmed rule allows an active emancipated subname to migrate independently despite its already-migrated V2 parent or ancestor being in grace. W1/W2/W3 identify distinct test wallets within each fixture. Existing V1 records remained intact; this is separate from V2 retention.</p><table><tr><th>Configuration</th><th>Subject</th><th>Ownership</th><th>Actual app migration</th><th>Original stored records</th><th>After-migration retention</th></tr>'+rows+'</table><p>Renewing the ancestor before migration is verified only for CFG-0864 and does not satisfy independent migration. No independent workaround is verified. <a href="independent-grace-execution-summary.json">Complete result ledger</a> · <a href="MRT-16-fourth-level-diagnostic.json">Active V2 parent / grace grandparent diagnostic</a></p></section>'

def record_bundle_table(config_id):
 items=record_bundle_runs(config_id)
 if not items:return ''
 result='<h3>Executed record bundles</h3><p>Each row is a separate fresh fixture for this configuration. A smaller later app fixture does not erase the expanded record comparison. Resolver replacement has its own results.</p><table><tr><th>Fixture / record count</th><th>Before</th><th>Migration outcome</th><th>After</th><th>Comparison</th></tr>'
 for file,data in sorted(items,key=lambda item:item[1].get('startedAt','')):
  before=data['beforeRecords'];after=data['afterRecords'];n=len(after)
  unchanged=before==after
  matches=sum(r['got']==r['want'] for r in after)
  refusal=str(data.get('migrationOutcome','')).startswith(('blocked','expired subject'))
  verdict=('PASS — V1 continuity only; V2 retention NOT RUN' if unchanged else 'FAIL — changed after refusal') if refusal else 'PASS — exact records retained' if matches==n and (data.get('afterState') or {}).get('status')==2 else 'FAIL — mismatch or migration incomplete'
  result+=f'<tr><td><a href="{esc(str(file.relative_to(OUT)))}">{esc(data.get("subject","Fixture"))}</a><br>{n} records</td><td>{sum(r["got"]==r["want"] for r in before)}/{len(before)} resolve</td><td>{esc(data.get("migrationOutcome","NOT VERIFIED"))}</td><td>{matches}/{n} resolve</td><td>{verdict}</td></tr>'
 return result+'</table>'

def resolver_imports(config_id):
 return sorted([(file,data) for file,data in supplements.values() if data.get('id','').startswith('S4-') and config_id in data.get('configurations',[]) and data.get('completedAt')],key=lambda v:v[1].get('completedAt',''))

def import_outcome(data):
 before=data.get('beforeMigration',[]); after=data.get('afterMigration',[])
 final=data.get('afterImport',data.get('finalRecords',[]))
 changed=bool(data.get('resolverAfterImport')) and str(data['resolverAfterImport']).lower()!=str(data.get('sourceResolver','')).lower()
 mismatches=[r for r in final if r.get('got')!=r.get('want')]
 if data.get('harnessInvalid'):return 'BLOCKED — invalid fixture',changed,mismatches
 if mismatches:return f'FAIL — {len(mismatches)} records differ after the attempted resolver switch',changed,mismatches
 if data.get('error') or data.get('assertionErrors'):return 'FAIL — resolver workflow; checked record values remain intact',changed,mismatches
 return ('PASS — replacement and exact record comparison' if changed else 'PASS — unsafe replacement blocked; checked records unchanged'),changed,mismatches

def resolver_table(config_id):
 items=resolver_imports(config_id)
 if not items:return ''
 result='<h3>Resolver replacement: separate fresh-fixture results</h3><p>These checks distinguish migration retention from a later resolver switch. A blocked editor does not by itself mean records were lost. Each row links its exact name, values and error evidence. Activity has a separate result: retained history does not clear a record-copy failure.</p><table><tr><th>Scenario / fixture</th><th>Migration</th><th>Resolver switch</th><th>Exact record comparison</th><th>Result</th><th>Activity retention</th></tr>'
 for file,data in items:
  verdict,changed,mismatches=import_outcome(data)
  before=data.get('beforeMigration',[]);after=data.get('afterMigration',[]);final=data.get('afterImport',data.get('finalRecords',[]))
  count=lambda values:f"{sum(v.get('got')==v.get('want') for v in values)}/{len(values)}" if values else 'NOT RUN'
  migration='PASS — V2 registered' if (data.get('finalState') or {}).get('status')==2 else 'NOT VERIFIED'
  switch='YES — new resolver recorded' if changed else 'NO — same resolver' if data.get('resolverAfterImport') else 'NOT COMPLETED / resolver address not captured'
  if data.get('recovery'):
   recovery=data['recovery'];switch+=f'<br>Recovery: {esc(recovery.get("result","NOT RUN"))}'
   if recovery.get('records'):switch+=f'<br>Original resolver restored: {count(recovery["records"])} records'
  details=''.join(f'<tr><td>{esc(r["what"])}</td><td><pre>{esc(r.get("want"))}</pre></td><td><pre>{esc(r.get("got"))}</pre></td></tr>' for r in final)
  exact_history=[(hf,hd) for hf,hd in history_items(config_id) if hd.get('subject')==data.get('subject',data.get('name'))]
  activity='NOT RUN — no exact original/final activity checkpoints in this older fixture' if not data.get('beforeActivity') or not data.get('afterActivity') else 'NOT RUN — separate real API and Explorer replay pending'
  if exact_history:
   hf,hd=exact_history[-1];activity=esc(history_outcome(hd))+'<br><a href="'+esc(str(hf.relative_to(OUT)))+'">Exact activity assertions</a>'
  result+=f'<tr><td>{esc(data.get("id"))}<br><a href="{esc(str(file.relative_to(OUT)))}">{esc(data.get("name","Exact fixture evidence"))}</a></td><td>{migration}<br>Before: {count(before)}<br>After migration: {count(after)}</td><td>{switch}</td><td>After import/attempt: {count(final)}<details><summary>All record values</summary><table><tr><th>Record</th><th>Expected</th><th>Actual</th></tr>{details}</table></details></td><td>{esc(verdict)}</td><td>{activity}</td></tr>'
 return result+'</table>'

def detached_lifecycle_table():
 result=''
 tables=[('detached-parent-lifecycle-comparison.json','detached-parent-comparison','Active third-level child: parent lifecycle comparison'),('locked-fourth-level-parent-lifecycle-comparison.json','locked-fourth-level-parent-comparison','Active fourth-level child: ancestor lifecycle comparison')]
 for filename,anchor,title in tables:
  path=OUT/filename
  if not path.exists():continue
  data=json.loads(path.read_text())
  result+='<section id="'+anchor+'"><h2>'+title+'</h2><p>'+esc(data['scope'])+'</p><table><tr><th>Case / parent at start</th><th>Migration check</th><th>Child public resolution: before → after</th><th>Original stored records</th><th>Holder editing after attempt</th><th>Indexed history</th></tr>'
  for row in data['rows']:
   result+=f'<tr><td><a href="cases/{esc(row["configuration"])}.html">{esc(row["configuration"])}</a><br>{esc(row["parent"])}</td><td>{esc(row["migration"])}</td><td>{esc(row["publicResolution"])}</td><td>{esc(row["sourceStorage"])}</td><td>{esc(row["editing"])}<br>{esc(row["otherLimits"])}</td><td>{esc(row["history"])}<br><a href="{esc(row["historySource"])}">Exact history</a></td></tr>'
  result+='</table><p><a href="'+esc(filename)+'">Exact fixture references and scope</a>. Successful migration did not retain the previous operator’s registry permissions or the resolver delegate’s editing authority; those measured changes remain visible in each case. Correct post-migration denial checks do not mean these permissions were preserved.</p></section>'
 return result

def history_items(config_id):
 return sorted([(file,data) for file,data in supplements.values() if data.get('id','').startswith('HISTORY-') and config_id in data.get('configurations',[])],key=lambda v:v[1].get('startedAt',''))

def history_outcome(data):
 checks=data.get('checks',{})
 if any(v.get('result')=='FAIL' and ('HTTP 500' in v.get('detail','') or 'Real history API returned500' in v.get('detail','')) for v in checks.values()):return 'FAIL — history API error; data loss not established'
 if any(v.get('result')=='FAIL' for v in checks.values()):return 'FAIL — indexed activity retention'
 blocked_checks=[label for label,value in checks.items() if value.get('result')=='BLOCKED']
 if blocked_checks and all('Explorer history' in label or 'Explorer retains every fixture transaction' in label for label in blocked_checks):return 'BLOCKED — Explorer history display not verified'
 if data.get('blocked') or blocked_checks:return 'BLOCKED — real indexer / original-chain check incomplete'
 if data.get('error') or data.get('assertionErrors'):return 'FAIL — indexed activity retention'
 if data.get('completedAt') and checks and all(v.get('result')=='PASS' for v in checks.values()):
  expanded=data.get('postActivityOracleVersion')=='post-activity-v1' and data.get('preV2ActivityOracleVersion')=='per-name-v2-baseline-v1'
  if not expanded:return f'PARTIAL PASS — {len(checks)} original history checks; expanded V2 history assertions not included in this run'
  if data.get('explorerActivityOracleVersion')!='all-fixture-transactions-v1':return f'PARTIAL PASS — {len(checks)} API and sampled Explorer checks; every fixture transaction link is not yet checked in Explorer'
  return f'PASS — {len(checks)} real API / Explorer history checks, including every original and post-baseline fixture transaction link'
 return 'IN PROGRESS — real indexed history'

def history_summary(config_id):
 items=history_items(config_id)
 if not items:
  versions=[d for _,d in runs.get(config_id,[])]
  fresh=any(d.get('completedAt') and not d.get('harnessInvalid') and not d.get('historyClockInvalid') and not d.get('error') and d.get('beforeActivity') and d.get('afterActivity') for d in versions)
  if fresh:return 'NOT RUN — valid fresh fixture saved; real indexer catching up'
  return 'BLOCKED — test-chain clock moved backwards; fresh history fixture required' if any(d.get('historyClockInvalid') for d in versions) else 'NOT RUN — live indexer catching up'
 outcomes=[history_outcome(data) for _,data in items]
 if any(x.startswith('FAIL') for x in outcomes):return next(x for x in outcomes if x.startswith('FAIL'))
 # A completed fresh replay can resolve earlier readiness failures for the
 # same fixture. All attempts remain in the detailed history table below.
 latest={data.get('subject'):(file,data) for file,data in items}
 # An explicitly reviewed fresh configuration can resolve a readiness blocker.
 # This does not prove the old fixture's missing display or erase real failures.
 recovered=set()
 by_source={str(file.relative_to(OUT)):data for file,data in items}
 for recovery in history_readiness_recoveries:
  if recovery.get('configuration')!=config_id:continue
  old=by_source.get(recovery.get('blockedSource'));fresh=by_source.get(recovery.get('passingSource'))
  if old and fresh and history_outcome(old).startswith('BLOCKED') and history_outcome(fresh).startswith('PASS'):
   recovered.add(recovery['blockedSource'])
 current=[history_outcome(data) for file,data in latest.values() if str(file.relative_to(OUT)) not in recovered]
 for prefix in ['BLOCKED','IN PROGRESS','PARTIAL']:
  if any(x.startswith(prefix) for x in current):return next(x for x in current if x.startswith(prefix))
 if recovered:return f'PASS — fresh expanded activity verification; {len(recovered)} earlier readiness-blocked fixture(s) remain documented, not passed retrospectively'
 return f'PASS — expanded indexed activity for {len(latest)} fixture(s), {len(items)} recorded read attempt(s)'

def history_table(config_id):
 items=history_items(config_id)
 if not items:return '<h3>Activity retention</h3><p><b>'+esc(history_summary(config_id))+'.</b> A recovered local chain with backwards timestamps cannot prove real indexed history; its original observations remain available. Fresh fixtures use a verified monotonic clock. Seeded discovery and saved chain logs do not count as indexed activity retention.</p>'
 result='<h3>Activity retention</h3><p>Actual chain transaction identities are compared with the complete paginated indexer response and the Explorer history page. Each read attempt remains visible, including failures followed by successful repeats. Older passes cover only their recorded assertions. The expanded Explorer check requires every original and post-baseline fixture transaction link across all pages; one sampled original link is now explicitly PARTIAL. API checks also cover existing and subsequent V2 events. This public history evidence does not imply wallet-specific edit authority.</p><table><tr><th>Fixture / read attempt</th><th>Check</th><th>Result</th><th>Evidence</th></tr>'
 for file,data in items:
  link=f'<a href="{esc(str(file.relative_to(OUT)))}">Exact transactions and returned history</a>'
  checks=data.get('checks',{}) or {'Indexer readiness':{'result':'BLOCKED' if data.get('blocked') else 'NOT RUN','detail':data.get('blocked','No completed check yet.')}}
  for label,value in checks.items():result+=f'<tr><td>{esc(data.get("subject"))}<br>{esc(data.get("startedAt",data.get("completedAt","")))}<br>{esc(history_outcome(data))}</td><td>{esc(label)}</td><td><b>{esc(value.get("result"))}</b><br>{esc(value.get("detail",""))}</td><td>{link}</td></tr>'
 return result+'</table>'

gaps=json.loads((OUT/'gaps.json').read_text()) if (OUT/'gaps.json').exists() else []
# Extend established findings only from completed, matching app assertions.
# A loading timeout, missing fixture or a contract-only probe does not qualify.
gap_by_id={g['id']:g for g in gaps}
for gid in ['MRT-01','MRT-02','MRT-04','MRT-05','MRT-07','MRT-08','MRT-10']:
 if gid in gap_by_id:
  g=gap_by_id[gid]
  g['previousCaseMappings']=sorted(set(g.get('previousCaseMappings',[])+g.get('cases',[])))
  g['previousEvidence']=sorted(set(g.get('previousEvidence',[])+g.get('evidence',[])))
  g['cases']=[];g['evidence']=[]
def map_gap(gid, aid, file):
 g=gap_by_id.get(gid)
 if not g:return
 if aid not in g['cases']:g['cases'].append(aid);g['cases'].sort()
 ref=str(file.relative_to(OUT))
 if ref not in g['evidence']:g['evidence'].append(ref)
for versions in runs.values():
 for file,d in versions:
  if not d.get('completedAt') or d.get('harnessInvalid'):continue
  for aid,actor in d.get('actors',{}).items():
   for stage in ['beforeUI','afterUI']:
    apps={a['app']:assessed_app(file,d,aid,stage,actor,a).get('checks',{}) for a in actor.get(stage,[])}
    mgr=apps.get('Manager',{});exp=apps.get('Explorer',{})
    m=mgr.get('editRecords',{});e=exp.get('editRecords',{})
    observed_missing=lambda check:(check.get('result')=='FAIL' and ('no usable edit entry although the exact resolver call is authorized' in check.get('detail','') or 'Direct editing is unavailable although the legacy resolver authorizes' in check.get('detail',''))) or (check.get('result')=='BLOCKED' and check.get('detail','').startswith('Acceptance rule pending:')) or (check.get('result')=='PASS' and check.get('detail','').startswith('Renewal required before editing:'))
    missing=lambda check:d['configuration'].get('root_lifecycle')!='Grace' and observed_missing(check)
    wrote=lambda check:check.get('result')=='PASS' and check.get('detail','').startswith('Submitted a distinct record')
    legacy=stage=='beforeUI' or bool(actor.get('afterRefusal'))
    if legacy and any(mgr.get(key,{}).get('result')=='FAIL' and exp.get(key,{}).get('result')=='FAIL' and 'Contract permits changing only the V1' in mgr[key].get('detail','') and 'Contract permits changing only the V1' in exp[key].get('detail','') for key in ['independentOwnerEdit','independentManagerEdit']):
     if 'MRT-07' not in gap_by_id:
      item={'id':'MRT-07','title':'Independent V1 owner and manager edits have no app workflow','status':'CONFIRMED — authorized contract action absent in both checked app surfaces','cases':[],'observed':'For the mapped unwrapped2LD wallet rows, the actual contract call permits changing one role, but Manager profile actions and Explorer Ownership/Roles provide no independent edit for that role. Full-name transfer is a separately tested action and cannot satisfy a requirement to preserve the other role.','workaround':'No independent-role workaround through the two new apps has been verified. Reclaim and full transfer are separately reported; neither is counted as an owner-only or manager-only edit.','limit':'Only executed wallet rows are included. The absence check covers the loaded profile and role/ownership surfaces. An added control must still pass a real isolated-role mutation and readback before this finding can be closed.','evidence':[]}
      gaps.append(item);gap_by_id['MRT-07']=item
     map_gap('MRT-07',aid,file)
    c=d['configuration']
    native_grace=c.get('root_lifecycle')=='Grace' and c.get('root_lifecycle_version')=='V2' and c.get('parent_migrated')=='Yes' and c.get('name_expiry')=='Active'
    holder=c['name_holder'] if c['name_holder'].startswith('W') else c['name_manager']
    if legacy and native_grace and actor.get('actor')==holder and observed_missing(m) and observed_missing(e):
     if 'MRT-08' not in gap_by_id:
      item={'id':'MRT-08','title':'Grace editing restriction matches the renewal-first requirement','status':'EXPECTED — renewal is required before editing','cases':[],'observed':'The active child holder is authorized by an actual source-resolver call, but both Manager and Explorer expose no usable record editor while the migrated ancestor is in grace. Universal resolution already fails before the child migration attempt; this is distinct from record loss. Compare the exact source-record and before/after resolution tables.','workaround':'Renewal is the required editing route; only separately executed recoveries count as verified.','limit':'GRACE-EDIT-01 requires renewal before editing. MIGRATION-GRACE-01 independently requires active emancipated-child migration despite V2 ancestor grace. An editing gate does not justify a migration refusal.','evidence':[]}
      gaps.append(item);gap_by_id['MRT-08']=item
     map_gap('MRT-08',aid,file)
     gap_by_id['MRT-08'].update(status='EXPECTED — renewal is required before editing (user-confirmed 2026-10-24); not a product failure', title='Grace editing restriction matches the renewal-first requirement', limit='Renewal before editing and independent emancipated-child migration are separate confirmed rules. A migration refusal due to V2 ancestor grace is assessed under MIGRATION-GRACE-01 / MRT-16.', workaround='Renewal is the required editing route. End-to-end renewal, restored resolution and subsequent editing are checked separately; no successful recovery is inferred from the edit gate.')
    if legacy and missing(m) and wrote(e):map_gap('MRT-01',aid,file)
    if legacy and actor.get('actor')=='Resolver delegate' and missing(m) and missing(e):map_gap('MRT-04',aid,file)
    if legacy and c['level']=='2LD' and c['root_type']=='Unwrapped' and mgr.get('ownerDisplay',{}).get('detail','').startswith('Displayed Owner points to a different wallet'):map_gap('MRT-02',aid,file)
    owner=mgr.get('ownerDisplay',{})
    if owner.get('result')=='FAIL' and owner.get('evidence',{}).get('oracleVersion')=='live-wrapper-holder-v1' and owner.get('detail','').startswith('NameWrapper reports no current holder'):
     if 'MRT-15' not in gap_by_id:
      item={'id':'MRT-15','title':'Manager shows a current Owner for an expired wrapped name with no current holder','status':'CONFIRMED — loaded owner link differs from actual wrapper state','cases':[],'observed':'The actual NameWrapper getData call returns the zero address as current holder at the tested expiry checkpoint. The loaded Manager profile nevertheless links an address as Owner; in the executed expired subname, that address is the wrapper contract itself. Registry custody, previous ownership and parent control must be distinguished from a current token holder.','workaround':'No viewing workaround has been independently verified for this exact expired-name case. Current wrapper state and original record storage remain available in the evidence.','limit':'This is an ownership-display finding for executed expired wrapped fixtures. It is separate from split V1 registrar-owner/manager labels and does not prove the name was lost during migration.','evidence':[]}
      gaps.append(item);gap_by_id['MRT-15']=item
     map_gap('MRT-15',aid,file)
    if stage=='afterUI' and not legacy and missing(e) and wrote(m) and actor.get('after',{}).get('resolver','').lower()=='0x8fade66b79cc9f707ab26799354482eb93a5b7dd':map_gap('MRT-05',aid,file)
if 'MRT-08' in gap_by_id and not gap_by_id['MRT-08']['cases']:
 gap_by_id['MRT-08']['status']='RETESTING — no current app conclusion after discovery correction; on-chain source storage and permissions remain measured'
if 'MRT-09' in gap_by_id:
 for versions in runs.values():
  for file,d in versions:
   c=d['configuration']
   if not d.get('completedAt') or d.get('harnessInvalid') or c.get('root_lifecycle_version')!='V2' or c.get('root_lifecycle')!='Grace':continue
   for check in d.get('appChecks',[]):
    evidence=check.get('evidence',{})
    if check.get('app')!='Explorer' or check.get('actor')!='Public view' or check.get('action')!='expiry and grace display: 2LD ancestor' or assessed_action(file,check)['result']!='FAIL':continue
    if evidence.get('protocol')!='V2' or not evidence.get('grace') or "getByText('Expires'" not in check.get('detail','') or 'Previous owner' not in evidence.get('screen',''):continue
    # The real indexed date page exhibits the same V1-style rendering as the
    # separately verified protocol/renewal finding. This is one public check,
    # shared by its wallet rows, not a new wallet-specific permission claim.
    for actor in c['actors']:map_gap('MRT-09',actor['case_id'],file)
    gap_by_id['MRT-09']['publicDisplayScope']='Linked public date checks apply to all wallet rows of that configuration. They do not imply additional wallet-specific renewal or permission executions.'
for sf,sd in supplements.values():
 if sd.get('id','').startswith('GRACE-RECOVERY-') and sd.get('completedAt') and not sd.get('error'):
  required=['Renewing ancestor restores all child records without replacing the child resolver','Child holder can edit through Explorer after ancestor renewal','Child migrates after ancestor renewal with exact records and correct holder']
  if all(sd.get('checks',{}).get(key,{}).get('result')=='PASS' for key in required):
   recovery_scope=sd.get('configuration',{}).get('config_id') or ', '.join(sd.get('configurations',[])) or sd.get('id','the linked fixture')
   for gid in ['MRT-08','MRT-09']:
    if gid not in gap_by_id:continue
    gap_by_id[gid]['workaround']=f"Verified only for {recovery_scope}: the ancestor owner renewed through {sd.get('renewalApp','Explorer')}; every seeded child record resolved again, the child holder submitted an Explorer edit, and Manager migrated the child with records and holder preserved. Other configurations require their own recovery evidence."
    if gid=='MRT-09':gap_by_id[gid]['status']='CONFIRMED — Explorer renewal missing; Manager renewal and subsequent child recovery verified'
    ref=str(sf.relative_to(OUT))
    if ref not in gap_by_id[gid]['evidence']:gap_by_id[gid]['evidence'].append(ref)
# Re-evaluate completed grace edits under the newly confirmed requirement,
# retaining raw strict results and distinguishing this from a fresh execution.
for config_id,(file,d) in observations.items():
 if d['configuration'].get('root_lifecycle')!='Grace':continue
 for actor in d['configuration']['actors']:
  probe=combined_probe(d,actor['case_id'])
  for stage in ['beforeUI','afterUI']:
   for app in probe.get(stage,[]):
    check=app.get('checks',{}).get('editRecords',{})
    if check.get('result')!='FAIL' or not ('edited a record during grace without renewal' in check.get('detail','') or 'committed a record edit during grace without renewal' in check.get('detail','')):continue
    if 'MRT-10' not in gap_by_id:
     item={'id':'MRT-10','title':'App permits record edits during grace without the required renewal','status':'CONFIRMED — committed edit conflicts with user-confirmed renewal-first policy','cases':[],'observed':'The app submitted a record edit while the name or its ancestor was in grace. Actual resolver storage/readback verified the new value, then the baseline was restored.','workaround':'Renew first as required. No app enforcement workaround is claimed.','limit':'Only completed, committed writes are mapped. Earlier observations are explicitly reassessed under the requirement confirmed on 2026-10-24; raw strict results remain unchanged.','evidence':[]}
     gaps.append(item);gap_by_id['MRT-10']=item
    source=OUT/probe.get('uiSources',{}).get(stage,{}).get('file',str(file.relative_to(OUT)))
    map_gap('MRT-10',actor['case_id'],source)
# Keep verified operator denials separate from transient form-navigation failures.
for versions in runs.values():
 for file,d in versions:
  if not d.get('completedAt') or d.get('harnessInvalid'):continue
  for check in d.get('appChecks',[]):
   if assessed_action(file,check)['result']!='FAIL' or check.get('actor')!='Operator':continue
   actor=next((a for a in d['configuration']['actors'] if a['actor']=='Operator'),None)
   probe=d.get('actors',{}).get(actor['case_id'],{}) if actor else {}
   stage=check.get('stage')
   authority=probe.get('before',{}) if stage=='before' else probe.get('afterRefusal',{}) if stage=='after' else {}
   permission={'change resolver':'setResolver','create subname':'createSubname','full name transfer':'transfer'}.get(check.get('action'))
   if not permission or authority.get(permission,{}).get('result')!='ALLOWED':continue
   screen=check.get('evidence',{}).get('screen','')
   if check.get('action') not in ['change resolver','create subname','full name transfer'] or not ('Permission Denied' in screen or 'Only its owner can create subnames' in screen or 'Not authorized' in screen):continue
   if 'MRT-11' not in gap_by_id:
    item={'id':'MRT-11','title':'Explorer blocks an approved V1 operator from resolver changes and child creation','status':'CONFIRMED — loaded UI denial despite contract permission','cases':[],'observed':'On the executed wrapped-subname fixture, the approved operator is permitted by independent contract simulations to change the resolver and create a child. Explorer displays Permission Denied or Only its owner can create subnames for that wallet. The existing holder can complete the corresponding workflows.','workaround':'The holder can perform the action; no way for the approved operator to complete it through the apps has been verified. This does not prove equivalent delegated access.','limit':'Only executed, loaded denials are mapped. Post-migration role tests and permission preservation are reported separately.','evidence':[]}
    gaps.append(item);gap_by_id['MRT-11']=item
   if actor:map_gap('MRT-11',actor['case_id'],file)
   gap_by_id['MRT-11']['limit']='Only executed, loaded denials with an independent ALLOWED contract probe for that same wallet and stage are mapped. After-refusal checks still concern V1 names; they do not claim that a migration occurred. Post-migration roles are reported separately.'
   if check.get('action')=='full name transfer':
    gap_by_id['MRT-11']['title']='Explorer blocks an approved V1 operator from resolver changes, child creation and transfer'
    gap_by_id['MRT-11']['observed']='On the linked wrapped V1 name fixtures, including a .eth root and subnames, independent contract simulations authorize the approved operator to change the resolver, create a child and transfer the name. Loaded Explorer pages deny those actions for that wallet. The existing holder completes the corresponding workflows; exact affected actions and stages are listed per case.'
# Parent re-issue is distinct from transferring an existing child holder.
# This supplemental route has its own exact parent-reassignment probe.
for sf,sd in supplements.values():
 if not sd.get('completedAt') or sd.get('actor')!='Operator':continue
 if sd.get('authority',{}).get('transferAsParent',{}).get('result')!='ALLOWED':continue
 for check in sd.get('appChecks',[]):
  if check.get('action')!='reissue expired subname through parent' or check.get('result')!='FAIL':continue
  if 'Only its owner can create subnames' not in check.get('evidence',{}).get('screen',''):continue
  actor=next((a for a in sd.get('configuration',{}).get('actors',[]) if a['actor']=='Operator'),None)
  if actor and 'MRT-11' in gap_by_id:
   map_gap('MRT-11',actor['case_id'],sf)
   gap_by_id['MRT-11']['parentReissueScope']='Also reproduced for CFG-0853: the approved parent operator has an ALLOWED exact parent-reassignment probe, but Explorer denies entry to the parent re-issue form. This is a permission-entry failure; the separate owner label-availability failure is MRT-17. No operator re-issue success is claimed.'
   if gap_by_id['MRT-11']['parentReissueScope'] not in gap_by_id['MRT-11']['observed']:
    gap_by_id['MRT-11']['observed']+=' '+gap_by_id['MRT-11']['parentReissueScope']
   gap_by_id['MRT-11']['workaround']='The holder completes the ordinary resolver, creation or transfer actions only where separately recorded. No equivalent app access for the approved operator is verified. For expired-child re-issue in CFG-0853, the parent owner is also blocked later by MRT-17, so switching to that owner is not a complete recovery.'
if 'MRT-13' in gap_by_id:
 gap_by_id['MRT-13']['title']='Explorer resolver page reports a missing registry for inactive V1 names'
 gap_by_id['MRT-13']['observed']='The Change resolver page shows Could not find registry for this name for executed V1 .eth names in grace and expired wrapped third- and fourth-level names, including subjects with V2 ancestors. It supplies neither an action nor an explicit permission, expiry or renewal explanation. The expired subjects were excluded from migration; this error does not mean they migrated or disappeared.'
 for versions in runs.values():
  for file,d in versions:
   c=d['configuration']
   grace_v1=c['level']=='2LD' and c['root_lifecycle']=='Grace' and c.get('root_lifecycle_version')!='V2'
   expired_v1=c.get('name_expiry')=='Expired' and d.get('migrationOutcome')=='expired subject excluded from UI; no wallet submission'
   if d.get('harnessInvalid') or not (grace_v1 or expired_v1):continue
   for check in d.get('appChecks',[]):
    if check.get('action')!='change resolver' or 'Could not find registry for this name.' not in check.get('evidence',{}).get('screen',''):continue
    if assessed_action(file,check)['result']!='FAIL':continue
    actor=next((a for a in c['actors'] if a['actor']==check.get('actor')),None)
    if actor:map_gap('MRT-13',actor['case_id'],file)
renewal_entry_file=OUT/'v1-grace-renewal-entry.json'
if renewal_entry_file.exists():
 entry=json.loads(renewal_entry_file.read_text())
 if 'MRT-14' not in gap_by_id:
  item={'id':'MRT-14','title':'Explorer V1 name page omits renewal during a renewable grace period','status':'CONFIRMED — loaded profile has no Extend action','cases':[],'observed':entry['observed'],'workaround':'No complete app renewal recovery verified yet. Manager renewal and subsequent resolver/record editing are being tested independently.','limit':entry['scope'],'evidence':['v1-grace-renewal-entry.json',entry['source']]}
  gaps.append(item);gap_by_id['MRT-14']=item
 original=observations.get(entry['configuration'])
 if original:
  actor=next((a for a in original[1]['configuration']['actors'] if a['actor']==entry['actor']),None)
  if actor:map_gap('MRT-14',actor['case_id'],OUT/entry['source'])
for sf,sd in supplements.values():
 if not sd.get('id','').startswith('V1-GRACE-RECOVERY-'):continue
 c=sd.get('configuration',{})
 for check in sd.get('appChecks',[]):
  if check.get('action')=='renew V1 root from its profile' and check.get('result')=='FAIL' and 'MRT-14' in gap_by_id:
   gap_by_id['MRT-14']['observed']='Fresh Explorer profiles display the V1 name’s grace dates but provide no Extend action. For each linked fixture the actual ETHRenewerV1 isRenewable call returned true before opening the profile. This was reproduced with both same-wallet and split owner/manager configurations.'
   actor=next((a for a in c.get('actors',[]) if a['actor']==check.get('actor')),None)
   if actor:map_gap('MRT-14',actor['case_id'],sf)
 if sd.get('checks',{}).get('Actual V1 renewal preserves every record and controller',{}).get('result')=='PASS':
  for view in sd.get('afterRenewalUI',[]):
   check=view.get('checks',{}).get('editRecords',{})
   if view.get('app')=='Manager' and check.get('result')=='FAIL' and 'no usable edit entry' in check.get('detail','') and 'MRT-01' in gap_by_id:
    actor=next((a for a in c.get('actors',[]) if a['actor']==c.get('root_manager')),None)
    if actor:map_gap('MRT-01',actor['case_id'],sf)
 recovered=sd.get('phase')=='completed V1 renewal recovery' and all(sd.get('checks',{}).get(key,{}).get('result')=='PASS' for key in ['Actual V1 renewal preserves every record and controller','Resolver action recovers after actual renewal','Record editing recovers after actual renewal'])
 if recovered:
  for gid in ['MRT-13','MRT-14']:
   if gid not in gap_by_id:continue
   proofs=gap_by_id[gid].setdefault('verifiedRecovery',[])
   proof={'configuration':c['config_id'],'source':str(sf.relative_to(OUT)),'renewalApp':sd['renewalApp'],'records':len(sd['afterRecords'])}
   if proof not in proofs:proofs.append(proof)
   gap_by_id[gid]['workaround']='Verified for '+', '.join(sorted({p['configuration'] for p in proofs}))+': renew through '+sd['renewalApp']+', then use Explorer for the resolver change and record edit. Actual expiry advancement, unchanged controller/resolver, every seeded record, the new write and exact cleanup were asserted. Other configurations require their own evidence.'
   if str(sf.relative_to(OUT)) not in gap_by_id[gid]['evidence']:gap_by_id[gid]['evidence'].append(str(sf.relative_to(OUT)))
for reference in ['locked-v1-renewal-recovery.json','locked-renewal-holder-audit.json','unlocked-renewal-holder-audit.json']:
 if (OUT/reference).exists():
  for gid in ['MRT-13','MRT-14']:
   if gid in gap_by_id and reference not in gap_by_id[gid]['evidence']:gap_by_id[gid]['evidence'].append(reference)
expired_reissue_file=OUT/'MRT-17-diagnostic.json'
if expired_reissue_file.exists():
 finding=json.loads(expired_reissue_file.read_text())
 if 'MRT-17' not in gap_by_id:
  item={key:finding[key] for key in ['id','title','status','observed','workaround','limit','evidence']}
  item['cases']=[];gaps.append(item);gap_by_id['MRT-17']=item
 for key in ['title','status','observed','workaround','limit']:gap_by_id['MRT-17'][key]=finding[key]
 for reference in finding['evidence']:
  if reference not in gap_by_id['MRT-17']['evidence']:gap_by_id['MRT-17']['evidence'].append(reference)
 map_gap('MRT-17',finding['caseId'],OUT/finding['source'])
 for case in finding.get('additionalCases',[]):
  if case.get('result')=='FAIL':map_gap('MRT-17',case['caseId'],OUT/case['source'])
 if 'MRT-17-diagnostic.json' not in gap_by_id['MRT-17']['evidence']:gap_by_id['MRT-17']['evidence'].append('MRT-17-diagnostic.json')
if history_api_failures:
 if 'MRT-12' not in gap_by_id:
  item={'id':'MRT-12','title':'History requests intermittently fail with a database transaction error','status':'CONFIRMED — actual HTTP500; subsequent API retry succeeded','cases':[],'observed':'Two independent local indexers returned HTTP500 for published four-level name histories. Both logged: SET TRANSACTION ISOLATION LEVEL must be called before any query. Subsequent direct reads returned the original history rows.','workaround':'A repeated direct API request succeeded for both affected names. A user-visible browser reload workaround has not yet been independently verified.','limit':'This is an intermittent history-access failure in the recorded local indexer image, not evidence of records or names being lost during migration. Image identity and source-investigation limits are recorded.','evidence':['history-api-transient-failures.json','history-parent-projection-reproduction.json']}
  gaps.append(item);gap_by_id['MRT-12']=item
 gap_by_id['MRT-12']['observed']='Published history requests intermittently returned HTTP500 for root names and subnames across three independent local indexers. The associated server logs report: SET TRANSACTION ISOLATION LEVEL must be called before any query. Subsequent direct reads returned history rows; the original failures remain recorded.'
 gap_by_id['MRT-12']['workaround']='Repeated direct API requests succeeded for the recorded affected names. A user-visible browser reload workaround has not yet been independently verified. Later successful reads do not erase the original access failures.'
 for failure in history_api_failures:
  recovery=failure.get('recoveryEvidence')
  if recovery and recovery not in gap_by_id['MRT-12']['evidence']:gap_by_id['MRT-12']['evidence'].append(recovery)
  config=observations.get(failure['configuration'])
  if config:
   for actor in config[1]['configuration']['actors']:map_gap('MRT-12',actor['case_id'],OUT/failure['source'])
for id,versions in runs.items():
 for file,data in versions:
  if not independent_grace_migration(data['configuration']) or data.get('harnessInvalid') or not str(data.get('migrationOutcome','')).startswith('blocked') or not data.get('refusalUI'):continue
  if 'MRT-16' not in gap_by_id:
   item={'id':'MRT-16','title':'Active emancipated subname migration is blocked while its V2 ancestor is in grace','status':'FAIL — contradicts user-confirmed MIGRATION-GRACE-01','cases':[],'observed':'The app shows a parent-upgrade refusal and prevents the active emancipated child from migrating, although the ancestor is already V2 and in grace. The user confirmed that the child must be able to migrate independently. Unchanged V1 records after the refusal do not make this eligibility check pass.','workaround':'Ancestor renewal followed by child migration was verified in the separate CFG-0864 recovery fixture. It requires an extra ancestor renewal and does not satisfy independent migration. No independent-migration workaround has been verified.','limit':'Original observations are reassessed against the newly confirmed requirement; they are not relabelled as fresh executions. New strict policy runs are queued. Renewal before record editing remains a separate requirement.','evidence':[]}
   gaps.append(item);gap_by_id[item['id']]=item
  for actor in data['configuration']['actors']:map_gap('MRT-16',actor['case_id'],file)
if 'MRT-16' in gap_by_id and (OUT/'MRT-16-diagnostic.json').exists():
 if 'MRT-16-diagnostic.json' not in gap_by_id['MRT-16']['evidence']:gap_by_id['MRT-16']['evidence'].append('MRT-16-diagnostic.json')
 detail=' Saved runtime diagnostics identify the missing-wrapper preflight error despite a successful prior ancestor-migration receipt. Contract-level independent migration has not been demonstrated.'
 if detail not in gap_by_id['MRT-16']['observed']:gap_by_id['MRT-16']['observed']+=detail
if 'MRT-16' in gap_by_id and (OUT/'MRT-16-historical-contract-diagnostic.json').exists():
 diagnostic=json.loads((OUT/'MRT-16-historical-contract-diagnostic.json').read_text())
 if diagnostic.get('standardHelperSimulation',{}).get('errorName')=='ParentNotMigrated':
  path='MRT-16-historical-contract-diagnostic.json'
  if path not in gap_by_id['MRT-16']['evidence']:gap_by_id['MRT-16']['evidence'].append(path)
  detail=' At the original grace block, historical calls confirmed that the parent wrapper still exists and the child is unexpired, but the parent registry returns no subregistry. Read-only simulation of the standard MigrationHelper route also reverts with ParentNotMigrated. This is separate diagnostic evidence, not an app migration or a demonstrated alternative workaround.'
  if detail not in gap_by_id['MRT-16']['observed']:gap_by_id['MRT-16']['observed']+=detail
if 'MRT-16' in gap_by_id:
 if (OUT/'MRT-16-fourth-level-diagnostic.json').exists():
  diagnostic=json.loads((OUT/'MRT-16-fourth-level-diagnostic.json').read_text())
  if diagnostic.get('directParentState',{}).get('status')==2 and diagnostic.get('standardHelperSimulation',{}).get('errorName')=='ParentNotMigrated':
   path='MRT-16-fourth-level-diagnostic.json'
   if path not in gap_by_id['MRT-16']['evidence']:gap_by_id['MRT-16']['evidence'].append(path)
   detail=' A separate fourth-level fixture also confirms the failure when the immediate V2 parent is active and only the V2 grandparent is in grace. Both ancestor migration receipts succeeded; direct reads still find the parent and its wrapper, but the root subregistry lookup returns zero and the standard helper reverts. The child remains V1.'
   if detail not in gap_by_id['MRT-16']['observed']:gap_by_id['MRT-16']['observed']+=detail
 fresh_policy_runs=[(file,d) for versions in runs.values() for file,d in versions if d.get('completedAt') and not d.get('harnessInvalid') and any(a.get('check','').startswith('MIGRATION-GRACE-01:') for a in d.get('retentionAssertions',[]))]
 fresh_ids={d['configuration']['config_id'] for _,d in fresh_policy_runs}
 fresh_failed={d['configuration']['config_id'] for _,d in fresh_policy_runs if any(a.get('check','').startswith('MIGRATION-GRACE-01:') and a.get('result')=='FAIL' for a in d['retentionAssertions'])}
 remaining=f'{14-len(fresh_ids)} remaining policy checks are queued or running.' if len(fresh_ids)<14 else 'All 14 policy configurations have a fresh execution; other wallet actions and activity checks remain separately tracked.'
 gap_by_id['MRT-16']['limit']=f'Original observations are reassessed with raw evidence retained. Fresh strict policy executions now cover {len(fresh_ids)} of 14 affected configurations; {len(fresh_failed)} have failed the independent-migration assertion. {remaining} Renewal before editing remains a separate requirement. Unchanged V1 records after refusal are not V2 retention.'
 if (OUT/'independent-grace-fresh-results.json').exists() and 'independent-grace-fresh-results.json' not in gap_by_id['MRT-16']['evidence']:gap_by_id['MRT-16']['evidence'].append('independent-grace-fresh-results.json')
 if (OUT/'independent-grace-execution-summary.json').exists() and 'independent-grace-execution-summary.json' not in gap_by_id['MRT-16']['evidence']:gap_by_id['MRT-16']['evidence'].append('independent-grace-execution-summary.json')
# A resolver-switch loss affects public resolution for every wallet row. Link
# that shared record result without claiming every wallet submitted the switch.
if 'MRT-06' in gap_by_id:
 for config_id, (_, data) in observations.items():
  supported=[item for item in resolver_imports(config_id) if 'supported' in item[1].get('id','')]
  if not supported:continue
  source, attempt=supported[-1]
  _, changed, missing=import_outcome(attempt)
  if attempt.get('harnessInvalid') or (attempt.get('finalState') or {}).get('status')!=2 or not changed:continue
  if {record.get('what') for record in missing}!={'ABI 2','ABI 4','ABI 8'}:continue
  for actor in data['configuration']['actors']:map_gap('MRT-06',actor['case_id'],source)
 gap_by_id['MRT-06']['sharedRecordScope']='All linked wallet rows share the same public record-loss result for that configuration. The resolver-switch transaction was executed only by the holder documented in the separate S4 fixture; these links do not imply additional wallet-specific executions.'
 if gap_by_id['MRT-06']['sharedRecordScope'] not in gap_by_id['MRT-06'].get('limit',''):
  gap_by_id['MRT-06']['limit']=gap_by_id['MRT-06'].get('limit','')+' '+gap_by_id['MRT-06']['sharedRecordScope']
write_changed(OUT/'gaps.json',json.dumps(priority.merge_findings(gaps,priority_integration),indent=2)+'\n')
rows={}; config_rows=[]
for id,(file,d) in sorted(observations.items()):
 c=d['configuration']; complete=bool(d.get('completedAt')); errors=d.get('assertionErrors',[]); failure=bool(d.get('error') or errors)
 phase=d.get('phase','')
 # The bounded local-wallet guard aborts the fixture before further actions.
 # Keep completed action failures, but do not label the interruption itself an
 # unexplained product failure. Raw observations and strict exits are retained.
 execution_incomplete=bool(d.get('executionIncomplete')) or str(d.get('error','')).removeprefix('Error: ').startswith('Local matrix wallet request did not settle before the transaction deadline; fresh fixture required.')
 fixture_block=failure and (execution_incomplete or bool(d.get('harnessInvalid')) or phase=='fixture' or any("reading 'emit'" in e for e in errors))
 state=d.get('afterState') or {}; migrated=state.get('status')==2
 independent_required=independent_grace_migration(c)
 independent_refused=independent_required and str(d.get('migrationOutcome','')).startswith('blocked')
 actual_refused=str(d.get('migrationOutcome','')).startswith(('blocked','expired subject'))
 before=d.get('beforeRecords',[]); after=d.get('afterRecords',[])
 mismatches=[r for r in after if r['got']!=r['want']]
 blocked_expected=(c['expected_migration'].startswith('BLOCK') and not d.get('effectiveExpectation','').startswith('Parent-first requirement can')) or (bool(d.get('requirementDecisionPending')) and str(d.get('migrationOutcome','')).startswith('blocked'))
 continuity=bool(after) and after==before
 stage=('BLOCKED — incomplete execution' if execution_incomplete else 'BLOCKED — fixture') if fixture_block else 'FAIL — assertion/flow; triage pending' if failure else 'PARTIAL — execution continues' if complete else 'IN PROGRESS'
 records='NOT RUN'
 if after:
  records=('PARTIAL PASS — unchanged V1 records after failed required migration; post-migration retention NOT RUN' if continuity else 'FAIL — V1 resolution changed after refused migration') if independent_refused else (('PARTIAL PASS — V1 continuity; migration correctly not attempted' if continuity else 'FAIL — V1 resolution changed') if blocked_expected else ('FAIL — post-migration record mismatch' if mismatches else f'PARTIAL PASS — {len(after)}-record S2 bundle; S4 pending'))
 imports=resolver_imports(id)
 supported=[(sf,sd) for sf,sd in imports if 'supported' in sd.get('id','')]
 # S4 is an independently migrated fixture. A later setup interruption must
 # not erase its observed resolver-switch loss or borrow its migration state.
 supported_migrated=bool(supported) and (supported[-1][1].get('finalState') or {}).get('status')==2
 if supported_migrated:
  _,sd=supported[-1];verdict,changed,missing=import_outcome(sd)
  if migrated and after and not mismatches:records=f'S2 PASS — {len(after)} records'
  records+='; S4 separate migrated fixture: '+verdict+f' ({len(sd.get("beforeMigration",[]))} records)'
 expanded=[(rf,rd) for rf,rd in record_bundle_runs(id) if len(rd['afterRecords'])>len(after)]
 if expanded:
  rf,rd=max(expanded,key=lambda item:(len(item[1]['afterRecords']),item[1].get('startedAt','')))
  rb=rd['beforeRecords'];ra=rd['afterRecords'];refused=str(rd.get('migrationOutcome','')).startswith(('blocked','expired subject'))
  valid=(ra==rb) if refused else (rd.get('afterState') or {}).get('status')==2 and all(r['got']==r['want'] for r in ra)
  records+=f'; expanded {len(ra)}-record fresh fixture: '+('PASS — refusal continuity' if refused and valid else 'PASS — migration retention' if valid else 'FAIL — see bundle comparison')
 ref=str(file.relative_to(OUT))
 retention=assertions_by_file.get(ref,d.get('retentionAssertions',[]))
 for actor in c['actors']:
  aid=actor['case_id']; probe=combined_probe(d,aid)
  ui_fail=any(check.get('result')=='FAIL' for st in ['beforeUI','afterUI'] for app in probe.get(st,[]) for check in app.get('checks',{}).values())
  failures=[(st,key) for st in ['beforeUI','afterUI'] for app in probe.get(st,[]) for key,check in app.get('checks',{}).items() if check.get('result')=='FAIL']
  workaround_only=bool(failures) and all(key=='editRecords' and combined_edit(probe,st)['result']=='PASS' for st,key in failures)
  if workaround_only:ui_fail=False
  flow_errors=[e for e in errors if app_assertion_scope(d,e) is None]
  flow_fail=bool(d.get('error')) or bool(flow_errors)
  row_stage=('FAIL — app workflow' if ui_fail else stage) if fixture_block or flow_fail or ui_fail else 'PARTIAL — execution continues' if complete else 'IN PROGRESS'
  if workaround_only and not fixture_block and not flow_fail:row_stage='PARTIAL — verified app workaround'
  actor_assertions=[a for a in retention if a.get('actor') in [None,aid]]
  role_assertions=[a for a in actor_assertions if any(word in a.get('check','').lower() for word in ['role','authority','authorization'])]
  if any(a['result']=='FAIL' for a in actor_assertions):row_stage='FAIL — retention assertion'
  if supported_migrated and import_outcome(supported[-1][1])[2]:row_stage='FAIL — resolver replacement retention'
  workflow_checks={app+': '+stage+': '+key:value for app in ['Manager','Explorer'] for stage in ['before','after'] for key,value in action_checks(c,actor['actor'],app,stage).items()}
  if any(a['result']=='FAIL' for a in workflow_checks.values()):row_stage='FAIL — app workflow'
  if history_summary(id).startswith('FAIL'):row_stage='FAIL — activity retention'
  if independent_refused and not fixture_block:row_stage='FAIL — migration eligibility'
  row_gaps=[g for g in gaps if aid in g.get('cases',[])]
  notes=[f"{id}; subject {d.get('subject','not seeded')}; phase: {phase}."]
  if before: notes.append(f"Before: {sum(r['got']==r['want'] for r in before)}/{len(before)} records resolve exactly.")
  if after: notes.append(f"After: {sum(r['got']==r['want'] for r in after)}/{len(after)} records resolve exactly. V2 registered: {'yes' if migrated else 'no'}.")
  if probe: notes.append('Contract permission simulations recorded; these do not prove completed UI action workflows.')
  if probe.get('uiSources'): notes.append('App checks cite separate fresh fixtures with the same configuration; a record-only rerun does not erase prior app failures.')
  if c['root_lifecycle']=='Grace': notes.append('User-confirmed app rule: renew before editing. Saved completed editor/write observations are reassessed under this rule; raw strict results remain unchanged. Migration eligibility is a separate requirement.')
  if d.get('requirementDecisionPending'): notes.append(d['requirementDecisionPending'])
  if d.get('requirementReassessment'):notes.append(d['requirementReassessment'])
  if independent_refused:notes.append('MRT-16: required independent migration was refused. After-attempt checks remain V1 observations; V2 retention was not exercised.')
  if d.get('effectiveExpectation'): notes.append('Execution expectation: '+d['effectiveExpectation']+'.')
  if d.get('executionIncomplete'):notes.append(d['executionIncomplete']['reason'])
  if d.get('error') or flow_errors:notes.append(str(d.get('error') or flow_errors[0])[:1600])
  elif failure:notes.append('The original fixture recorded wallet-specific strict assertion failures. Current results above are scoped to this wallet; all original failures remain in the configuration evidence.')
  rows[aid]={
   'overall_result':row_stage,
   'records_result':records,
   'roles_result':('V2 role retention NOT RUN — required migration failed. V1 authority after refusal: ' if independent_refused else '')+role_result(role_assertions,probe,actor['actor']),
   'permissions_result':permission_change_summary(probe,migrated)+(('PARTIAL — actual app checks: '+', '.join(k+': '+v['result'] for k,v in workflow_checks.items())) if workflow_checks else 'PARTIAL — record editing tested in apps; other actions pending' if probe.get('beforeUI') or probe.get('afterUI') else 'PARTIAL — contract call probes; UI writes pending' if probe.get('before') else 'NOT RUN'),
   'activity_result':history_summary(id),
   'before_manager_result':ui_result(probe,'beforeUI','Manager') if probe.get('beforeUI') else 'PARTIAL — migration selection only' if actor['actor']==(c['name_holder'] if 'Native' in c['expected_migration'] else c['root_owner']) and d.get('reviewUI') else 'NOT RUN',
   'after_manager_result':ui_result(probe,'afterUI','Manager') if probe.get('afterUI') else 'PARTIAL — migration outcome only' if d.get('migrationOutcome')=='success' and actor['actor']==c['root_owner'] else 'NOT RUN',
   'before_explorer_result':ui_result(probe,'beforeUI','Explorer'),'after_explorer_result':ui_result(probe,'afterUI','Explorer'),
   'combined_record_edit_result':' | '.join(('Before: ' if st=='beforeUI' else 'After: ')+combined_edit(probe,st)['result']+' — '+combined_edit(probe,st)['detail'] for st in ['beforeUI','afterUI']),
   'actual_outcome':' '.join(notes),
   'workaround':' '.join(g['id']+': '+g['workaround'] for g in row_gaps) or 'No product workaround verified. Discovery uses seeded fixture inventory; live history is checked separately.',
   'evidence':f"execution/cases/{id}.html; execution/{ref}",
  }
 config_ui_errors=[]
 for actor in c['actors']:
  cp=combined_probe(d,actor['case_id'])
  for st in ['beforeUI','afterUI']:
   for app in cp.get(st,[]):
    for action,check in app.get('checks',{}).items():
     if check.get('result')=='FAIL':config_ui_errors.append(f"{actor['case_id']} {st} {app['app']} {action}: {check['detail']}")
 if (config_ui_errors or any(rows[a['case_id']]['overall_result'].startswith('FAIL') for a in c['actors'])) and not fixture_block:stage='FAIL — app workflow/retention; see separate fixture evidence'
 if independent_refused and not fixture_block:stage='FAIL — migration eligibility (MRT-16); V2 retention NOT RUN'
 policy_errors=['MRT-16 / MIGRATION-GRACE-01: active emancipated child must migrate independently despite V2 ancestor grace; actual app refused migration.'] if independent_refused else []
 display_errors=list(dict.fromkeys(errors+config_ui_errors+policy_errors))
 loss_summary=('Migration did not occur. Before/after V1 record reads are identical, including any existing expiry refusal; V2 retention was not tested.' if actual_refused and continuity else 'No loss observed during migration in the checked bundle. Any later resolver replacement is reported separately below.' if migrated and after and not mismatches else 'Do not infer loss from a missing migration or failed read. See each raw read below.')
 values=''
 after_map={r['what']:r for r in after}
 for r in before or d.get('activeRecords',[]):
  a=after_map.get(r['what'])
  before_status='PASS' if r['got']==r['want'] else 'NOT RESOLVING — expiry baseline' if c['root_lifecycle']=='Grace' or c['name_expiry'].startswith('Expired') else 'FAIL'
  after_status=('NOT RUN' if not a else 'UNCHANGED — still V1 after refused migration; post-migration NOT RUN' if actual_refused and a['got']==r['got'] else 'PASS' if a['got']==a['want'] else 'FAIL')
  values+=f"<tr><td>{esc(r['what'])}</td><td>{before_status}</td><td>{after_status}</td><td><details><summary>Values</summary><b>Expected</b><pre>{esc(r['want'])}</pre><b>Before</b><pre>{esc(r['got'])}</pre><b>After</b><pre>{esc(a['got'] if a else 'NOT RUN')}</pre></details></td></tr>"
 config_rows.append(f'''<section id="{id}"><h2>{id} — {esc(c['level'])}, {esc(c['root_type'])} root / {esc(c['wrapping'])} subject</h2><p><b>Subject lifecycle:</b> {esc(c['root_lifecycle'] if c['level']=='2LD' else c['name_expiry'])}. <b>2LD ancestor lifecycle:</b> {esc('Not applicable — the subject is the 2LD' if c['level']=='2LD' else c['root_lifecycle_version']+' '+c['root_lifecycle'])}.</p><p><b>{esc(stage)}</b> · {len(c['actors'])} wallet rows · <a href="{esc(ref)}">Raw observations</a></p><table><tr><th>Question</th><th>Observed</th></tr><tr><td>Migration expectation tested</td><td>{esc(d.get('effectiveExpectation') or c['expected_migration'])}{('<br>Matrix starting condition: '+esc(c['expected_migration'])) if d.get('effectiveExpectation') and d['effectiveExpectation']!=c['expected_migration'] else ''}</td></tr><tr><td>Current phase</td><td>{esc(phase)}</td></tr><tr><td>Did the subject actually migrate?</td><td>{'YES — V2 registered' if migrated else 'NO — refused or excluded before migration; V2 retention not exercised' if actual_refused else 'NO V2 registration observed — inspect flow and raw state' if 'afterState' in d else 'NOT CHECKED'}</td></tr><tr><td>Was the name lost during migration?</td><td>{esc(loss_summary)}</td></tr><tr><td>Flow result</td><td>{esc(d.get('migrationOutcome',d.get('error','Running')))}</td></tr><tr><td>Test failures</td><td><details><summary>{len(display_errors)} failed assertions/observations — show details</summary><pre>{esc(chr(10).join(display_errors) if display_errors else d.get('error','None recorded so far'))}</pre></details></td></tr><tr><td>Workaround</td><td>{esc(" ".join(g["id"]+": "+g["workaround"] for g in gaps if any(a["case_id"] in g.get("cases",[]) for a in c["actors"])) or "No product workaround verified. Test infrastructure changes are listed separately.")}</td></tr><tr><td>Coverage limit</td><td>Discovery is mocked from seeded fixtures. Contract probes are read-only simulations. Completed app writes are identified explicitly in the wallet table. S4 resolver import has separate scenario-specific results below; real indexed activity is reported separately with its own evidence. App workflow results below are shown only where actually executed. Record and app layers may use separate fresh fixtures with the same configuration; each app cell links its own fixture evidence. A later record-only run does not clear an earlier app failure.</td></tr></table>{record_lifecycle_diagnostic(id)}{ancestor_grace_record_diagnostic(id)}{live_ancestor_record_checkpoints(id)}<h3>Record-by-record comparison</h3><table><tr><th>Record</th><th>Before</th><th>After</th><th>Details</th></tr>{values or '<tr><td colspan="4">No completed record read yet.</td></tr>'}</table>{actor_table(d)}{contract_table(d)}<details><summary>Exact role, permission and expiry assertion results</summary><pre>{esc(json.dumps(retention,indent=2))}</pre></details><details><summary>Connected-wallet permission observations</summary><pre>{esc(json.dumps({k:{part:obs for part,obs in v.items() if part not in ['beforeUI','afterUI']} for k,v in d.get('actors',{}).items()},indent=2))}</pre></details></section>''')
meta={'status':'EXECUTION IN PROGRESS','candidate_commit':'6d24b082f11a8ed0d2500281ac06d5e76b4fc72e','executed_configurations':len(observations),'execution_note':'Supporting units: 698 passed. Matrix results come only from recorded runtime evidence; partial checks are not whole-row passes.'}
result={'metadata':meta,'rows':rows}
priority.merge(result,priority_integration)
retention_report.merge(result,retention_integration)
write_changed(OUT/'matrix-results.json',json.dumps(result,indent=2))
write_changed(OUT/'execution-interruptions.json',json.dumps(execution_interruptions,indent=2)+'\n')
summary=Counter(r['overall_result'] for r in rows.values())
coverage={'record_role_outcomes':sum(bool(d.get('afterRecords')) and any(a.get('before') for a in d.get('actors',{}).values()) for _,d in observations.values()),'post_authority':sum(all((d.get('actors',{}).get(a['case_id'],{}).get('after') or d.get('actors',{}).get(a['case_id'],{}).get('afterRefusal')) for a in d['configuration']['actors'] if a['actor']!='Disconnected') for _,d in observations.values()),'four_app_checkpoints':0}
for _,d in observations.values():
 for actor in d['configuration']['actors']:
  probe=combined_probe(d,actor['case_id'])
  if all(any(app.get('app')==name and 'editRecords' in app.get('checks',{}) and 'recordsVisible' in app.get('checks',{}) for app in probe.get(stage,[])) for stage in ['beforeUI','afterUI'] for name in ['Manager','Explorer']):coverage['four_app_checkpoints']+=1
queue_file=OUT/'remaining-action-queue.json';action_queue=json.loads(queue_file.read_text()) if queue_file.exists() else {'pending':[],'claimed':[]}
finished_actions=sum(c.get('status')=='completed' for c in action_queue['claimed'])
extra=f'<h2>Execution coverage</h2><table><tr><th>Layer</th><th>Current coverage</th><th>What this means</th></tr><tr><td>Record outcomes and baseline authority</td><td>{coverage["record_role_outcomes"]} / 986 configurations</td><td>Actual post-attempt record reads and baseline authority probes exist. Post-attempt authority and app actions are reported separately; this count does not imply those checks passed.</td></tr><tr><td>Post-attempt authority comparison</td><td>{coverage["post_authority"]} /986 configurations</td><td>Every connected wallet has post-migration or post-refusal contract reads. Exact assertion outcomes appear in the case tables.</td></tr><tr><td>Before/after app checkpoints</td><td>{coverage["four_app_checkpoints"]} / 6,218 wallet rows attempted in both apps</td><td>Record viewing and editing were checked at all four checkpoints. This count includes failures and blockers and does not certify every action.</td></tr><tr><td>Additional actual action runs</td><td>{finished_actions} completed; {len(action_queue["pending"])} queued configuration/layer runs</td><td>Independent transfer, resolver switch and child-control fixtures, including additional wallet roles. A run can contain multiple wallet tests; product failures remain failures.</td></tr></table>'
if (OUT/'local-chain-crash-P.json').exists():
 extra+='<p><b>Local test-chain interruption:</b> One chain stopped after an upstream storage read timed out. Its saved snapshot ends 354 blocks before its last audited head. Completed live checks, including their verified activity history, remain recorded; an exact final-head archive or replay is not claimed. The interrupted setup is BLOCKED and fresh fixtures are used for continued execution. <a href="local-chain-crash-P.json">Crash, preserved data and replacement details</a>.</p>'
if (OUT/'crashed-chain-expanded-history-recovery.json').exists():
 recovery=json.loads((OUT/'crashed-chain-expanded-history-recovery.json').read_text())
 affected=', '.join(f'<a href="cases/{esc(row["configuration"])}.html">{esc(row["configuration"])}</a>' for row in sorted(recovery['rows'],key=lambda row:row['configuration']))
 extra+=f'<p><b>Expanded activity checks on the unavailable chain:</b> {len(recovery["rows"])} replay attempts are BLOCKED because the original transaction receipts cannot be read. This is not evidence of lost name activity. Fresh complete app workflows and separate activity checks are being used to recover configuration coverage; the original attempts remain unchanged. Affected cases: {affected}. <a href="crashed-chain-expanded-history-recovery.json">Recovery scope and evidence</a>.</p>'
recovery_file=OUT/'upstream-recovery-ui-results.json'
if recovery_file.exists():
 recovery=json.loads(recovery_file.read_text())
 extra+='<h2 id="upstream-recovery-checks">Fresh checks after environment recovery</h2><p>The earlier interrupted attempts remain BLOCKED. These are separate fresh executions of the same configuration and wallet. Both checkpoints below are V1: migration was refused. They do not establish post-V2 permission retention.</p><table><tr><th>Case / wallet</th><th>Fresh result</th><th>Executed scope</th><th>Evidence</th></tr>'
 for item in recovery['rows']:
  scope='Waiting for completion; no pass claimed.'
  if item['status']=='PASS':scope='6/6 Explorer actions passed: change resolver, create subname and transfer, before and after refusal. All 18 subject records still resolve and all 18 source values match. Exact holder/manager restored.'
  elif item.get('completedAt'):scope='The fresh attempt did not verify the complete workflow; inspect its individual assertions.'
  link=('<a href="'+esc(item['source'])+'">Fresh assertions</a>') if item.get('source') and (OUT/item['source']).exists() else 'Fresh fixture queued or running'
  extra+='<tr><td>'+esc(item['configuration']+' / '+item['actor'])+'</td><td>'+esc(item['status'])+'</td><td>'+esc(scope)+'</td><td>'+link+'</td></tr>'
 extra+='</table><p>Intermittent RPC timeouts are still tracked separately; an environment recovery is not a product workaround. <a href="upstream-recovery-ui-results.json">Full recovery evidence and limits</a>.</p>'
workaround_coverage=OUT/'parent-reclaim-workaround-coverage.json'
if workaround_coverage.exists():
 wc=json.loads(workaround_coverage.read_text())
 history_status_file=OUT/'parent-reclaim-history-status.json'
 workaround_history=json.loads(history_status_file.read_text()) if history_status_file.exists() else {'rows':[]}
 workaround_history_by_source={row['source']:row for row in workaround_history.get('rows',[])}
 extra+='<h2 id="parent-reclaim-workaround">Parent reclaim and child transfer: complete workaround</h2><p>Connected as the .eth parent’s token owner, these checks follow Explorer’s parent link, reclaim the manager role, return to the child and submit its transfer. They check both names’ records and restore the original controllers. Reclaiming temporarily replaces the previous parent manager; it does not preserve that wallet’s role. After-refusal checks first execute the Manager refusal and verify the unchanged tree and permissions. They remain V1 workflows.</p><table><tr><th>Configuration</th><th>Before migration</th><th>After actual migration refusal</th></tr>'
 for config_id in wc['eligibleConfigurations']:
  cells=[]
  for prefix in ['PARENT-RECLAIM-TRANSFER-','REFUSAL-PARENT-RECLAIM-TRANSFER-']:
   item=supplements.get(prefix+config_id)
   if not item:
    cells.append('NOT RUN — queued' if prefix=='PARENT-RECLAIM-TRANSFER-' or config_id in wc.get('afterRefusalQueued',[]) else 'N/A — recreation is enabled; successful V2 workflows are checked separately')
    continue
   sf,sd=item;checks=sd.get('checks',{});results=[v.get('result') for v in checks.values()]
   strict_file=sf.parent.parent/'strict-results.json';strict=json.loads(strict_file.read_text()) if strict_file.exists() else []
   status='RUNNING'
   if sd.get('completedAt') and strict:
    status='BLOCKED' if 'BLOCKED' in results else 'FAIL' if sd.get('error') or sd.get('assertionErrors') or sd.get('cleanupError') or 'FAIL' in results or any(t.get('status')!='passed' for t in strict) else 'PASS' if results and all(r=='PASS' for r in results) and sd.get('cleanup','').startswith('PASS') else 'BLOCKED — incomplete evidence'
   source_path=str(sf.relative_to(OUT))
   history_row=workaround_history_by_source.get(source_path,{})
   history_status=history_row.get('status','NOT RUN')
   if history_status=='PASS' and history_row.get('historySource'):
    history_file=OUT/history_row['historySource']
    if history_file.exists() and json.loads(history_file.read_text()).get('explorerActivityOracleVersion')!='all-fixture-transactions-v1':history_status='PARTIAL — API and sampled Explorer checks passed; every transaction link still needs checking'
   history_link=' · <a href="'+esc(history_row['historySource'])+'">Activity assertions</a>' if history_row.get('historySource') else ''
   cells.append(esc(status)+' · <a href="'+esc(source_path)+'">Exact assertions</a><br>Activity retention: '+esc(history_status)+history_link)
  extra+='<tr><td><a href="cases/'+config_id+'.html">'+config_id+'</a></td><td>'+cells[0]+'</td><td>'+cells[1]+'</td></tr>'
 extra+='</table><p>A loaded “Reclaim the parent first” screen verifies guidance only. It does not count as a completed workaround. Activity retention has its own status: it requires exact original and workflow events in the real indexer and Explorer for both names. Captured chain logs alone do not establish PASS. <a href="parent-reclaim-workaround-coverage.json">Coverage and scope</a>.</p>'
extra+=independent_grace_table()
extra+=detached_lifecycle_table()
extra+=ancestor_record_checkpoint_summary()
extra+='<p><a href="execution-interruptions.json">Interrupted fixture executions</a> remain BLOCKED at the run level. Any completed wallet-specific failure is still reported separately; original strict test results are retained.</p><p><b>Confirmed acceptance rules:</b> renewal is required before record editing in grace, even when the resolver authorizes the wallet. Separately, an active emancipated subname must be allowed to migrate independently while its already-migrated V2 parent or ancestor is in grace. Saved observations are reassessed with originals retained; fresh strict executions are identified separately. Loading failures remain blocked. Unchanged V1 data after a refused migration does not prove V2 retention. <a href="acceptance-decisions.json">Decision record</a></p><h2 id="findings">Findings, expected restrictions and workarounds</h2><table class="findings-table"><tr><th>Finding</th><th>Cases</th><th>Observed</th><th>Workaround / evidence</th></tr>'+''.join(f"<tr><td><b>{esc(g['id'])} — {esc(g['title'])}</b><br>{esc(g['status'])}</td><td>{esc(', '.join(g['cases']))}</td><td>{esc(g['observed'])}<br>{esc(g['limit'])}</td><td>{esc(g['workaround'])}<br>"+''.join(f'<a href="{esc(e)}">Evidence</a> ' for e in g['evidence'])+'</td></tr>' for g in gaps)+'</table>'
if (OUT/'resource-capacity-adjustment.json').exists():
 capacity=json.loads((OUT/'resource-capacity-adjustment.json').read_text()).get('latestReview',{}).get('maximumConcurrentFixtures',4)
 extra+=f'<p><b>Execution capacity:</b> new fixtures wait for one of {capacity} shared browser-test slots. Existing tests finish normally; queued fixtures remain untested. Capacity is reviewed against actual machine load to keep loading failures separate from app failures. <a href="resource-capacity-adjustment.json">Capacity adjustment</a> · <a href="resource-slot-concurrency-verification.json">Admission check</a></p>'
extra+='<h2>Additional executed retention checks</h2><table><tr><th>Scenario</th><th>Result</th><th>Checks / limit</th><th>Evidence</th></tr>'
assessed_supplements={str(sf):sd for sf,sd in supplements.values()}
for sf in sorted(OUT.glob('matrix-*/supplemental/*.json')):
 sd=assessed_supplements.get(str(sf)) or json.loads(sf.read_text()); checks=sd.get('checks',{}); status=('BLOCKED — test harness' if sd.get('harnessInvalid') else history_outcome(sd) if sd.get('id','').startswith('HISTORY-') else 'BLOCKED — limited fixture discovery' if sd.get('harnessLimit') and all(v.get('result')!='FAIL' for v in checks.values()) else 'FAIL' if sd.get('assertionErrors') or sd.get('error') else sd.get('result') or ('PASS' if sd.get('completedAt') else 'IN PROGRESS'))
 extra+=f"<tr><td>{esc(sd.get('id',sf.stem))}</td><td>{esc(status)}</td><td>{esc('; '.join(k+': '+v['result'] for k,v in checks.items()) or sd.get('phase',''))}<br>Applies only to the recorded scenario, not all configurations.</td><td><a href=\"{esc(str(sf.relative_to(OUT)))}\">Raw assertions and transactions</a></td></tr>"
extra+='</table><p><b>Snapshot recovery:</b> Several test chains hit the shared local VM memory limit during history backfill. Their verified checkpoint details and affected reruns are retained in history-bootstrap. The history router now bounds its in-memory transaction lookup cache while preserving disk responses and chain history. C retains the documented unrecovered old historical-storage tail; subsequent fixtures use fresh evidence. Fresh runs use larger chain limits and less frequent full snapshots. Indexed-history checks must verify each original transaction on the recovered chain. See <a href="history-bootstrap/C-snapshot-recovery.json">the exact recovery limitation</a> and <a href="run-metadata.json">run metadata</a>.</p>'
case_directory=OUT/'cases';case_directory.mkdir(exist_ok=True)
case_summaries=[]
case_style='<style>body{font:15px/1.55 system-ui;max-width:1250px;margin:32px auto;padding:0 20px;color:#17382d;background:#f5f8f5}table{border-collapse:collapse;width:100%;background:white;margin:12px 0}td,th{border:1px solid #cbd9d1;padding:10px;text-align:left;vertical-align:top}th{background:#e6f1e9}a{color:#08674e}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}summary{cursor:pointer}</style>'
for section in config_rows:
 case_id=section.split('id="',1)[1].split('"',1)[0]
 section=retention_report.panel(retention_integration,prefix='../',config=case_id)+priority.panel(priority_integration,prefix='../',config=case_id)+'<p><b>Earlier campaign evidence — commit 6d24b082f11a8.</b> Any newer checks are presented separately and do not replace unrelated results below.</p>'+section
 section+=source_record_table(observations[case_id][1])+record_bundle_table(case_id)+resolver_table(case_id)+history_table(case_id)
 doc=f'<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><base href="../"><title>{case_id} — Migration evidence</title>'+case_style+'<p><a href="Campaign%20status.html">Campaign results</a> · <a href="../Flattened%20migration%20matrix.html">Flattened matrix</a></p>'+section+'</html>'
 write_changed(case_directory/(case_id+'.html'),doc)
 case_summaries.append(f'<section id="{case_id}"><a href="cases/{case_id}.html"><b>{case_id}</b> — open before/after tables, exact records and assertions</a></section>')
page='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Migration matrix execution results</title><style>body{font:15px/1.55 system-ui;max-width:1250px;margin:32px auto;padding:0 20px;color:#17382d;background:#f5f8f5}table{border-collapse:collapse;width:100%;background:white;margin:12px 0}td,th{border:1px solid #cbd9d1;padding:10px;text-align:left;vertical-align:top}th{background:#e6f1e9}a{color:#08674e}section{margin:40px 0;padding-top:15px;border-top:3px solid #cbd9d1}pre{white-space:pre-wrap;overflow-wrap:anywhere;max-width:100%;font-size:12px}details{background:#fff;padding:8px}summary{cursor:pointer}.findings-table{table-layout:fixed}.findings-table th:nth-child(1){width:20%}.findings-table th:nth-child(2){width:14%}.findings-table th:nth-child(3){width:36%}.findings-table th:nth-child(4){width:30%}.findings-table td{overflow-wrap:anywhere}</style><h1>Migration matrix execution results</h1><p><b>Execution in progress.</b> DNS and legacy stateful suites excluded. Partial contract checks do not mean a complete matrix row has passed.</p><p><a href="../Flattened%20migration%20matrix.html">Open flattened matrix</a> · <a href="candidate-unit-results.json">698 supporting unit tests: PASS</a> · <a href="run-metadata.json">Pinned code and run details</a></p>'''+f'<p>{len(observations)} / 986 configurations have observations. {len(rows)} / 6,218 wallet rows have partial or full execution evidence. <b>No complete-row PASS is assigned until all required UI, record, permission and activity checks finish.</b></p>'+'''<h2>Environment and fixture corrections</h2><table><tr><th>ID</th><th>Observed</th><th>Correction / limitation</th></tr><tr><td>ENV-01</td><td>Old fork block 11898021 lacked required historical storage; Anvil crashed.</td><td>Fresh fork pinned at 11983209. Original manual environment preserved.</td></tr><tr><td>FIX-01</td><td>A resolver-discovery probe had migrated on Sepolia.</td><td>Only currently RESERVED probes count; at least two must agree.</td></tr><tr><td>FIX-02</td><td>Old fixtures approximated expiry and omitted the premigration bonus. The new preparation gate rejected them.</td><td>Read exact registrar/wrapper dates and reserve with the initial 62-day bonus. No production gate bypassed.</td></tr><tr><td>ENV-03</td><td>Upstream throttling interrupted the first chain epoch. No prior result is treated as proof of the rebuilt live state.</td><td>Fresh fixtures rerun on recovered chain epoch 2; full historical state is saved periodically; memory limits and snapshot intervals are recorded for each isolated environment. Historical RPC requests use bounded concurrency and retries. Indexer database rebuilt after the chain restart; activity remains unverified until catch-up.</td></tr><tr><td>FIX-03</td><td>UI prototype tried restoring a V1 record through a read adapter.</td><td>Write to the actual configured resolver. Preserve the invalid prototype evidence separately and rerun fresh. This is not a record-retention defect.</td></tr><tr><td>ENV-02</td><td>Fresh indexer startup lacked its SQL role file.</td><td>Restored existing test infrastructure file. Backfill begins at ENSv2 deployment block 11820280; all new fixture history is included. History tests wait for indexed head and registry history verification.</td></tr><tr><td>ENV-04</td><td>Transfer gas estimation timed out during an upstream RPC outage, although basic ownership reads still worked.</td><td>The nine active campaign chains switched to a replacement endpoint with the identical pinned fork hash. All nine heads stayed unchanged; no chain reset or service restart was used. Direct gas estimates returned afterward. Earlier app attempts remain BLOCKED; separate fresh workflow results appear below. Intermittent RPC timeouts remain under observation. <a href="rpc-upstream-recovery-active-chains.json">Recovery evidence</a> · <a href="transfer-estimate-after-upstream-M.json">Direct estimate check</a>. This is an environment recovery, not a product workaround.</td></tr></table><p>PASS: an executed assertion matched. FAIL: an executed assertion mismatched (root cause still requires triage). BLOCKED: environment or fixture prevented execution. NOT RUN: no execution evidence. PARTIAL: named checks ran but the broader case is incomplete.</p>'''+extra+'<h2>Configuration evidence</h2>'+''.join(case_summaries)+'</html>'
page=page.replace('<h2>Environment and fixture corrections</h2>',retention_report.panel(retention_integration,prefix='../')+priority.panel(priority_integration,prefix='../')+'<h2>Earlier campaign: environment and fixture corrections</h2>',1)
page=page.replace('<b>Execution in progress.</b> DNS and legacy stateful suites excluded.', '<b>Full matrix incomplete; latest 17-scenario follow-up merged.</b> DNS, stateful suites and all 4LDs excluded from current work. The older campaign totals below include archived 4LD evidence.')
page=page.replace('<h2>Execution coverage</h2>', '<h2>Earlier campaign coverage — includes archived 4LD evidence</h2>')
write_changed(OUT/'Campaign status.html',page)
subprocess.run(['python3',str(ROOT/'build-flat-matrix.py')],check=True,stdout=subprocess.DEVNULL)
print(json.dumps({'configurations':len(observations),'rows':len(rows),'statuses':summary}))
