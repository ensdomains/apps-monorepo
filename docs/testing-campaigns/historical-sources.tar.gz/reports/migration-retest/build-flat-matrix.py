from pathlib import Path
from itertools import product
from collections import Counter
import json
import os
import priority_matrix_integration as priority
import retention_matrix_integration as retention

OUT = Path(__file__).resolve().parent
def atomic_write(path, text):
    temp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temp.write_text(text)
    temp.replace(path)
NOT_RUN = 'NOT RUN'
shapes = []


def shape(code, level, kind, root, parent, wrapping, lock, emancipation, family):
    shapes.append(dict(shape=code, level=level, kind=kind, root_type=root,
                       parent_type=parent, wrapping=wrapping, lock=lock,
                       emancipation=emancipation, family=family))


shape('U2', '2LD', 'root', 'Unwrapped', '.eth registry', 'Unwrapped', 'N/A', 'N/A — registrar token', 'N-01')
shape('W2', '2LD', 'root', 'Unlocked', '.eth registry', 'Wrapped', 'Unlocked', 'Yes — .eth wrapper rule', 'N-02')
shape('L2', '2LD', 'root', 'Locked', '.eth registry', 'Wrapped', 'Locked', 'Yes', 'N-03')
for root, rcode in [('Unwrapped', 'U'), ('Unlocked', 'W')]:
    for wrapping, ccode in [('Unwrapped', 'U'), ('Wrapped', 'W')]:
        shape(f'{rcode}{ccode}3', '3LD', 'recreate', root, f'{root} .eth', wrapping,
              'N/A' if wrapping == 'Unwrapped' else 'Not locked — zero fuses',
              'N/A — registry-only' if wrapping == 'Unwrapped' else 'No — parent-controlled',
              {('U','U'):'N-07', ('U','W'):'N-08', ('W','U'):'N-09', ('W','W'):'N-10'}[(rcode, ccode)])
        for parent_wrap, pcode in [('Unwrapped', 'U'), ('Wrapped, zero fuses', 'W')]:
            shape(f'{rcode}{pcode}{ccode}4', '4LD', 'deep', root, f'{parent_wrap} 3LD', wrapping,
                  'N/A' if wrapping == 'Unwrapped' else 'Not locked — zero fuses',
                  'N/A — registry-only' if wrapping == 'Unwrapped' else 'No — parent-controlled', 'N-12')
for level in ['3LD', '4LD']:
    for lock in ['Locked', 'Detached']:
        shape(f'{lock[0]}{level[0]}', level, 'native', 'Locked', f'Locked {".eth" if level == "3LD" else "3LD"}',
              'Wrapped', lock, 'Yes', 'N-06' if level == '4LD' else ('N-04' if lock == 'Locked' else 'N-05'))
for wrapping, code in [('Unwrapped', 'U'), ('Wrapped', 'W')]:
    shape(f'X{code}3', '3LD', 'unsupported', 'Locked', 'Locked .eth', wrapping,
          'N/A' if wrapping == 'Unwrapped' else 'Not locked — zero fuses',
          'N/A — registry-only' if wrapping == 'Unwrapped' else 'No — parent-controlled', 'N-13')


def partitions(symbols):
    """Every equality partition, with stable wallet labels (Bell-number enumeration)."""
    def rec(values):
        if len(values) == len(symbols):
            yield dict(zip(symbols, [f'W{v+1}' for v in values]))
            return
        for v in range(max(values, default=-1) + 2):
            yield from rec(values + [v])
    yield from rec([])


def identities(s):
    syms = ['A']
    if s['root_type'] == 'Unwrapped':
        syms.append('B')
    if s['level'] == '4LD':
        syms.append('P')
    if s['level'] != '2LD':
        syms.append('C')
    for ids in partitions(syms):
        ids.setdefault('B', ids['A'])
        if s['level'] == '2LD':
            ids['C'] = ids['A']
        ids.setdefault('P', ids['B'])
        labels = []
        for w in sorted(set(ids[x] for x in syms)):
            labels.append('='.join(x for x in syms if ids[x] == w) + f' ({w})')
        yield ids, '; '.join(labels)


def roles_for(s, ids, actor):
    if actor in ['Operator', 'Resolver delegate', 'Unrelated', 'Disconnected']:
        return actor, 'None'
    roles = []
    parents = []
    if s['level'] == '2LD':
        if s['root_type'] == 'Unwrapped':
            if actor == ids['A'] and actor == ids['B']:
                roles = ['Owner+manager']
            elif actor == ids['A']:
                roles = ['Owner']
            elif actor == ids['B']:
                roles = ['Manager']
        elif actor == ids['A']:
            roles = ['Owner (wrapper holder)']
    else:
        if actor == ids['C']:
            roles.append('Manager (registry controller)' if s['wrapping'] == 'Unwrapped' else 'Owner (wrapper holder)')
        if actor == ids['A']:
            parents.append('2LD token owner')
        if s['root_type'] == 'Unwrapped' and actor == ids['B']:
            parents.append('2LD manager')
        if actor == ids['P']:
            parents.append('Immediate parent controller/holder')
    return ' + '.join(roles) or 'Parent only', ' + '.join(parents) or 'None'


def disposition(s, root_state, child_state, parent_migrated, flag):
    if s['kind'] == 'deep':
        return 'BLOCK — unsupported deep recreation', 'Do not migrate the affected .eth tree; keep its V1 namespace intact.'
    if s['kind'] == 'unsupported':
        return 'BLOCK — dependent child under locked parent', 'Explain the unsupported dependent namespace; no silent omission.'
    if s['kind'] != 'native' and root_state == 'Grace':
        return 'BLOCK — renew out of V1 grace', 'Root is not transferable; renew/sync first and use a fresh active-case check.'
    if s['kind'] == 'recreate' and flag == 'OFF':
        return 'BLOCK — recreation flag OFF', 'The affected parent remains V1; plain childless roots have separate rows.'
    if s['kind'] == 'native':
        if parent_migrated == 'No':
            return 'BLOCK — parent must migrate first', 'Child remains V1; verify resolver fallback and parent-first guidance.'
        if child_state == 'Expired':
            return 'BLOCK — expired child', 'Do not treat child expiry as a new 90-day grace period; verify actual transferability.'
        if root_state == 'Grace':
            return 'Native migration — independent despite V2 ancestor grace', 'User-confirmed MIGRATION-GRACE-01: allow this active emancipated child to migrate without renewing its V2 ancestor. Renewal before record editing remains a separate requirement.'
        return 'Native migration — app eligibility to verify', 'Migrate the child through the correct parent WrapperRegistry; never recreate it as a dependent child.'
    if s['kind'] == 'recreate':
        if child_state == 'Expired wrapper timestamp':
            return 'Recreate — canonical holder check required', 'Confirm reachable zero-fuse holder/fuse state; timestamp alone must not silently omit this child.'
        return 'Recreate direct child', 'Owner migrates the .eth tree atomically; direct child goes to its effective V1 holder.'
    return 'Migrate 2LD', 'Migrate this childless root through its type-specific controller.'


def before(s, ids, actor, root_state, child_state):
    own = actor == ids['A'] if s['level'] == '2LD' else actor == ids['C']
    manager = actor == (ids['B'] if s['level'] == '2LD' and s['root_type'] == 'Unwrapped' else ids['C'])
    parent = s['level'] != '2LD' and actor == ids['P']
    expired = child_state in ['Expired', 'Expired wrapper timestamp']
    active = root_state == 'Active' and not expired
    negative = actor in ['Unrelated', 'Disconnected']
    record = 'ALLOW — holder/controller authorization' if manager else 'DENY — no record authorization'
    if actor == 'Resolver delegate':
        record = 'ALLOW — explicit per-name resolver approval'
    if actor == 'Operator':
        record = 'VERIFY — operator authorization on source resolver'
    if not active and not negative:
        record = 'MEASURE — expiry/grace resolver authorization; do not infer from role label'
    if root_state == 'Grace' and not negative:
        record = 'BLOCK APP EDIT — renew first (user-confirmed); probe resolver authority separately'
    transfer = 'DENY — not token owner/operator'
    if s['wrapping'] == 'Unwrapped' and s['level'] != '2LD':
        transfer = 'ALLOW — change child controller; no separate token' if manager else 'DENY — not child controller'
    elif own or actor == 'Operator':
        transfer = 'ALLOW — token transfer (baseline approvals/fuses)'
    if not active and not negative:
        transfer = 'VERIFY child transferability and ancestor gate; no child grace assumed' if s['level'] != '2LD' else 'BLOCK — renew/sync before transfer'
    resolver = 'ALLOW — holder/controller' if manager else 'DENY — no registry authority'
    create = 'ALLOW — holder/controller, baseline fuses' if manager else 'DENY — no namespace authority'
    if actor == 'Operator':
        resolver = create = 'VERIFY — exact scope of V1 operator approval'
    if not active and not negative:
        resolver = create = 'MEASURE — effective rights at this expiry/grace checkpoint'
    reclaim = 'N/A — not a parent/reclaim actor'
    if s['level'] == '2LD' and s['root_type'] == 'Unwrapped' and actor == ids['A']:
        reclaim = 'ALLOW — reclaim registry manager' if active else 'BLOCK — token not transferable/reclaimable until active'
    elif parent:
        reclaim = 'DENY — child emancipated' if s['kind'] == 'native' else 'VERIFY — parent overwrite/control, separate from direct record editing'
    return dict(before_roles=('V1 token owner + registry controller' if s['level'] == '2LD' and actor == ids['A'] == ids['B'] and s['root_type'] == 'Unwrapped' else roles_for(s, ids, actor)[0]),
                before_records=record, before_transfer=transfer, before_set_resolver=resolver,
                before_create_subname=create, before_reclaim=reclaim,
                before_edit_roles='Test owner, controller, ETH-record edits separately; follow this actor’s actual contract authority',
                before_delete_subname='Probe holder deletion and parent overwrite separately; assert own/parent authority and no unrelated changes',
                before_primary='Can set reverse only for the wallet it controls; prove forward/reverse match',
                before_resolution='Require the seeded records resolve; capture raw and universal reads' if active else 'Capture raw and universal reads independently; record any expiry/grace refusal',
                before_activity='Seed edits, transfers, resolver changes, child creation and renewal; save hashes/actors/order',
                before_dates='Compare registrar, wrapper and ancestor dates; show grace only where the protocol defines it')


def after(s, ids, actor, keep, outcome):
    blocked = outcome.startswith('BLOCK')
    if blocked:
        return dict(after_holder='NO V2 NAME EXPECTED — source namespace unchanged',
                    after_registry_roles='NO NEW GRANTS EXPECTED', after_resolver_roles='NO NEW GRANTS EXPECTED',
                    after_s2_records='Verify all previously resolving V1 values still resolve; no migration-side deletion',
                    after_s4_records='NOT REACHED — no import or pointer switch expected',
                    after_s2_edit='Retest original V1 authority after the refused migration',
                    after_s4_edit='NOT REACHED', after_transfer='Retest V1; no new V2 token',
                    after_set_resolver='Retest V1; no new V2 registry', after_create_subname='Retest V1 with current expiry/permissions',
                    after_reclaim='Retest V1 with current expiry/permissions', after_edit_roles='Retest V1; no surplus grants from failed setup',
                    after_delete_subname='Retest original V1 rights; no silent subtree loss',
                    after_primary='Verify pre-existing forward/reverse outcome unchanged by the refusal',
                    after_activity='Retain V1 events; no successful migration event for refused/reverted work',
                    after_dates='No migration-induced expiry change; preserve exact source state',
                    retention_note='Expected safe block, not evidence of successful migration. All checks still NOT RUN.')
    subject = ids['A'] if s['level'] == '2LD' else ids['C']
    owner = actor == subject
    retained_manager = s['level'] == '2LD' and s['root_type'] == 'Unwrapped' and ids['A'] != ids['B'] and actor == ids['B'] and keep == 'Keep'
    parent_root = s['kind'] == 'recreate' and actor == ids['A']
    native_locked = s['lock'] == 'Locked'
    registry = 'No automatic V2 grant; verify exact bitmap and effective denials'
    if owner:
        registry = 'ALL child-token roles; no sibling/root grant implied' if s['kind'] == 'recreate' else ('Native fuse-derived token roles; canonical WrapperRegistry root roles' if native_locked else 'Standard registration token roles; verify exact bitmap')
    if retained_manager:
        registry = 'SET_RESOLVER, without its admin counterpart — cached expectation; confirm D6'
    if parent_root:
        registry += '; parent UserRegistry ROOT ALL (HCA also ROOT ALL)'
    resolver = 'No automatic new resolver grant; verify scope'
    if owner:
        resolver = 'Verify owner’s expected resolver rights; registry roles alone are insufficient'
    if retained_manager:
        resolver = 'Seven record setters only (0x1111111); no link/upgrade/admin; verify dedicated name scope'
    if s['kind'] == 'recreate':
        resolver = 'Old V1 resolver retained; measure effective authorization separately from new registry roles'
    editing = 'ALLOW — required owner record writes, subject to this resolver route' if owner else ('ALLOW — every retained setter; no admin escalation' if retained_manager else 'DENY on new resolver absent a separate grant; verify old approvals independently')
    s2edit = 'MEASURE — old resolver writes may be frozen after V1 ownership clears' if s['kind'] == 'recreate' else editing
    post_edit = editing
    if parent_root and not owner:
        post_edit = 'No automatic record-writing role; verify explicit copy/replace and resulting authorization'
    resolver_action = 'ALLOW — token SET_RESOLVER (baseline fuse allows it)' if owner or retained_manager else 'DENY absent registry grant'
    if parent_root and not owner:
        resolver_action = 'VERIFY inherited registry root authority separately from resolver writer access'
    create = 'ALLOW through permitted child-registry setup; verify UI + chain' if owner else 'DENY absent child-registry authority'
    if retained_manager:
        create = 'VERIFY — record setters / SET_RESOLVER do not establish subname-creation rights'
    if parent_root:
        create += '; root registrar authority verified separately'
    note = 'Compare original and resulting powers; a new role label is not preservation proof.'
    if retained_manager:
        note = 'Record-write retention is required; separately report V1 controller powers not restored by record-setter grants.'
    if s['kind'] == 'recreate':
        note = 'Child holder becomes V2 token owner; parent can still control the namespace. S2 reads and S4 writes need independent proof.'
    if outcome.startswith('VERIFY') or s['kind'] == 'native':
        note += ' Native route/app eligibility needs evidence; if blocked, report V1 continuity instead of pretending S2 was reached.'
    return dict(after_holder=f'{subject} — same effective V1 holder' if s['level'] != '2LD' else f'{subject} — owner-designated recipient (baseline: unchanged)',
                after_registry_roles=registry, after_resolver_roles=resolver,
                after_s2_records='Exact old resolver pointer + every previously resolving value' if s['kind'] == 'recreate' else 'Exact raw/decoded inventory and universal resolution; route-specific resolver copy',
                after_s4_records='All supported records preserved; populated pubkey / required-read failure must prevent unsafe switch',
                after_s2_edit=s2edit, after_s4_edit=post_edit,
                after_transfer='ALLOW — verify recipient and independent roles' if owner else ('VERIFY parent reclaim/unregister separately from direct token transfer' if parent_root else 'DENY absent a new transfer grant'),
                after_set_resolver=resolver_action, after_create_subname=create,
                after_reclaim=('ALLOW — parent root unregister/reclaim; verify child loss of namespace authority only' if parent_root else ('DENY — emancipated child cannot be clobbered by parent' if s['kind'] == 'native' and actor != subject else 'N/A — V1 sync-manager operation does not carry over as such')),
                after_edit_roles='Test own granted/admin roles only; reject surplus delegation and cross-name changes',
                after_delete_subname='Verify exact granted unregister/control rights; no assumption from owner/manager label',
                after_primary='Recheck forward/reverse pair and connected-wallet label; record stored reverse text separately',
                after_activity='Old V1 events remain reachable + correct migration/recreation and new V2 events; history UI contract D7 pending',
                after_dates='MAX child expiry, exact numeric value' if s['kind'] == 'recreate' else ('Exact reserved 2LD expiry; distinguish 62d and 62d+1s history' if s['level'] == '2LD' else 'Native-route expiry preserved/derived exactly; no generic 90-day child grace'),
                retention_note=note)


rows = []
configs = 0
partition_counts = {}
for s in shapes:
    all_ids = list(identities(s))
    partition_counts[s['shape']] = len(all_ids)
    parent_states = ['No', 'Yes'] if s['kind'] == 'native' else ['N/A — .eth registry' if s['level'] == '2LD' else ('N/A — root and direct children migrate together' if s['kind'] == 'recreate' else 'No')]
    child_states = ['N/A — use 2LD lifecycle'] if s['level'] == '2LD' else (['No independent registrar expiry'] if s['wrapping'] == 'Unwrapped' else (['Active', 'Expired'] if s['kind'] == 'native' else ['Active', 'Expired wrapper timestamp']))
    flags = ['ON', 'OFF'] if s['kind'] in ['recreate', 'deep', 'unsupported'] else ['N/A — no recreation']
    for (ids, relation), root_state, child_state, parent_migrated, flag in product(all_ids, ['Active', 'Grace'], child_states, parent_states, flags):
        keep_opts = ['Keep', 'Remove'] if s['root_type'] == 'Unwrapped' and ids['A'] != ids['B'] else ['N/A — no separate 2LD manager']
        for keep in keep_opts:
            configs += 1
            config_id = f'CFG-{configs:04}'
            outcome, migration = disposition(s, root_state, child_state, parent_migrated, flag)
            actors = sorted(set(ids.values())) + ['Operator', 'Resolver delegate', 'Unrelated', 'Disconnected']
            for ai, actor in enumerate(actors, 1):
                role, parent_role = roles_for(s, ids, actor)
                subject = ids['A'] if s['level'] == '2LD' else ids['C']
                initiator = subject if s['kind'] == 'native' else ids['A']
                who = 'Owner-authorized migration; this row observes the listed wallet before/after'
                if actor == initiator:
                    who = 'YES if eligibility passes — owning wallet'
                elif actor == 'Operator':
                    who = 'VERIFY approved-operator app route; no approval-based change of intended recipient'
                else:
                    who = 'NO independent initiation from this role; owning wallet performs migration for post-checks'
                data = dict(case_id=f'{config_id}-A{ai:02}', config_id=config_id, level=s['level'],
                            name_example={'2LD':'alice.eth','3LD':'child.alice.eth','4LD':'leaf.child.alice.eth'}[s['level']],
                            wrapping=s['wrapping'], lock=s['lock'], emancipated=s['emancipation'],
                            root_type=s['root_type'], parent_type=s['parent_type'], root_lifecycle=root_state,
                            root_lifecycle_version='V2' if s['kind'] == 'native' and parent_migrated == 'Yes' else 'V1',
                            name_expiry=child_state, parent_migrated=parent_migrated,
                            relationships=relation, root_owner=ids['A'], root_manager=ids['B'], parent_controller=ids['P'],
                            name_holder=subject if s['level'] == '2LD' or s['wrapping'] == 'Wrapped' else 'No separate token owner',
                            name_manager=ids['B'] if s['level'] == '2LD' and s['root_type'] == 'Unwrapped' else (ids['C'] if s['wrapping'] == 'Unwrapped' else 'No separate V1 manager role'),
                            actor=actor, actor_role=role, actor_parent_role=parent_role, retain_manager=keep,
                            recreation_flag=flag, baseline_fuses=('PARENT_CANNOT_CONTROL + CANNOT_UNWRAP; no extra restrictions' if s['lock'] == 'Locked' else ('PARENT_CANNOT_CONTROL; CANNOT_UNWRAP clear' if s['lock'] == 'Detached' else ('2LD wrapper mandatory flags; CANNOT_UNWRAP clear' if s['shape'] == 'W2' else ('Zero fuses' if s['wrapping'] == 'Wrapped' else 'N/A')))),
                            baseline_resolver='Known V1 PublicResolver, supported complete record bundle; per-name delegate D explicitly approved',
                            baseline_approvals='Operator has source token approval (where a token exists); no other surplus grants',
                            migration_initiator=initiator, actor_can_initiate=who, expected_migration=outcome, expected_flow=migration,
                            scope='Manager + Explorer; separate results for each',
                            requirement_refs=f"{s['family']}; R-01–R-15; P-01–P-08; H-01–H-07; T-01–T-08; F-01–F-06",
                            oracle_status='PLANNED EXPECTATIONS — verify final PR/deployment; D6/D7 and native gates remain explicit',
                            **before(s, ids, actor, root_state, child_state),
                            **after(s, ids, actor, keep, outcome))
                if root_state == 'Grace':
                    data['after_s2_edit'] = 'BLOCK APP EDIT while still in grace — renew first; test restored authority after renewal'
                    if not outcome.startswith('BLOCK'):
                        data['after_s4_edit'] = 'BLOCK APP EDIT while still in grace — renew first; test supported import/edit after renewal'
                for key in ['before_manager_result','after_manager_result','before_explorer_result','after_explorer_result',
                            'records_result','roles_result','permissions_result','activity_result','combined_record_edit_result','overall_result']:
                    data[key] = NOT_RUN
                data.update(actual_outcome='', workaround='', evidence='')
                rows.append(data)

assert len({r['case_id'] for r in rows}) == len(rows)
assert set(r['level'] for r in rows) == {'2LD', '3LD', '4LD'}
assert all(r['overall_result'] == NOT_RUN for r in rows)
assert len(list(partitions(['A','B','C']))) == 5
assert len(list(partitions(['A','B','P','C']))) == 15

meta = dict(title='Flattened migration ownership and lifecycle matrix', status='PLAN — NOT EXECUTED',
            created='2026-10-24', row_count=len(rows), configuration_count=configs, shape_count=len(shapes),
            row_definition='One name configuration × distinct connected wallet. Pre/post actions are columns, not separate passing test results.',
            exclusions=['DNS', 'legacy stateful suites'],
            source='Migration retention retest plan.html and its attached source snapshots',
            fixed_baseline='Known V1 PublicResolver; complete supported record bundle; minimal legal fuse profile; no extra grants except explicitly named operator/delegate.',
            remaining_expansions='Custom/offchain/zero resolvers, each record payload, full legal fuse lattice, exact boundary seconds, sibling fanout, races, flag transitions, wallet transport and deployment variants remain separate families in the detailed plan.',
            identity_legend={'A':'2LD token owner / wrapper holder', 'B':'2LD registry manager (equals A as effective holder for wrapped roots)', 'P':'Immediate parent controller/holder for 4LD; B for 3LD', 'C':'Subname registry controller or effective wrapper holder'},
            partition_counts=partition_counts)
result_path = OUT/'execution'/'matrix-results.json'
execution = json.loads(result_path.read_text()) if result_path.exists() else {'rows': {}, 'metadata': {}}
integration = priority.load()
priority.merge(execution, integration)
retention_integration = retention.load()
retention.merge(execution, retention_integration)
result_fields = {k for k in rows[0] if k.endswith('_result')} | {'actual_outcome', 'workaround', 'evidence'} | set(priority.FIELDS) | set(retention.FIELDS)
for row in rows:
    update = execution.get('rows', {}).get(row['case_id'], {})
    if set(update) - result_fields:
        raise ValueError(f"Unexpected result fields: {set(update) - result_fields}")
    row.update(update)
meta.update(execution.get('metadata', {}))
meta['result_counts'] = dict(Counter(r['overall_result'] for r in rows))
meta['rows_with_observations'] = sum(any(r[k] != NOT_RUN for k in result_fields if k.endswith('_result')) for r in rows)
meta['active_configuration_count'] = len({r['config_id'] for r in rows if r['level'] != '4LD'})
meta['active_row_count'] = sum(r['level'] != '4LD' for r in rows)
meta['historical_result_counts'] = dict(Counter(r.get('historical_result', r['overall_result']) for r in rows))
atomic_write(OUT/'flattened-matrix.json', json.dumps(dict(metadata=meta, rows=rows), ensure_ascii=False, indent=2))

labels = {
    'case_id':'Case', 'config_id':'Configuration', 'level':'Level', 'name_example':'Example',
    'wrapping':'Wrapped / unwrapped', 'lock':'Lock state', 'emancipated':'Emancipated?',
    'root_type':'.eth type', 'parent_type':'Immediate parent type', 'root_lifecycle':'.eth lifecycle',
    'root_lifecycle_version':'Lifecycle applies to', 'name_expiry':'Subname expiry', 'parent_migrated':'Parent migrated?',
    'relationships':'Wallet relationships', 'root_owner':'.eth token owner', 'root_manager':'.eth effective manager',
    'parent_controller':'Immediate parent controller', 'name_holder':'Name token holder', 'name_manager':'Separate name manager',
    'actor':'Connected wallet', 'actor_role':'Role on this name', 'actor_parent_role':'Role on ancestors',
    'retain_manager':'Keep separate 2LD manager?', 'recreation_flag':'Recreation flag',
    'baseline_fuses':'Baseline fuses', 'baseline_resolver':'Baseline resolver / records', 'baseline_approvals':'Baseline approvals',
    'migration_initiator':'Migration submitted by', 'actor_can_initiate':'Can connected wallet initiate?',
    'expected_migration':'Expected migration outcome', 'expected_flow':'Expected route / refusal',
    'scope':'Apps', 'requirement_refs':'Plan references', 'oracle_status':'Expectation confidence',
    'before_roles':'Before: roles', 'after_holder':'After: holder', 'after_registry_roles':'After: registry roles', 'after_resolver_roles':'After: resolver roles',
    'before_records':'Before: record edits', 'after_s2_edit':'S2: record edits', 'after_s4_edit':'S4: record edits',
    'before_resolution':'Before: record resolution', 'after_s2_records':'S2: record retention', 'after_s4_records':'S4: record retention',
    'before_transfer':'Before: send / transfer', 'after_transfer':'After: send / transfer',
    'before_set_resolver':'Before: set resolver', 'after_set_resolver':'After: set resolver',
    'before_create_subname':'Before: create subname', 'after_create_subname':'After: create subname',
    'before_reclaim':'Before: sync / parent control', 'after_reclaim':'After: sync / parent control',
    'before_edit_roles':'Before: edit roles', 'after_edit_roles':'After: edit roles',
    'before_delete_subname':'Before: delete subname', 'after_delete_subname':'After: delete subname',
    'before_primary':'Before: primary name', 'after_primary':'After: primary name',
    'before_activity':'Before: activity history', 'after_activity':'After: activity history',
    'before_dates':'Before: dates / renewal', 'after_dates':'After: dates / renewal',
    'retention_note':'Retention check / limitation', 'before_manager_result':'Before Manager result', 'after_manager_result':'After Manager result',
    'before_explorer_result':'Before Explorer result', 'after_explorer_result':'After Explorer result',
    'records_result':'Record result', 'roles_result':'Role result', 'permissions_result':'Permission result', 'activity_result':'Activity result', 'combined_record_edit_result':'Record edits across both apps',
    'overall_result':'Combined status (see commit)', 'actual_outcome':'Earlier campaign: actual outcome', 'workaround':'Earlier campaign: workaround', 'evidence':'Earlier campaign: evidence',
    'historical_result':'Earlier campaign result (6d24b08)', 'followup_result':'Latest follow-up result',
    'followup_commit':'Follow-up commit', 'followup_scenarios':'Executed follow-up scenarios',
    'followup_checks':'Actual follow-up checks for this wallet', 'followup_gaps':'New findings',
    'followup_evidence':'Follow-up evidence', 'coverage_scope':'Evidence scope / remaining coverage',
    'continuation_result':'Current retention check result', 'continuation_before_result':'Current: before app checks',
    'continuation_after_result':'Current: after app checks', 'continuation_records_result':'Current: record retention',
    'continuation_permissions_result':'Current: permission retention', 'continuation_activity_result':'Current: indexed activity',
    'continuation_checks':'Current: executed assertions', 'continuation_findings':'Current: finding disposition',
    'continuation_workaround':'Current: verified workaround', 'continuation_evidence':'Current: evidence', 'continuation_commit':'Current: tested commit', 'continuation_scope':'Current: actual migration outcome / scope'
}
for key in ['before_manager_result','after_manager_result','before_explorer_result','after_explorer_result','records_result','roles_result','permissions_result','activity_result','combined_record_edit_result']:
    labels[key] += ' (earlier campaign)'
assert set(labels) == set(rows[0])
common=['case_id','overall_result','followup_result','level','wrapping','lock','emancipated','root_lifecycle_version','root_lifecycle','name_expiry','parent_type','parent_migrated','relationships','actor_role','actor_parent_role','retain_manager','recreation_flag']
focus=['case_id','overall_result','followup_result','followup_checks','followup_gaps','followup_commit','level','root_lifecycle','actor_role','relationships']
views={
 'Current retention checks':['case_id','level','actor','actor_role','continuation_scope','continuation_result','continuation_before_result','continuation_after_result','continuation_records_result','continuation_permissions_result','continuation_activity_result','continuation_findings','continuation_workaround','continuation_commit','continuation_evidence'],
 'Latest 2LD/3LD checks':['case_id','followup_result','level','actor','actor_role','followup_scenarios','followup_checks','followup_gaps','followup_commit','historical_result','coverage_scope','followup_evidence'],
 'Overview':common+['expected_migration','after_holder','after_registry_roles','after_resolver_roles','after_s2_records','after_s4_records','retention_note'],
 'Roles & permissions':focus+['before_roles','after_holder','after_registry_roles','after_resolver_roles','before_transfer','after_transfer','before_set_resolver','after_set_resolver','before_edit_roles','after_edit_roles','before_reclaim','after_reclaim','migration_initiator','actor_can_initiate','roles_result','permissions_result'],
 'Records':focus+['before_resolution','after_s2_records','after_s4_records','before_records','after_s2_edit','after_s4_edit','before_primary','after_primary','expected_migration','records_result'],
 'Actions & activity':focus+['before_create_subname','after_create_subname','before_delete_subname','after_delete_subname','before_dates','after_dates','before_activity','after_activity','expected_migration','activity_result'],
 'Execution results':focus+['expected_migration','before_manager_result','after_manager_result','before_explorer_result','after_explorer_result','combined_record_edit_result','records_result','roles_result','permissions_result','activity_result','actual_outcome','workaround','evidence'],
 'All columns':list(labels)
}

# Store repeated text once in the HTML; JSON export remains a conventional flat row array.
strings=[]; lookup={}
def intern(x):
    if x not in lookup:
        lookup[x]=len(strings);strings.append(x)
    return lookup[x]
keys=list(labels)
packed=[[intern(r[k]) for k in keys] for r in rows]
payload=json.dumps(dict(metadata=meta, keys=keys, labels=labels, views=views, strings=strings, rows=packed), ensure_ascii=False, separators=(',',':')).replace('</','<\\/')

page='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Flattened migration matrix</title><style>
:root{--ink:#17382d;--green:#08674e;--line:#cbd9d1;--muted:#52685f}*{box-sizing:border-box}body{margin:0;background:#f5f8f5;color:var(--ink);font:14px/1.5 system-ui,sans-serif}header{padding:28px 32px 22px;background:#e6f1e9;border-bottom:1px solid var(--line)}h1{font-size:30px;margin:8px 0}p{max-width:1150px;margin:9px 0}a{color:var(--green)}.badge{display:inline-block;padding:4px 10px;background:#fff3cb;border-radius:20px;font-size:12px;font-weight:750}.stats{display:flex;gap:32px;flex-wrap:wrap;margin:18px 0 8px}.stats b{display:block;font-size:24px}.stats span{font-size:12px;color:var(--muted)}.links{display:flex;gap:18px;flex-wrap:wrap}main{padding:20px 28px}details{background:white;border:1px solid var(--line);border-radius:8px;padding:12px 16px;margin:0 0 15px}summary{cursor:pointer;font-weight:650}.legend{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:14px}.legend div{padding:10px;background:#f4f8f4}.filters{display:flex;gap:10px;flex-wrap:wrap;align-items:end;padding:15px;background:white;border:1px solid var(--line);border-radius:8px}label{display:flex;flex-direction:column;font-size:12px;gap:4px;color:var(--muted)}select,input,button{font:inherit;color:var(--ink);border:1px solid #b8ccc0;border-radius:5px;background:white;padding:8px}input{min-width:240px}button{cursor:pointer}button:disabled{opacity:.4;cursor:default}.toolbar{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin:14px 0}.toolbar .controls{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.table-wrap{overflow:auto;max-height:66vh;border:1px solid var(--line);background:white;border-radius:7px;overscroll-behavior:contain}table{border-collapse:separate;border-spacing:0;font-size:12px}th,td{white-space:pre-line;text-align:left;vertical-align:top;padding:10px 12px;min-width:155px;max-width:280px;border-right:1px solid var(--line);border-bottom:1px solid var(--line);overflow-wrap:anywhere}th{position:sticky;top:0;background:#e4eee7;z-index:2;height:60px;min-width:155px}td:first-child,th:first-child{position:sticky;left:0;min-width:136px;z-index:1;background:#f0f6f0;font-weight:700}th:first-child{z-index:3}td:nth-child(2),th:nth-child(2){min-width:190px;max-width:240px;overflow-wrap:normal}.fail{color:#a42828;font-weight:650}.pass{color:#08674e;font-weight:650}.partial{color:#665214}tr:nth-child(even) td{background:#f9fbf9}tr:nth-child(even) td:first-child{background:#eaf2eb}.notrun{color:#896316;font-weight:700}.blocked{color:#9b4f23}.empty{padding:40px}.count{font-weight:700}.foot{color:var(--muted);font-size:12px}.smalltable{border-collapse:collapse;width:100%;margin-top:12px}.smalltable th{position:static;height:auto}.smalltable td,.smalltable th{min-width:0;max-width:none;border:1px solid var(--line)}@media(max-width:800px){header{padding:20px}main{padding:15px}.legend{grid-template-columns:1fr}.table-wrap{max-height:70vh}.stats{gap:20px}input{min-width:170px}}@media print{header{padding:10px}main{padding:0}.filters,.toolbar,.links,details{display:none}.table-wrap{max-height:none;overflow:visible}th,td{position:static!important;font-size:8px;min-width:0!important;padding:4px}tr{break-inside:avoid}@page{size:A3 landscape;margin:10mm}}
</style></head><body><header><span class="badge" id="executionStatus">PLAN — NOT EXECUTED · DNS & legacy stateful excluded</span><h1>Flattened migration matrix</h1><p>One row per name configuration and connected wallet. The same row follows records, roles, permissions and activity from V1 through migration and resolver replacement.</p><div class="stats"><div><b id="totalRows"></b><span>configuration × wallet rows</span></div><div><b id="totalConfigs"></b><span>name / policy configurations</span></div><div><b id="totalShapes"></b><span>retention workflows executed (not whole rows)</span></div><div><b id="observedRows">0</b><span>wallet rows with new mapped checks</span></div></div><div class="links"><a href="Migration%20retention%20retest%20plan.html">Detailed execution plan</a><a href="flattened-matrix.json">Full flat JSON</a><a href="execution/Campaign%20status.html">Run details, gaps and evidence</a><button id="download">Download filtered rows (JSON)</button></div></header><main>
<details><summary>How to read this matrix — definitions, assumptions and scope</summary><p><b>Expected behavior and actual results are separate.</b> ALLOW / DENY / BLOCK describe planned assertions, not observations. MEASURE / VERIFY identifies an unresolved or conditional rule. PASS means the named check completed and matched its assertion. FAIL means an observed mismatch. BLOCKED means a required environment or preceding step prevented the check. NOT RUN means no execution evidence yet. Partial checks do not make the whole row PASS. Unsupported migration stays in the matrix as a negative test.</p><p>This expands the requested name, lifecycle, wallet relationship and migration-policy axes. It is <b>not the final executable-test count</b>. Each row uses a known V1 PublicResolver, a complete supported record bundle and the minimum legal fuse profile. The detailed plan separately covers custom/zero/offchain resolvers, individual record payloads, other fuse combinations, exact boundary seconds, sibling fanout, races and wallet modes.</p><div class="legend"><div><b>2LD / 3LD / 4LD</b><br>alice.eth / child.alice.eth / leaf.child.alice.eth. Wrapped, locked and emancipated are separate columns because they overlap.</div><div><b>Owner and manager</b><br>Unwrapped .eth can have separate token owner and registry manager. A registry-only subname has a controller plus parent control. Wrapped names have a holder; a resolver delegate is not a second V1 manager.</div><div><b>Grace belongs to the .eth ancestor</b><br>Editing requires renewal first (confirmed by the user). Contract authority and app policy are tested separately. Use “Lifecycle applies to” to distinguish V1 from V2. Subname expiry is a separate column; no 90-day child grace is invented.</div><div><b>Wallet relationships</b><br>A = 2LD owner; B = 2LD manager; P = immediate parent of a 4LD; C = subname controller/holder. Equal symbols mean the same wallet. W1/W2/etc. are fixture identities, not real addresses.</div><div><b>Before → S2 → S4</b><br>Before = V1 baseline. S2 = migration mined, before optional resolver import. S4 = copy/replace completed. For a safe block, there is no migrated S2/S4 name: check V1 continuity instead.</div><div><b>Connected wallet vs migrator</b><br>The owning wallet performs migration to prepare post-migration checks. A manager-only row does not assume the manager can initiate migration. Operator/delegate rows have explicit limited fixture approvals.</div></div><p class="foot">Baseline independent parent expiry is active for 4LD fixtures. Additional parent-expiry/fuse variants remain in T-04 / P-07. Canonical holder checks must validate every expired zero-fuse fixture; an impossible fixture is BLOCKED — FIXTURE, never an application pass.</p></details>
<div class="filters"><label>Scope<select id="scopeFilter"><option value="active">Current: 2LD + 3LD</option><option value="archive">Archived: 4LD only</option><option value="all">All, including archived 4LD</option></select></label><label>Follow-up result<select id="followup"></select></label><label>Search all columns<input id="search" placeholder="e.g. owner+manager, pubkey, CFG-0001"></label><label>Result<select id="result"></select></label><label>Level<select id="level"></select></label><label>Lifecycle<select id="life"></select></label><label>Wrapped / unwrapped<select id="wrap"></select></label><label>Lock state<select id="lock"></select></label><label>Emancipated<select id="emancipated"></select></label><label>Connected role<select id="role"></select></label><label>Migration outcome<select id="outcome"></select></label><label>Keep manager<select id="keep"></select></label><label>Flag<select id="flag"></select></label><button id="reset">Reset filters</button></div>
<div class="toolbar"><span id="count" class="count"></span><div class="controls"><label>Columns<select id="view"></select></label><label>Rows per page<select id="size"><option>25</option><option>50</option><option>100</option></select></label><button id="prev">Previous</button><span id="pageNo"></span><button id="next">Next</button></div></div><p class="foot">Scroll the table horizontally for the paired before/after columns. Focused column views display the same rows with fewer identity columns; “All columns” includes every field and result. Filters also apply to the JSON download.</p><div class="table-wrap" tabindex="0" aria-label="Migration matrix, scroll horizontally for additional columns"><table id="matrix"><thead></thead><tbody></tbody></table></div>
<details style="margin-top:18px"><summary>Combinations that do not apply</summary><table class="smalltable"><tr><th>Combination</th><th>Reason / treatment</th></tr><tr><td>Unwrapped + locked</td><td>Lock is a NameWrapper fuse property; N/A for registry-only / registrar-token cases.</td></tr><tr><td>Locked + not emancipated</td><td>CANNOT_UNWRAP requires PARENT_CANNOT_CONTROL. No valid locked, parent-controlled fixture.</td></tr><tr><td>Wrapped .eth + not emancipated</td><td>The .eth wrapper sets parent-cannot-control. Unlocked wrapped .eth therefore still shows emancipation.</td></tr><tr><td>Independent owner and manager for a wrapped token</td><td>Use holder, operator and resolver-delegate rows. Do not invent a second registrar/controller pair.</td></tr><tr><td>Subname with its own 90-day registrar grace</td><td>Grace is attached to its .eth ancestor; record the child’s own expiry independently.</td></tr><tr><td>Registry-only subname with a separate child registrar-token owner</td><td>Use the child controller and actual parent authority. After supported recreation the child receives a V2 token.</td></tr><tr><td>All 4LDs excluded from current testing</td><td>User-requested scope exclusion, not a claim that every protocol route is unsupported. Earlier 4LD evidence remains in the archive filter.</td></tr></table></details><p class="foot">Sources: <a href="sources/thread.txt">migration thread</a> · <a href="sources/migration-case-study.txt">migration case study</a> · <a href="sources/continuity-case-study.txt">continuity case study</a>. Source snapshot and unresolved D1–D10 decisions are retained in the detailed plan. Earlier evidence retains its own commit; newer checks are credited only to the exact mapped scenarios and wallets.</p>
</main><script id="data" type="application/json">PAYLOAD</script><script>
const data=JSON.parse(document.getElementById('data').textContent);
const rows=data.rows.map(values=>Object.fromEntries(data.keys.map((key,i)=>[key,data.strings[values[i]]])));
const filters={followup:'followup_result',result:'overall_result',level:'level',life:'root_lifecycle',wrap:'wrapping',lock:'lock',emancipated:'emancipated',role:'actor_role',outcome:'expected_migration',keep:'retain_manager',flag:'recreation_flag'};
const $=id=>document.getElementById(id);let page=0,filtered=rows;
$('executionStatus').textContent=data.metadata.status+' · DNS, stateful & 4LD excluded';$('observedRows').textContent=data.metadata.retention_continuation_wallets||0;$('totalRows').textContent=data.metadata.active_row_count.toLocaleString();$('totalConfigs').textContent=data.metadata.active_configuration_count.toLocaleString();$('totalShapes').textContent=data.metadata.retention_continuation_jobs?.EXECUTED||0;
function option(select,value,label){const o=document.createElement('option');o.value=value;o.textContent=label;select.append(o)}
for(const [id,key] of Object.entries(filters)){option($(id),'','All');for(const value of [...new Set(rows.map(r=>r[key]))].sort())option($(id),value,value);$(id).addEventListener('change',()=>{page=0;render()})}
for(const value of Object.keys(data.views))option($('view'),value,value);
function render(){const q=$('search').value.trim().toLowerCase();filtered=rows.filter(r=>($('scopeFilter').value==='all'||($('scopeFilter').value==='active'?r.level!=='4LD':r.level==='4LD'))&&Object.entries(filters).every(([id,key])=>!$(id).value||r[key]===$(id).value)&&(!q||Object.values(r).some(v=>v.toLowerCase().includes(q))));const size=+$('size').value;const pages=Math.max(1,Math.ceil(filtered.length/size));page=Math.min(page,pages-1);const keys=data.views[$('view').value];const head=document.createElement('tr');for(const key of keys){const th=document.createElement('th');th.textContent=data.labels[key];th.scope='col';head.append(th)}$('matrix').tHead.replaceChildren(head);const frag=document.createDocumentFragment();for(const r of filtered.slice(page*size,(page+1)*size)){const tr=document.createElement('tr');for(const key of keys){const td=document.createElement('td');td.textContent=r[key]||'—';if(key==='case_id'&&r.overall_result!=='NOT RUN'){const a=document.createElement('a');a.href=r.continuation_evidence?'retention-continuation-20261026/Retention%20continuation%20results.html#'+r.case_id:'execution/cases/'+r.config_id+'.html'+(r.followup_scenarios?'#priority-latest':'');a.textContent=r[key];td.replaceChildren(a)}if((key==='evidence'||key==='followup_evidence'||key==='continuation_evidence')&&r[key]){td.replaceChildren();r[key].split(';').forEach((ref,i)=>{const a=document.createElement('a');a.href=encodeURI(ref.trim());a.textContent='Evidence '+(i+1);td.append(a,document.createElement('br'))})}if(r[key].startsWith('FAIL'))td.className='fail';if(r[key].startsWith('PASS'))td.className='pass';if(r[key].startsWith('PARTIAL'))td.className='partial';if(r[key]==='NOT RUN')td.className='notrun';if(r[key].startsWith('BLOCK'))td.className='blocked';tr.append(td)}frag.append(tr)}if(!filtered.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=keys.length;td.textContent='No matching configurations. Adjust the filters; the table below explains impossible combinations.';td.className='empty';tr.append(td);frag.append(tr)}$('matrix').tBodies[0].replaceChildren(frag);$('count').textContent=filtered.length.toLocaleString()+' of '+rows.length.toLocaleString()+' rows · '+new Set(filtered.map(r=>r.config_id)).size.toLocaleString()+' configurations';$('pageNo').textContent=(page+1)+' / '+pages;$('prev').disabled=page===0;$('next').disabled=page===pages-1;}
$('scopeFilter').addEventListener('change',()=>{page=0;render()});let searchTimer;$('search').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{page=0;render()},150)});$('view').addEventListener('change',render);$('size').addEventListener('change',()=>{page=0;render()});$('prev').onclick=()=>{page--;render()};$('next').onclick=()=>{page++;render()};$('reset').onclick=()=>{for(const id of Object.keys(filters))$(id).value='';$('search').value='';$('scopeFilter').value='active';page=0;render()};$('download').onclick=()=>{const blob=new Blob([JSON.stringify({metadata:{...data.metadata,filtered_row_count:filtered.length},rows:filtered},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='filtered-migration-matrix.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};render();
</script></body></html>'''.replace('PAYLOAD',payload)
page = page.replace('<main>', '<main>' + retention.panel(retention_integration) + priority.panel(integration), 1)
atomic_write(OUT/'Flattened migration matrix.html', page)

plan_path=OUT/'Migration retention retest plan.html'
plan=plan_path.read_text()
link='<a id="flat-matrix-link" href="Flattened%20migration%20matrix.html">Flattened ownership &amp; lifecycle matrix</a>'
if 'id="flat-matrix-link"' not in plan:
    plan=plan.replace('<div class="tools">','<div class="tools">'+link,1)
    plan_path.write_text(plan)
manifest_path=OUT/'execution-plan.json'
manifest=json.loads(manifest_path.read_text())
manifest['flattenedMatrix']={**{k:meta[k] for k in ['row_count','configuration_count','shape_count','row_definition','fixed_baseline','remaining_expansions']},'html':'Flattened migration matrix.html','json':'flattened-matrix.json','status':meta['status']}
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps({'rows':len(rows),'configurations':configs,'shapes':len(shapes),'html_bytes':len(page.encode()),'by_level':Counter(r['level'] for r in rows)}))
