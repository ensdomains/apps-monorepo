import json,os,pathlib,subprocess,time
p=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
while json.loads((p/'active-batch.json').read_text()).get('status') != 'all initial attempts completed': time.sleep(3)
batches=[('permissions-corrected','/priority-permissions.spec.ts$', ['--grep','parent-reclaim'], {'MATRIX_RECORD_PROFILE':'extended'}),('import-recovery-corrected','/resolver-import.spec.ts$',[],{'MATRIX_IDS':'CFG-0015','MATRIX_S4_VARIANT':'reject-first,reject-after-setup','MATRIX_RECORD_PROFILE':'baseline-7'})]
for name,spec,args,extra in batches:
 out=p/'runs'/name
 if out.exists():raise RuntimeError(f'Refusing to overwrite {out}')
 (p/'corrected-batch.json').write_text(json.dumps({'batch':name,'status':'running'}))
 env={**os.environ,'MATRIX_READY':'e2e/.migration-matrix-runs/migration-matrix-1792925893024-21515/ready.json','MATRIX_OUTPUT':str(out),'MATRIX_CACHE_APP_MODULES':'1',**extra}
 result=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs',spec,*args],cwd=repo,env=env)
 print(name,'exit',result.returncode,flush=True)
(p/'corrected-batch.json').write_text(json.dumps({'status':'all corrected attempts completed'}))
