import collections, datetime, html, json
from pathlib import Path
P=Path(__file__).resolve().parent
m=json.loads((P/'manifest.json').read_text())
triage=json.loads((P/'triage.json').read_text()) if (P/'triage.json').exists() else {}
rows=[]
for r in m['rows']:
 s=P/r['source']; d=json.loads(s.read_text()) if s.exists() else {}
 errors=d.get('assertionErrors',[])
 result='NOT RUN' if not d else 'RUNNING' if not d.get('completedAt') else 'FAIL' if d.get('error') or errors else 'PASS'
 t=triage.get(r['id'],{})
 if t.get('result'): result=t['result']
 rows.append({**r,'result':result,'phase':d.get('phase',''),'errors':errors,'error':d.get('error'),'summary':t.get('summary',''),'finding':t.get('finding',''),'workaround':t.get('workaround',''),'checks':{**d.get('checks',{}), **({'Cancel and reopen':d['cancelReview']} if 'cancelReview' in d else {}), **({'Rejected wallet request':d['rejectedImport']} if 'rejectedImport' in d else {})},'subject':d.get('subject',''),'completedAt':d.get('completedAt'),'after':d.get('after',[])})
counts=dict(collections.Counter(r['result'] for r in rows))
data={'updatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':m['candidate'],'excluded':m['excluded'],'scope':m['scope'],'counts':counts,'rows':rows}
(P/'results.json').write_text(json.dumps(data,indent=2))
e=html.escape
style="body{font:16px/1.5 system-ui,sans-serif;margin:38px auto;max-width:1280px;padding:0 24px;color:#173047;background:#f7f9fc}h1{font-size:32px}table{width:100%;border-collapse:collapse;background:white;margin:22px 0}th,td{text-align:left;border:1px solid #d5dee8;padding:12px;vertical-align:top}th{background:#e7eef6}a{color:#006caa}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px}section{background:white;padding:22px;margin:20px 0;border:1px solid #d5dee8}.PASS{color:#087942}.FAIL{color:#b42318}.BLOCKED{color:#965900}small{color:#52667a}"
page=f'<!doctype html><html lang="en"><meta charset="utf-8"><title>2LD and 3LD priority results</title><style>{style}</style><h1>2LD and 3LD priority results</h1><p><b>17 focused follow-up scenarios.</b> DNS, all fourth-level names, and legacy dependent stateful suites are excluded.</p><p>Candidate: <code>{e(m["candidate"][:12])}</code>. Updated {e(data["updatedAt"])}.</p><p>'+e(' · '.join(f'{k}: {v}' for k,v in counts.items()))+'</p><p>'+e(m['scope'])+'</p><p>PASS means the executed scenario assertions matched. FAIL retains failed assertions; root-cause and acceptance triage are separate. BLOCKED means execution did not establish the intended product outcome. Tests use real local-fork contracts and fresh names with seeded discovery. Activity captured as chain logs is not a new indexed-history pass.</p><table><tr><th>Case</th><th>Area</th><th>Result</th><th>Finding / workaround / evidence</th></tr>'
for r in rows:
 page+=f'<tr><td><a href="#{e(r["id"])}">{e(r["title"])}</a></td><td>{e(r["group"])}</td><td class="{e(r["result"])}"><b>{e(r["result"])}</b></td><td>{e(r["summary"] or r["phase"])}<br>{e(r["finding"])}<br>{e(r["workaround"])}'
 if (P/r['source']).exists():page+=f'<br><a href="{e(r["source"])}">Original execution evidence</a>'
 page+='</td></tr>'
page+='</table><section><h2>Source-change acceptance rule</h2><p>Records, child ownership or the child inventory changing after final review must stop migration and require a fresh review. A successful transaction using an older snapshot is a failure. The four source-change checks measure changes before wallet submission; they do not cover every pending-transaction race.</p><a href="acceptance-decisions.json">User-confirmed rule MIGRATION-SOURCE-01</a></section><section><h2>Previously accepted findings</h2><p>Accepted findings remain separate from new failures. Their original failed assertions are not changed to passes. These focused resolver recovery tests compare the seven-record supported bundle; the control and race fixtures use the extended record inventory.</p><a href="../pr-approval-36/PR%20approval%20results.html">Previous 36-scenario report and accepted findings</a></section><section><h2>Still outside this focused run</h2><p>The remaining full 2LD/3LD matrix, broader grace/fuse boundaries, all resolver implementations and payload combinations, oversized trees, all wallet/action combinations and complete indexed activity remain separate. The original saved 84-configuration UI backlog and 851 action jobs must be credited check by check; these 17 scenarios are not 17 completed matrix configurations.</p></section>'
if (P/'new-findings.json').exists():
 page+='<section><h2>New findings and failed cases</h2><p>These findings are separate from the previously accepted MRT findings.</p><table><tr><th>Finding</th><th>Failed cases</th><th>Observed impact</th></tr>'
 for finding in json.loads((P/'new-findings.json').read_text())['findings']:
  page+='<tr><td>'+e(finding['id']+' — '+finding['title'])+'</td><td>'+', '.join('<a href="#'+e(case)+'">'+e(case)+'</a>' for case in finding['cases'])+'</td><td>'+e(finding['observed'])+'</td></tr>'
 page+='</table></section>'
for r in rows:
 page+=f'<section id="{e(r["id"])}"><h2>{e(r["title"])}</h2><p><b>{e(r["result"])}</b> — {e(r["summary"] or r["phase"])}</p>'
 page+=f'<table><tr><th>Initial state</th><td>{e(r.get("initial",""))}</td></tr><tr><th>Action</th><td>{e(r.get("action",""))}</td></tr><tr><th>Expected</th><td>{e(r.get("expected",""))}</td></tr><tr><th>Observed</th><td>{e(r["summary"] or r["phase"])}</td></tr></table>'
 if r.get('previousEvidence'): page+='<p>Earlier attempt: <a href="'+e(r['previousEvidence'])+'">Preserved setup failure</a></p>'
 for prior in r.get('extraAttempts',[]):page+='<p><a href="'+e(prior)+'">Earlier selected-tree attempt</a></p>'
 if r['checks']:
  page+='<table><tr><th>Assertion</th><th>Actual result</th></tr>'
  for label,v in r['checks'].items():page+=f'<tr><td>{e(label)}</td><td>{e(str(v.get("result",v)))}</td></tr>'
  page+='</table>'
 if r.get('after'):
  page+='<h3>Name and record outcome</h3><table><tr><th>Name</th><th>V2 registration</th><th>Public records match latest values</th><th>Latest values still in V1 source storage</th></tr>'
  for item in r['after']:
   records=item.get('records',[]);source=item.get('source',[]);state=item.get('state') or {}
   page+='<tr><td style="overflow-wrap:anywhere">'+e(item['name'])+'</td><td>'+('Registered' if state.get('status')==2 else 'Not registered')+'</td><td>'+str(sum(x.get('got')==x.get('want') for x in records))+'/'+str(len(records))+'</td><td>'+str(sum(x.get('got')==x.get('want') for x in source))+'/'+str(len(source))+'</td></tr>'
  page+='</table><p>Matching an intentionally empty record does not demonstrate that the name resolves. Registration and each populated record are checked separately.</p>'
  for item in r['after']:
   differences=[x for x in item.get('records',[]) if x.get('got')!=x.get('want')]
   if differences:
    page+='<details><summary>Changed or missing values for '+e(item['name'])+'</summary><table><tr><th>Record</th><th>Latest source value</th><th>Public result after migration</th></tr>'
    for x in differences:page+='<tr><td>'+e(x['what'])+'</td><td><pre>'+e(str(x.get('want')))+'</pre></td><td><pre>'+e(str(x.get('got')))+'</pre></td></tr>'
    page+='</table></details>'
 if r['errors'] or r['error']:page+='<details><summary>Original failure details</summary><pre>'+e(str(r['error'] or '')+'\n'+'\n'.join(str(v) for v in r['errors']))+'</pre></details>'
 page+='</section>'
page=page.replace('<h1>2LD and 3LD priority results</h1>', '<h1>2LD and 3LD priority results</h1><p><a href="../Flattened%20migration%20matrix.html#priority-latest">Open the full matrix with these results merged into the matching wallet rows</a></p>',1)
page+='</html>'
(P/'2LD and 3LD priority results.html').write_text(page)
print(json.dumps(counts))
