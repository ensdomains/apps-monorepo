import json, os, pathlib, subprocess, time
P=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
while not (P/'runs/child-controls/strict-results.json').exists():time.sleep(2)
batches=[('permissions','/priority-permissions.spec.ts$',{'MATRIX_RECORD_PROFILE':'extended'}),('import-recovery','/resolver-import.spec.ts$',{'MATRIX_IDS':'CFG-0015','MATRIX_S4_VARIANT':'cancel-review,reject-first,reject-after-setup','MATRIX_RECORD_PROFILE':'baseline-7'}),('races','/priority-races.spec.ts$',{'MATRIX_RECORD_PROFILE':'extended'}),('conflict','/priority-conflict.spec.ts$',{'MATRIX_RECORD_PROFILE':'extended'})]
for name,spec,extra in batches:
 out=P/'runs'/name
 if (out/'strict-results.json').exists():raise RuntimeError(f'Refusing to overwrite {out}')
 env={**os.environ,'MATRIX_READY':'e2e/.migration-matrix-runs/migration-matrix-1792925893024-21515/ready.json','MATRIX_OUTPUT':str(out),'MATRIX_CACHE_APP_MODULES':'1',**extra}
 (P/'active-batch.json').write_text(json.dumps({'batch':name,'status':'running'}))
 result=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs',spec],cwd=repo,env=env)
 print(name,'exit',result.returncode,flush=True)
 subprocess.run(['python3',str(P/'publish.py')],check=True)
(P/'active-batch.json').write_text(json.dumps({'status':'all initial attempts completed'}))
