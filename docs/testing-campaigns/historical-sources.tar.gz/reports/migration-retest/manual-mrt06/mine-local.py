import json,time,urllib.request
from pathlib import Path
root=Path(__file__).parent
fixture=json.loads((root/'fixture.json').read_text())
def rpc(method,params=[]):
 req=urllib.request.Request('http://127.0.0.1:21545',data=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),headers={'Content-Type':'application/json'})
 data=json.loads(urllib.request.urlopen(req,timeout=5).read())
 if 'error' in data: raise RuntimeError(data['error'])
 return data['result']
while True:
 try:
  original=rpc('eth_getBlockByNumber',[hex(int(fixture['block'])),False])
  if not original or original['hash']!=fixture['blockHash']:raise SystemExit('Fixture chain changed; miner stopped.')
  block=rpc('eth_getBlockByNumber',['latest',False]);now=int(time.time())
  if int(block['timestamp'],16)<now:
   rpc('evm_setNextBlockTimestamp',[now]);rpc('anvil_mine',['0x1','0x1'])
 except Exception as exc:print(type(exc).__name__,str(exc),flush=True)
 time.sleep(1)
