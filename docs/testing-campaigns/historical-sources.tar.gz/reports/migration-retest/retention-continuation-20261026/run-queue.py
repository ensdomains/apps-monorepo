"""Run existing independent specs; preserve every attempt and replay actual history."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl, json, os, signal, subprocess, sys, time, urllib.request

P = Path(__file__).resolve().parent
REPO = Path('/Users/sg/ens/worktrees/pr1494-approval-36')
worker = int(sys.argv[1])
environment = json.loads((P / 'environments.json').read_text())[worker]
ready = environment['ready']

def now(): return datetime.now(timezone.utc).isoformat()

@contextmanager
def queue():
    with (P / 'queue.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        data = json.loads((P / 'queue.json').read_text())
        yield data
        data['updatedAt'] = now()
        temp = P / f'queue-{worker}.tmp'
        temp.write_text(json.dumps(data, indent=2)); temp.replace(P / 'queue.json')

def update(job_id, **values):
    with queue() as q:
        next(j for j in q['jobs'] if j['job_id'] == job_id).update(values)

def rpc(method, params=(), timeout=180):
    request = urllib.request.Request(environment['urls']['ANVIL_RPC_URL'], json.dumps(dict(jsonrpc='2.0', id=1, method=method, params=list(params))).encode(), {'Content-Type': 'application/json'})
    response = json.load(urllib.request.urlopen(request, timeout=timeout))
    if 'error' in response: raise RuntimeError(response['error'])
    return response['result']

def run(job, output, layer=None, history_input=None):
    env = {**os.environ, 'MATRIX_READY': ready, 'MATRIX_OUTPUT': str(output),
           'MATRIX_MAX_LEVEL': '3', 'MATRIX_RECORD_PROFILE': 'extended',
           'MATRIX_HISTORY_RICH': '1', 'MATRIX_CACHE_APP_MODULES': '1',
           'MATRIX_PRIMARY_ACTIONS': '0', 'MATRIX_DATE_ACTIONS': '0',
           'MATRIX_ALL_ACTORS': '1'}
    if job.get('variant'): env['MATRIX_S4_VARIANT'] = job['variant']
    if history_input: env['MATRIX_HISTORY_DIRS'] = str(history_input)
    command = ['node', 'e2e/scripts/run-migration-matrix.mjs', f'--layer={layer or job["layer"]}', f'--ids={job["id"]}']
    output.mkdir(parents=True, exist_ok=True)
    with (output / 'launcher.log').open('a') as log:
        process = subprocess.Popen(command, cwd=REPO, env=env, stdout=log, stderr=log, start_new_session=True)
        failures = 0
        while True:
            try: return process.wait(timeout=15)
            except subprocess.TimeoutExpired: pass
            try:
                assert rpc('eth_chainId', timeout=8) == '0xaa36a7'
                failures = 0
            except Exception as exc:
                failures += 1
                if failures < 6: continue
                diagnostic = {'detectedAt': now(), 'reason': f'Local chain failed six consecutive health checks: {exc}', 'rerunRequired': True, 'environment': environment}
                (output / 'environment-invalid.json').write_text(json.dumps(diagnostic, indent=2))
                os.killpg(process.pid, signal.SIGTERM)
                try: process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL); process.wait(timeout=10)
                raise RuntimeError(diagnostic['reason'])

def published(target):
    last = None
    for _ in range(240):
        try:
            status = json.load(urllib.request.urlopen(environment['urls']['E2E_BIGNAME_URL'] + '/v1/status', timeout=10))
            last = status['data']['chains']['11155111']
            if int(last.get('indexed_block') or 0) >= target: return status
        except Exception as exc: last = str(exc)
        time.sleep(3)
    raise RuntimeError(f'Activity publication did not reach {target}: {last}')

def histories(job, output):
    sources = sorted(output.glob('observations/CFG-*.json')) + sorted(output.glob('supplemental/*.json'))
    eligible = []
    unavailable = []
    for source in sources:
        data = json.loads(source.read_text())
        if data.get('completedAt') and data.get('configuration') and data.get('subject') and data.get('beforeActivity') and data.get('afterActivity') and not data.get('harnessInvalid') and not data.get('historyReplayUnavailable'):
            eligible.append((source, data))
        else: unavailable.append(str(source.relative_to(P)))
    if not eligible:
        update(job['job_id'], historyStatus='NOT RUN — no completed replayable fixture', historyUnavailable=unavailable)
        return
    target = max(int(data['afterActivity']['toBlock']) for _, data in eligible)
    rpc('anvil_mine', ['0x60', '0x1'])
    update(job['job_id'], historyStatus='WAITING FOR INDEXER', historyTarget=target)
    status = published(target)
    results = []
    for index, (source, data) in enumerate(eligible, 1):
        destination = P / f'matrix-history-{job["job_id"]}-a{job.get("attempt", 1):02}-{index:02}'
        inputs = destination / 'input' / 'observations'; inputs.mkdir(parents=True, exist_ok=True)
        link = inputs / (job['id'] + '.json')
        if not link.exists(): link.symlink_to(source)
        code = run(job, destination, 'history', inputs.parent)
        strict = json.loads((destination / 'strict-results.json').read_text()) if (destination / 'strict-results.json').exists() else []
        results.append({'source': str(source.relative_to(P)), 'output': destination.name, 'exitCode': code, 'strictResults': strict})
        update(job['job_id'], historyResults=results)
    update(job['job_id'], historyStatus='EXECUTED', historyResults=results, historyPublication=status, historyUnavailable=unavailable)

def finish(job, code):
    output = P / job['output']
    strict = json.loads((output / 'strict-results.json').read_text()) if (output / 'strict-results.json').exists() else []
    update(job['job_id'], status='EXECUTED' if strict else 'BLOCKED — no test outcome', exitCode=code,
           strictResults=strict, completedAt=now(), historyStatus='PENDING')
    histories(job, output)

# Adopt the initial supervised pilot, then keep claiming independent jobs.
with queue() as q:
    adopted = [dict(j) for j in q['jobs'] if j.get('environment') == worker and j['status'] == 'RUNNING']
for job in adopted:
    file = P / job['output'] / 'strict-results.json'
    while not file.exists(): time.sleep(3)
    results = json.loads(file.read_text())
    finish(job, 0 if results and all(r['status'] == 'passed' for r in results) else 1)

while True:
    with queue() as q:
        if q.get('infrastructure'):
            raise RuntimeError('Campaign infrastructure must be recovered before claiming more work')
        candidates = [j for j in q['jobs'] if j['status'] == 'PENDING']
        if not candidates: break
        job = candidates[0]
        attempt = job.get('attempt', 0) + 1
        job.update(status='RUNNING', attempt=attempt, environment=worker, startedAt=now(), output=f'matrix-{job["job_id"]}-{job["layer"]}-{job["id"]}-{attempt:02}')
        job = dict(job)
    try:
        head = rpc('eth_getBlockByNumber', ['latest', False])
        update(job['job_id'], initialBlock=int(head['number'], 16), initialTimestamp=int(head['timestamp'], 16), environmentSnapshot=environment)
        print(now(), 'START', job['job_id'], job['layer'], job['id'], job.get('variant', ''), flush=True)
        code = run(job, P / job['output'])
        finish(job, code)
        print(now(), 'FINISHED', job['job_id'], 'exit', code, flush=True)
    except Exception as exc:
        update(job['job_id'], status='BLOCKED — infrastructure', infrastructureError=str(exc), historyStatus='BLOCKED — infrastructure', workerNeedsAttention=True)
        # Preserve the exact environment for diagnosis; do not manufacture
        # passes, skip assertions, or reset the source chain under its evidence.
        raise
