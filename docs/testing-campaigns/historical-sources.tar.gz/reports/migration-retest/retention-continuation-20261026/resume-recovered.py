"""Start each continuous worker only after its rebuilt chain/indexer is verified."""
from pathlib import Path
from datetime import datetime, timezone
import fcntl, json, subprocess, time, urllib.request

P = Path(__file__).resolve().parent
REPO = Path('/Users/sg/ens/worktrees/pr1494-approval-36')
COMMIT = '2a5cce392d58c347212cd72985e842a6b455fdf6'
FORK_HASH = '0x3e6b89df580dddc3d65bea4d7fd4c0238c5bec6820597662b099dea91ece8067'
def now(): return datetime.now(timezone.utc).isoformat()
def rpc(url, method, params):
    request = urllib.request.Request(url, json.dumps(dict(jsonrpc='2.0', id=1, method=method, params=params)).encode(), {'Content-Type': 'application/json'})
    data = json.load(urllib.request.urlopen(request, timeout=15))
    if 'error' in data: raise RuntimeError(data['error'])
    return data['result']

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip() == COMMIT
assert not (P / 'runtime-recovery.json').exists(), 'Inspect existing recovery before restarting workers'
environments = json.loads((P / 'environments.json').read_text())
recovery = {'startedAt': now(), 'authorization': 'User: Restart OrbStack and continue', 'candidateCommit': COMMIT, 'status': 'Verifying rebuilt environments', 'volumesPreserved': True, 'workers': []}
for _ in range(600):
    started = {x['worker'] for x in recovery['workers']}
    for worker, env in enumerate(environments):
        if worker in started: continue
        state = P / (env['project'] + '-indexer.json')
        if not state.exists(): continue
        bootstrap = json.loads(state.read_text())
        if bootstrap['status'] != 'ready': continue
        assert rpc(env['urls']['ANVIL_RPC_URL'], 'eth_chainId', []) == '0xaa36a7'
        assert rpc(env['urls']['ANVIL_RPC_URL'], 'eth_getBlockByNumber', ['0xb6d969', False])['hash'] == FORK_HASH
        indexer = json.load(urllib.request.urlopen(env['urls']['E2E_BIGNAME_URL'] + '/v1/status', timeout=15))
        assert int(indexer['data']['chains']['11155111']['indexed_block']) >= bootstrap['target']
        with (P / 'queue.lock').open('w') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            q = json.loads((P / 'queue.json').read_text())
            assert all(j['level'] in ('2LD', '3LD') and j['candidate_commit'] == COMMIT for j in q['jobs'])
            if q.get('infrastructure'):
                incident = q.pop('infrastructure')
                incident.update(recoveredAt=now(), recoveryEvidence='runtime-recovery.json')
                q.setdefault('infrastructureIncidents', []).append(incident)
            q['updatedAt'] = now()
            temp = P / 'queue-recovered.tmp'; temp.write_text(json.dumps(q, indent=2)); temp.replace(P / 'queue.json')
        with (P / f'worker-{worker}.log').open('ab') as log:
            log.write(f'\nApproved runtime recovery: {now()}\n'.encode()); log.flush()
            process = subprocess.Popen(['python3', '-u', str(P / 'run-queue.py'), str(worker)], stdout=log, stderr=log, start_new_session=True)
        recovery['workers'].append({'worker': worker, 'pid': process.pid, 'startedAt': now(), 'environment': env, 'bootstrapTarget': bootstrap['target'], 'verifiedIndexer': indexer})
        recovery['status'] = 'Execution resumed; remaining environments preparing' if len(recovery['workers']) < len(environments) else 'Recovered; all four continuous workers resumed'
        (P / 'runtime-recovery.json').write_text(json.dumps(recovery, indent=2))
        print(worker, env['project'], 'verified; worker started', process.pid, flush=True)
    if len(recovery['workers']) == len(environments): break
    time.sleep(3)
else: raise RuntimeError('Not all rebuilt environments became ready; inspect bootstrap evidence')
