from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json, subprocess, time, urllib.request

P=Path(__file__).resolve().parent
REPO=Path('/Users/sg/ens/worktrees/pr1494-approval-36')
DUMP=P.parent/'execution/history-bootstrap/common-prefork.dump'

def rpc(url, method, params):
    req=urllib.request.Request(url,data=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),headers={'Content-Type':'application/json'})
    data=json.load(urllib.request.urlopen(req,timeout=180))
    if 'error' in data: raise RuntimeError(data['error'])
    return data['result']

def prepare(item):
    name=item['project']; state=P/(name+'-indexer.json')
    assert not state.exists(), 'An existing bootstrap must be inspected, not overwritten'
    original=rpc(item['urls']['ANVIL_RPC_URL'],'eth_getBlockByNumber',['0xb6d969',False])
    assert original['hash']=='0x3e6b89df580dddc3d65bea4d7fd4c0238c5bec6820597662b099dea91ece8067', 'Common archive fork mismatch'
    path=Path(item['compose']);config=json.loads(path.read_text())
    (P/(name+'-compose-before.json')).write_text(json.dumps(config))
    config['services']['bigname-rpc']['environment'].update(UPSTREAM_RPC_URL='http://host.docker.internal:15647',UPSTREAM_IN_FLIGHT='8',UPSTREAM_CHUNK='32',UPSTREAM_MIN_INTERVAL_MS='0')
    config['services']['bigname-runner']['mem_limit']='8g'
    path.write_text(json.dumps(config))
    compose=['docker','compose','-p',name,'-f',str(path),'--profile','bigname']
    with open(P/(name+'-indexer.log'),'ab') as log:
        def run(args,**kw):return subprocess.run(args,stdout=log,stderr=log,check=True,**kw)
        run(compose+['up','-d','bigname-postgres','bigname-init','bigname-roles'])
        for _ in range(90):
            status=subprocess.run(['docker','inspect','--format','{{.State.Status}} {{.State.ExitCode}}',name+'-bigname-roles-1'],capture_output=True,text=True)
            if status.stdout.strip()=='exited 0':break
            time.sleep(2)
        else:raise RuntimeError('Role initialization did not finish')
        with DUMP.open('rb') as src:
            run(['docker','exec','-i',name+'-bigname-postgres-1','pg_restore','-U','bigname','-d','bigname','--clean','--if-exists','--no-owner','--exit-on-error'],stdin=src)
        sql="SET search_path=bigname_phase,public; UPDATE chain_heads SET "+', '.join(f"{x}_block_number=11983209, {x}_block_hash='{original['hash']}'" for x in ['latest','safe','finalized'])+';'
        run(['docker','exec',name+'-bigname-postgres-1','psql','-U','bigname','-d','bigname','-c',sql])
        run(['docker','exec','-i',name+'-bigname-postgres-1','psql','-U','bigname','-d','bigname','-v','ON_ERROR_STOP=1'],input=(REPO/'e2e/infra/bigname/roles.sql').read_bytes())
        # A restored dump has no planner statistics. Rebuild them before the
        # real indexer projects history; this does not alter records or events.
        run(['docker','exec',name+'-bigname-postgres-1','psql','-U','bigname','-d','bigname','-v','ON_ERROR_STOP=1','-c','ANALYZE;'])
        run(compose+['up','-d','--no-deps','bigname-rpc','bigname-api','bigname-runner'])
    target=int(rpc(item['urls']['ANVIL_RPC_URL'],'eth_blockNumber',[]),16)
    rpc(item['urls']['ANVIL_RPC_URL'],'anvil_mine',['0x60','0x1'])
    report={'project':name,'target':target,'commonArchive':str(DUMP),'forkHash':original['hash'],'freshChain':True,'status':'indexing'}
    state.write_text(json.dumps(report,indent=2))
    print(name,'indexing to',target,flush=True)
    for _ in range(240):
        try:
            status=json.load(urllib.request.urlopen(item['urls']['E2E_BIGNAME_URL']+'/v1/status',timeout=10))
            current=status.get('data',{}).get('chains',{}).get('11155111',{}).get('indexed_block')
            report.update(indexed=current)
            if current is not None and int(current)>=target:
                report.update(status='ready',indexerStatus=status);state.write_text(json.dumps(report,indent=2));print(name,'READY',flush=True);return
        except Exception as exc:report['readinessError']=str(exc)
        state.write_text(json.dumps(report,indent=2));time.sleep(3)
    raise RuntimeError(name+' indexer not caught up')

if __name__ == '__main__':
    with ThreadPoolExecutor(max_workers=2) as pool:
        import sys
        items=json.loads((P/'environments.json').read_text())
        list(pool.map(prepare,items if len(sys.argv)==1 else [items[int(i)] for i in sys.argv[1:]]))
