"""Publish only recorded assertions; no inference of whole-row completion."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, html, json, re, os
from urllib.parse import quote

P = Path(__file__).resolve().parent
def atomic_write(path, text):
    temp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temp.write_text(text); temp.replace(path)
ROOT = P.parent
q = json.loads((P / 'queue.json').read_text())
configs = {c['config_id']: c for c in json.loads(Path('/Users/sg/ens/worktrees/pr1494-approval-36/e2e/projects/migration-matrix/configurations.json').read_text())}
accepted = json.loads((ROOT / 'pr-approval-36/accepted-findings.json').read_text())
accepted_ids = {f['id'] for f in accepted['findings']}
new_finding_path = P / 'new-history-finding.json'
new_findings = [json.loads(new_finding_path.read_text())] if new_finding_path.exists() else []
triage_path = P / 'finding-triage.json'
triage = json.loads(triage_path.read_text()) if triage_path.exists() else []
e = lambda v: html.escape(str(v))
link = lambda ref, label: f'<a href="{e(quote(str(ref), safe="/#"))}">{e(label)}</a>'
rows, documents, assertions = {}, [], []

def row(aid):
    c = configs[aid.rsplit('-A', 1)[0]]
    actor = next(a for a in c['actors'] if a['case_id'] == aid)
    return rows.setdefault(aid, {'checks': [], 'sources': [], 'configuration': {k:v for k,v in c.items() if k != 'actors'}, 'actor': actor, 'outcomes': [], 'recorded_workarounds': []})

def add(aid, group, check, result, detail, source, finding='', execution_key=None):
    item = dict(case_id=aid, group=group, check=check, result=result, detail=detail, evidence=source, finding=finding, execution_key=execution_key or f'{source}|{aid}|{group}|{check}')
    row(aid)['checks'].append(item); assertions.append(item)
    if source not in row(aid)['sources']: row(aid)['sources'].append(source)

def known(c, actor, stage, app, action, value, migration_outcome=None):
    if value['result'] != 'FAIL': return ''
    detail = value.get('detail', '')
    if 'Independent' in detail and 'no independent' in detail: return 'MRT-07'
    if 'committed a record edit during grace' in detail: return 'MRT-10'
    if action == 'editRecords' and actor == 'Resolver delegate' and (stage == 'before' or str(migration_outcome).startswith(('blocked', 'excluded'))): return 'MRT-04'
    if action == 'editRecords' and app == 'Manager' and ('legacy resolver authorizes' in detail or 'exact resolver call is authorized' in detail): return 'MRT-01'
    if action == 'editRecords' and app == 'Explorer' and stage == 'after' and c['expected_migration'].startswith('Recreate') and 'exact resolver call is authorized' in detail: return 'MRT-05'
    if 'previous owner must not be presented' in detail: return 'MRT-15'
    if 'different wallet from the legacy token holder' in detail: return 'MRT-02'
    return ''

for job in q['jobs']:
    if not job.get('output'): continue
    out = P / job['output']
    if not (out / 'run-context.json').exists() or (out / 'environment-invalid.json').exists(): continue
    context = json.loads((out / 'run-context.json').read_text())
    assert context['candidateCommit'] == job['candidate_commit']
    sources = list(out.glob('observations/CFG-*.json')) + list(out.glob('supplemental/*.json'))
    for history in job.get('historyResults', []): sources += list((P / history['output']).glob('supplemental/*.json'))
    for source in sources:
        d = json.loads(source.read_text())
        if not d.get('completedAt') or d.get('harnessInvalid'): continue
        c = d.get('configuration', configs[job['id']])
        assert c['level'] in ('2LD', '3LD')
        ref = str(source.relative_to(ROOT))
        aids = {a['actor']: a['case_id'] for a in c['actors']}
        is_history = d.get('id', '').startswith('HISTORY-')
        common = list(aids.values())
        if d.get('actor') in aids: common = [aids[d['actor']]]
        for check_index, check in enumerate(d.get('retentionAssertions', [])):
            targets = [aids[check['actor']]] if check.get('actor') in aids else common
            group = 'records' if any(s in check['check'].lower() for s in ['resolution', 'record', 'snapshot']) else 'permissions'
            for aid in targets: add(aid, group, check['check'], check['result'], 'Expected: ' + check.get('expected','') + '; actual: ' + check.get('actual',''), ref, execution_key=f'{ref}|retention|{check_index}')
        for aid, actor in d.get('actors', {}).items():
            for stage, key in [('before','beforeUI'),('after','afterUI')]:
                for app in actor.get(key, []):
                    for action, value in app.get('checks', {}).items():
                        add(aid, stage, app['app'] + ': ' + action, value['result'], value.get('detail',''), ref, known(c, actor['actor'], stage, app['app'], action, value, d.get('migrationOutcome')))
        for value in d.get('appChecks', []):
            finding = ''
            detail = value.get('detail', '')
            if value['result'] == 'FAIL' and value.get('app') == 'Explorer' and value.get('action') == 'change resolver' and 'could not find registry for this name' in detail.lower() and (c['root_lifecycle'] == 'Grace' or 'Expired' in c['name_expiry']):
                finding = 'MRT-13'
            for reviewed in triage:
                if reviewed['source'] == ref and reviewed['actor'] == value.get('actor') and reviewed['stage'] == value.get('stage') and reviewed['action'] == value.get('action'):
                    assert reviewed['source_sha256'] == hashlib.sha256(source.read_bytes()).hexdigest(), 'Triage evidence changed; review again'
                    assert value['result'] == 'FAIL' and reviewed['finding'] in {f['id'] for f in accepted['findings']}
                    finding = reviewed['finding']
                    detail = reviewed['explanation'] + ' Original assertion: ' + detail
            for aid in ([aids[value['actor']]] if value.get('actor') in aids else common):
                add(aid, value.get('stage','permissions'), value.get('app','') + ': ' + value.get('action',''), value['result'], detail, ref, finding)
        for name, value in d.get('checks', {}).items():
            if not isinstance(value, dict) or 'result' not in value: continue
            group = 'activity' if is_history else 'records' if any(s in name.lower() for s in ['record','resolver import','abi','pubkey']) else 'permissions'
            targets = common
            if d.get('id', '').startswith('ACTIONS-'):
                # These are individual app actions, not actions performed by
                # every wallet sharing the fixture's record baseline.
                owner = c['root_owner'] if c['level'] == '2LD' else c['name_holder'] if c['name_holder'].startswith('W') else c['name_manager']
                actor = next((a for a in aids if name.startswith(f'after: {a} change-resolver workflow')), None)
                actor = actor or ('W1' if 'primary' in name else owner)
                targets = [aids[actor]]
                group = 'before' if name.startswith('before:') else 'after'
            finding = next((f['id'] for f in new_findings if value['result'] == 'FAIL' and ref == P.name + '/' + f['historyEvidence'] and name in f.get('failedChecks', [])), '')
            for aid in targets: add(aid, group, name, value['result'], str(value.get('detail', value.get('error', value.get('triage','Actual asserted workflow; see evidence.')))), ref, finding, execution_key=f'{ref}|check|{name}')
        if d.get('id', '').startswith('ACTIONS-'):
            for key, label in [('beforeRecords', 'Action fixture: records resolve before migration'), ('afterRecords', 'Action fixture: records resolve immediately after migration')]:
                values = d.get(key)
                if not values or (key == 'afterRecords' and d.get('migrationOutcome') != 'success'): continue
                mismatches = [v for v in values if v['got'] != v['want']]
                for aid in common: add(aid, 'records', label, 'FAIL' if mismatches else 'PASS', f'The existing action spec checked all {len(values)} seeded subject-name values; {len(mismatches)} mismatches. This assertion covers the subject name only.', ref, execution_key=f'{ref}|action-records|{key}')
        refusal = d.get('refusalCheckpoint')
        if refusal:
            for aid in common:
                add(aid, 'after', 'Manager migration eligibility', refusal['result'], refusal['outcome'] + ('. Active emancipated child must be allowed to migrate independently of a V2 ancestor in grace.' if refusal.get('confirmedMigrationPolicy') else ''), ref, 'MRT-16' if refusal.get('confirmedMigrationPolicy') else '', f'{ref}|refusal-eligibility')
                if refusal.get('continuityResult') == 'PASS':
                    add(aid, 'records', 'Tree resolution and registration unchanged after refusal', 'PASS', f'The actual refusal checkpoint compared all {len(refusal["before"])} names with their pre-attempt snapshots. This is V1 continuity, not a completed migration.', ref, execution_key=f'{ref}|refusal-tree')
            if refusal.get('continuityResult') == 'PASS':
                for actor, permissions in refusal.get('permissionsBefore', {}).items():
                    if actor not in aids: continue
                    count = sum(isinstance(v, dict) and 'result' in v for v in permissions.values())
                    add(aids[actor], 'permissions', 'Contract permissions unchanged after refusal', 'PASS', f'{count} explicit allowed/denied probes compared before and after the loaded refusal. No blocked probe was accepted; these are contract checks, not app-action completion.', ref, execution_key=f'{ref}|refusal-permissions|{actor}')
        # These success markers are written only after the existing spec's
        # record assertions execute. Surface that actual coverage separately
        # from the enclosing deletion/transfer permission result.
        if d.get('checks', {}).get('Explorer deletion permission and outcome', {}).get('result') == 'PASS':
            for aid in common:
                add(aid, 'records', 'Records resolve before and immediately after migration', 'PASS', f'The existing deletion spec asserted every seeded value in both snapshots ({len(d["beforeRecords"])} before and {len(d["afterRecords"])} after), before attempting deletion.', ref, execution_key=f'{ref}|deletion-record-migration')
                if d['checks']['Explorer deletion permission and outcome'].get('expected') == 'allowed':
                    add(aid, 'records', 'Parent and stored child records survive intentional deletion', 'PASS', 'The actual delete removed the child registration. Separate assertions verified parent resolution and the original child values stored in the retained resolver. Child public resolution after deletion is not expected.', ref, execution_key=f'{ref}|deletion-records')
        if d.get('checks', {}).get('V1 deletion authority and outcome', {}).get('result') == 'PASS':
            allowed = d['checks']['V1 deletion authority and outcome'].get('expected') == 'allowed'
            for aid in common:
                add(aid, 'records', 'Records after V1 deletion or denial', 'PASS', 'Intentional deletion: parent resolution and original stored child values were compared with the exact baselines. The deleted child no longer resolves publicly.' if allowed else 'Denied deletion: registration and complete public-resolution snapshot stayed unchanged. This does not assert that an already-expired name resolves.', ref, execution_key=f'{ref}|legacy-deletion-records')
        if d.get('checks', {}).get('V1 full transfer permission and outcome', {}).get('result') == 'PASS':
            for aid in common:
                add(aid, 'records', 'Resolution unchanged after V1 transfer or denial', 'PASS', f'The existing spec asserted equality with the full {len(d["beforeRecords"])}-record baseline; successful transfers also asserted original resolver values. No migration is inferred from a V1 transfer.', ref, execution_key=f'{ref}|legacy-transfer-records')
        if d.get('id', '').startswith('S4-'):
            importer = aids.get(d.get('importer'), aids.get(c['root_owner']))
            for key, label in [('beforeMigration','Before migration: exact seeded records resolve'), ('afterMigration','After migration: exact records resolve through retained resolver')]:
                if key in d:
                    mismatches = [v for v in d[key] if v['got'] != v['want']]
                    for aid in common: add(aid, 'records', label, 'FAIL' if mismatches else 'PASS', f'{len(d[key])} actual values checked; {len(mismatches)} mismatches. ' + (str(mismatches) if mismatches else ''), ref, execution_key=f'{ref}|{key}')
            for record in d.get('afterImport', []):
                passed = record['got'] == record['want']
                finding = 'MRT-06' if not passed and record['what'].startswith(('ABI 2','ABI 4','ABI 8')) else ''
                for aid in common: add(aid, 'records', 'After resolver workflow: ' + record['what'], 'PASS' if passed else 'FAIL', f'Expected {record["want"]}; actual {record["got"]}', ref, finding, f'{ref}|afterImport|{record["what"]}')
            if d.get('result'):
                value = 'PASS' if d['result'].startswith('PASS') else 'FAIL'
                detail = d['result'] + '. ' + d.get('error','')
                object_abi = any(v['what'] == 'ABI 1' and v['got'].startswith('1:0x7b') and v['got'] == v['want'] for v in d.get('afterMigration', []))
                object_block = value == 'FAIL' and d.get('variant') == 'json-object' and object_abi and 'Preview' in d.get('error','') and 'not enabled' in d.get('error','') and 'Complete required field in Other records' in d.get('finalUI','')
                finding = 'MRT-03' if object_block else ''
                omitted = [r for r in d.get('afterImport', []) if r['want'] != r['got']]
                if value == 'FAIL' and omitted and all(r['what'] in ('ABI 2', 'ABI 4', 'ABI 8') for r in omitted) and not d.get('error'):
                    finding = 'MRT-06'
                if object_block:
                    detail = 'Migration preserved the JSON-object ABI. The acknowledged resolver-import form kept Preview disabled with an Other records validation error. Resolver replacement was not submitted. All 18 final observed record values still match the source; no record loss was observed. Original strict timeout is retained in the raw evidence.'
                    for aid in common: add(aid, 'records', 'Resolver-copy completion and imported values', 'BLOCKED', 'The JSON-object ABI validation failure prevented replacement; copied-record retention was not executed.', ref, finding, f'{ref}|copy-not-completed')
                add(importer, 'after', 'Manager resolver workflow: ' + d['variant'], value, detail, ref, finding)
            for key in ['requiredReadGuard','cancelReview','rejectedImport','recovery']:
                value = d.get(key)
                if value and value.get('result') in ['PASS','FAIL']:
                    add(importer, 'after', 'Resolver workflow: ' + key, value['result'], value.get('detail', value.get('error','Actual asserted checkpoint; see raw evidence.')), ref)
                    if key == 'recovery' and value['result'] == 'PASS': row(importer)['recorded_workarounds'].append(value['detail'])
        # A top-level failure must remain visible even if earlier checkpoints
        # passed. It is not automatically classified as a product defect.
        linked = [a for a in assertions if a['evidence'] == ref]
        if d.get('assertionErrors') and not any(a['result'] in ['FAIL','BLOCKED'] for a in linked):
            targets = [aids[d['actor']]] if d.get('actor') in aids else common
            for aid in targets: add(aid, 'activity' if is_history else 'permissions', 'Unclassified strict assertion failure', 'FAIL', '\n'.join(d['assertionErrors']), ref, execution_key=f'{ref}|unclassified-errors')
        outcome = d.get('migrationOutcome') or ('blocked: ' + refusal['outcome'] if refusal else None)
        if outcome:
            for aid in common:
                if aid in rows and outcome not in rows[aid]['outcomes']: rows[aid]['outcomes'].append(outcome)
        documents.append({'source': ref, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'configuration': c['config_id'], 'job_id': job['job_id'], 'subject': d.get('subject',''), 'phase': d.get('phase','history'), 'error': d.get('error', d.get('blocked','')), 'assertionErrors': d.get('assertionErrors',[]), 'migrationOutcome': outcome, 'scopeExclusions': d.get('scopeExclusions',[]), 'treeBefore': d.get('beforeTreeRecords',[]), 'treeAfter': d.get('afterTreeRecords',[])})

def result(checks):
    counts = Counter(c['result'] for c in checks)
    if not checks: return 'NOT RUN'
    if counts['FAIL']: return f'FAIL — {counts["FAIL"]} failed; {counts["PASS"]} passed; {counts["BLOCKED"]} unverified'
    if counts['BLOCKED']: return f'BLOCKED — {counts["BLOCKED"]} unverified; {counts["PASS"]} passed'
    if counts['PASS']: return f'PASS — {counts["PASS"]} named assertions only'
    return 'N/A — recorded checks not applicable'

for aid, r in rows.items():
    r['migration_scope'] = '; '.join('Migrated successfully to V2' if o == 'success' else o for o in r['outcomes']) or 'Supplementary workflow; no migration outcome inferred.'
    if any('blocked' in o or 'excluded' in o for o in r['outcomes']): r['migration_scope'] += ' After checks are after refusal, on V1; unchanged records do not prove V2 retention.'
    r['results'] = {group: result([c for c in r['checks'] if c['group'] == group]) for group in ['before','after','records','permissions','activity']}
    r['result'] = result(r['checks'])
    r['accepted_findings'] = sorted({c['finding'] for c in r['checks'] if c['finding'] in accepted_ids})
    r['new_findings'] = sorted({c['finding'] for c in r['checks'] if c['finding'] and c['finding'] not in accepted_ids})
    r['untriaged_failures'] = [c for c in r['checks'] if c['result'] == 'FAIL' and not c['finding']]
    r['workarounds'] = list(r['recorded_workarounds'])
    for stage in ['before', 'after']:
        edits = [c for c in r['checks'] if c['group'] == stage and c['check'].endswith(': editRecords')]
        if any(c['result'] == 'FAIL' for c in edits):
            for c in edits:
                if c['result'] == 'PASS' and 'Submitted a distinct record value' in c['detail']:
                    r['workarounds'].append(stage + ': ' + c['check'].split(':')[0] + ' completed a real record edit and verified readback; exact baseline restored.')

workflows = []
for job in q['jobs']:
    if job['status'] == 'PENDING': continue
    strict = Counter(r['status'] for r in job.get('strictResults', []))
    history = Counter(r['status'] for h in job.get('historyResults', []) for r in h.get('strictResults', []))
    outcome = ('FAIL' if any(k != 'passed' and v for k, v in strict.items()) else 'PASS') if strict else 'RUNNING' if job['status'] == 'RUNNING' else 'BLOCKED'
    if job['status'].startswith('BLOCKED'): outcome = 'BLOCKED'
    workflows.append({'job_id': job['job_id'], 'configuration': job['id'], 'layer': job['layer'], 'variant': job.get('variant',''), 'outcome': outcome, 'test_results': dict(strict), 'history_status': job.get('historyStatus','NOT RUN'), 'history_test_results': dict(history), 'output': job.get('output',''), 'infrastructure_error': job.get('infrastructureError','')})
ledger = {'generatedAt': datetime.now(timezone.utc).isoformat(), 'candidate_commit': '2a5cce392d58c347212cd72985e842a6b455fdf6', 'scope': q['scope'], 'excluded': q['excluded'], 'jobs': len(q['jobs']), 'job_status_counts': dict(Counter(j['status'] for j in q['jobs'])), 'workflows': workflows, 'rows': rows, 'documents': documents, 'accepted_findings': accepted, 'assertion_counts': dict(Counter(c['result'] for c in {a['execution_key']: a for a in assertions}.values())), 'note': 'Shared fixture assertions can be linked to several wallets; assertion_counts deduplicates their execution keys. Per-wallet PASS never means the whole matrix row is complete.'}
ledger['infrastructure'] = q.get('infrastructure')
ledger['new_findings'] = new_findings
atomic_write(P / 'results.json', json.dumps(ledger, ensure_ascii=False, indent=2))

page = '<!doctype html><html lang="en"><meta charset="utf-8"><title>Record, permission and activity retention — continuation</title><style>body{font:15px/1.5 system-ui;color:#193b30;background:#f5f8f5;margin:30px}h1{font-size:28px}table{width:100%;border-collapse:collapse;margin:15px 0;background:white}td,th{border:1px solid #cbd9d1;padding:10px;vertical-align:top;text-align:left;overflow-wrap:anywhere}th{background:#e6f1e9}a{color:#08674e}.FAIL{color:#a42828}.PASS{color:#08674e}details{background:white;padding:12px;margin:10px 0}pre{white-space:pre-wrap;font-size:12px}small{color:#52685f}</style><h1>Record, permission and activity retention</h1>'
page += '<p>Tested commit <code>2a5cce392d58c</code>. DNS, legacy stateful suites and all 4LD cases excluded. Each fixture uses fresh names and independent headless wallets. Real indexed history is checked separately.</p>'
page += '<p><b>' + (e(q['infrastructure']['status']) if q.get('infrastructure') else 'Execution is in progress.') + '</b> ' + e(ledger['job_status_counts']) + '. These are existing workflow jobs, often containing several wallets and many assertions; they are not individual assertions.</p>'
if q.get('infrastructure'):
    page += '<p style="border:2px solid #bb7820;padding:14px"><b>' + e(q['infrastructure']['status']) + '.</b> ' + e(q['infrastructure']['reason']) + ' Completed earlier results remain valid. Affected attempts require a fresh rerun.</p>'
page += '<p>' + link('../Flattened migration matrix.html#retention-latest','Full matrix') + ' · ' + link('results.json','Exact assertion ledger') + ' · ' + link('queue.json','Remaining work') + '</p>'
page += '<p><b>PASS</b> = the named assertion ran successfully. <b>FAIL</b> = a completed assertion failed. <b>BLOCKED / NOT RUN</b> = unverified, not a product defect. Accepted findings remain failures and are listed separately. Environment-invalid attempts receive no product pass/fail credit.</p>'
page += '<p><b>Named assertion results:</b> ' + e(' · '.join(f'{v} {k.lower()}' for k,v in ledger['assertion_counts'].items())) + '. Shared checks are counted once even when linked to several wallets.</p>'
for finding in new_findings:
    page += '<section style="border:2px solid #b84d37;padding:16px;background:white"><h2>' + e(finding['id'] + ' — ' + finding['title']) + '</h2><p><b>New finding; not accepted.</b> ' + e(finding['status']) + '.</p><p>An active unwrapped direct child was recreated during its parent’s migration. Its original public-key update is absent from the full history API and Explorer history, although the successful transaction remains on chain. A later API recheck after publication caught up still omitted the event.</p><p>' + e(finding['scope']) + '</p><p>' + e(finding['workaround']) + ' ' + link('new-history-finding.json', 'Exact diagnostic evidence') + '</p></section>'
page += '<details><summary>Workflow runs and activity replays</summary><p>A workflow fails if any assertion fails, even when its other named checks pass. A completed workflow does not imply its activity replay is complete.</p><table><tr><th>Workflow</th><th>Actual test outcome</th><th>Activity replay</th><th>Evidence / limitation</th></tr>'
for w in workflows:
    page += '<tr><td>' + e(f'{w["job_id"]} / {w["configuration"]}: {w["layer"]} {w["variant"]}') + '</td><td>' + e(w['outcome'] + ' — ' + ', '.join(f'{v} {k}' for k,v in w['test_results'].items())) + '</td><td>' + e(w['history_status'] + '; ' + ', '.join(f'{v} {k}' for k,v in w['history_test_results'].items())) + '</td><td>' + (link(w['output'] + '/strict-results.json','Strict test results') if w['test_results'] else 'Test still running or no strict outcome') + '<br>' + e(w['infrastructure_error']) + '</td></tr>'
page += '</table></details>'
page += '<table><tr><th>Initial state / wallet / migration outcome</th><th>Before app checks</th><th>After app checks</th><th>Record retention</th><th>Contract roles / permissions</th><th>Indexed activity</th><th>Findings / verified workaround</th></tr>'
for aid, r in sorted(rows.items()):
    c = r['configuration']
    page += '<tr><td><b>' + e(aid + ' / ' + r['actor']['actor']) + '</b><br>' + e(c['level'] + ', ' + c['wrapping'] + '; parent: ' + c['parent_type'] + '; root ' + c['root_lifecycle']) + '<br>' + e(r['actor']['actor_role']) + '<p>' + e(r['migration_scope']) + '</p></td>' + ''.join('<td>' + e(r['results'][g]) + '</td>' for g in ['before','after','records','permissions','activity']) + '<td>' + e('Accepted: ' + (', '.join(r['accepted_findings']) or 'none')) + '<br>' + e('New: ' + ', '.join(r['new_findings']) if r['new_findings'] else '') + '<br>' + e(f'{len(r["untriaged_failures"])} failed assertions awaiting classification' if r['untriaged_failures'] else '') + '<br>' + e(' '.join(r['workarounds'])) + '</td></tr>'
page += '</table>'
for aid, r in sorted(rows.items()):
    page += '<details id="' + e(aid) + '"><summary>' + e(aid + ' — ' + r['result']) + '</summary><table><tr><th>Checkpoint</th><th>Assertion</th><th>Result</th><th>Actual evidence</th></tr>'
    for c in r['checks']:
        page += '<tr><td>' + e(c['group']) + '</td><td>' + e(c['check']) + '</td><td class="' + e(c['result']) + '">' + e(c['result']) + '</td><td>' + e(c['detail']) + '<br>' + link('../' + c['evidence'],'Raw evidence') + '</td></tr>'
    page += '</table></details>'
page += '<details><summary>Accepted findings — unchanged disposition</summary><p>' + e(accepted['basis']) + '</p><table><tr><th>Finding</th><th>Disposition</th></tr>'
for f in accepted['findings']: page += '<tr><td>' + e(f['id'] + ' — ' + f['title']) + '</td><td>Previously accepted for PR evaluation; failed assertions are retained. No fix is implied.</td></tr>'
page += '</table></details><p><small>Updated ' + e(ledger['generatedAt']) + '</small></p></html>'
atomic_write(P / 'Retention continuation results.html', page)
print(json.dumps({'walletRows': len(rows), 'evidenceFiles': len(documents), 'jobs': ledger['job_status_counts']}))
