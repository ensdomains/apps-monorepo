"""Refresh local reports as current execution evidence changes."""
from pathlib import Path
import fcntl, json, subprocess, time

P = Path(__file__).resolve().parent
with (P / 'report-writer.lock').open('w') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    previous = None
    while True:
        files = [P / 'queue.json', P / 'publish.py', P.parent / 'retention_matrix_integration.py'] + list(P.glob('finding-triage.json')) + list(P.glob('matrix-*/strict-results.json')) + list(P.glob('matrix-*/observations/*.json')) + list(P.glob('matrix-*/supplemental/*.json'))
        signature = [(str(f), f.stat().st_mtime_ns) for f in files]
        if signature != previous:
            subprocess.run(['python3', str(P / 'publish.py')], check=True)
            subprocess.run(['python3', str(P.parent / 'build-flat-matrix.py')], check=True)
            previous = signature
        time.sleep(30)
