import json, os, pathlib, subprocess, time

p = pathlib.Path(__file__).parent
repo = pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
e = os.environ.copy()
e.update(MATRIX_READY=(p / 'second-ready-path.txt').read_text().strip(), MATRIX_RECORD_PROFILE='extended', MATRIX_HISTORY_RICH='1', MATRIX_TEST_HEAP_MB='8192', MATRIX_CACHE_APP_MODULES='1', MATRIX_RESOURCE_POOL=str(p / 'resource-pool'), MATRIX_OUTPUT=str(p / 'runs/grace-workaround-asserted'), APPROVAL_GRACE_PERMISSION_SOURCE=str(p / 'runs/grace-workaround-verified/supplemental/v1-grace-recovery-CFG-0005.json'))
r = subprocess.run(['node', 'e2e/scripts/run-prepared-matrix.mjs', 'approval-grace-permissions.spec.ts'], cwd=repo, env=e)
(p / 'grace-workaround-asserted-exit.json').write_text(json.dumps({'exitCode': r.returncode}))
e.pop('APPROVAL_GRACE_PERMISSION_SOURCE')
e.update(MATRIX_OUTPUT=str(p / 'runs/grace-workaround-asserted-cleanup'), APPROVAL_CLEANUP_SOURCE=str(p / 'runs/grace-workaround-asserted/supplemental'))
r = subprocess.run(['node', 'e2e/scripts/run-prepared-matrix.mjs', 'approval-cleanup.spec.ts'], cwd=repo, env=e)
(p / 'grace-workaround-asserted-cleanup-exit.json').write_text(json.dumps({'exitCode': r.returncode}))
source = p / 'runs/grace-workaround-asserted-history-source/observations'
source.mkdir(parents=True, exist_ok=True)
for f in (p / 'runs/grace-workaround-asserted/supplemental').glob('v1-grace-recovery-*.json'):
    d = json.loads(f.read_text())
    if not d.get('beforeActivity') or not d.get('afterActivity'):
        continue
    (source / d['configuration']['config_id']).with_suffix('.json').write_text(json.dumps(d))
e.update(MATRIX_OUTPUT=str(p / 'runs/grace-workaround-asserted-history'), MATRIX_HISTORY_DIRS=str(source.parent))
r = subprocess.run(['node', 'e2e/scripts/run-prepared-matrix.mjs', 'history-replay.spec.ts'], cwd=repo, env=e)
(p / 'grace-workaround-asserted-history-exit.json').write_text(json.dumps({'exitCode': r.returncode}))
