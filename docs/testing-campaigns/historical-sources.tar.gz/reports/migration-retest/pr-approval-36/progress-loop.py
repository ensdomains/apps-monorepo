import pathlib,time,subprocess
p=pathlib.Path(__file__).parent
for _ in range(360):
 subprocess.run(['python3',str(p/'update-progress.py')])
 time.sleep(30)
