import pathlib,time,os,subprocess,json
p=pathlib.Path(__file__).parent
repo=pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
ready=repo/'e2e/.migration-matrix-runs/migration-matrix-1792915827027-72889/ready.json'
while not ready.exists():time.sleep(5)
env=os.environ.copy();env.update(MATRIX_READY=str(ready),MATRIX_RECORD_PROFILE='extended',MATRIX_HISTORY_RICH='1',MATRIX_TEST_HEAP_MB='8192',MATRIX_CACHE_APP_MODULES='1',MATRIX_UI_ACTORS='W1,W2,W3,Unrelated',MATRIX_RESOURCE_POOL=str(p/'resource-pool'))
jobs=[('roles','ui','CFG-0001,CFG-0003,CFG-0004,CFG-0015,CFG-0019,CFG-0035,CFG-0036'),('setters','setters','CFG-0003'),('trees','core','CFG-0043,CFG-0860,CFG-0916,CFG-0956,CFG-0012'),('imports','resolver','CFG-0011')]
for name,layer,ids in jobs:
 e=env.copy();e['MATRIX_OUTPUT']=str(p/'runs'/name)
 if name=='imports':e['MATRIX_RECORD_PROFILE']='baseline-7'
 args=['node','e2e/scripts/run-migration-matrix.mjs','--layer='+layer,'--ids='+ids]
 if name=='imports':args+=['--grep=supported resolver import|required-read-failure resolver import|pubkey resolver import|missing-inventory resolver import']
 start=time.time(); result=subprocess.run(args,cwd=repo,env=e)
 (p/(name+'-exit.json')).write_text(json.dumps({'exitCode':result.returncode,'duration':time.time()-start}))
