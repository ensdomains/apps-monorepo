import pathlib,time,os,subprocess,json
p=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
while not (p/'second-ready-path.txt').exists():time.sleep(4)
ready=(p/'second-ready-path.txt').read_text().strip()
e=os.environ.copy();e.update(MATRIX_READY=ready,MATRIX_RECORD_PROFILE='extended',MATRIX_HISTORY_RICH='1',MATRIX_TEST_HEAP_MB='8192',MATRIX_CACHE_APP_MODULES='1',MATRIX_RESOURCE_POOL=str(p/'resource-pool'))
for name,spec,extra in [('gates-verified','approval-gates.spec.ts',{'APPROVAL_CASES':'mixed-supported,zero-resolver,custom-resolver,reject-first,reject-after-setup,stale-owner,stale-resolver,receipt-interruption,flag-before-submit,flag-during-recovery,wallet-capability-change'}),('grace','approval-grace.spec.ts',{}),('partial','approval-partial.spec.ts',{}),('missing-inventory','resolver-import.spec.ts',{'MATRIX_IDS':'CFG-0011','MATRIX_S4_VARIANT':'missing-inventory','MATRIX_RECORD_PROFILE':'baseline-7'})]:
 env=e.copy();env.update(extra);env['MATRIX_OUTPUT']=str(p/'runs'/name)
 start=time.time();result=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs',spec],cwd=repo,env=env)
 (p/(name+'-exit.json')).write_text(json.dumps({'exitCode':result.returncode,'duration':time.time()-start}))
