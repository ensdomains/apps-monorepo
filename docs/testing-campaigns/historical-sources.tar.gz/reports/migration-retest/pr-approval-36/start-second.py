import json,os,pathlib,subprocess,time,re
p=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
e=os.environ.copy();e.update(MATRIX_PREPARE_ONLY='1',MATRIX_REAL_INDEXER='1',MATRIX_PORT_OFFSET='5000',MATRIX_ANVIL_MEMORY='24g',MATRIX_SNAPSHOT_INTERVAL='14400',MATRIX_FORK_UPSTREAM_RPC_URL='https://sepolia.gateway.tenderly.co',MATRIX_HISTORY_RPC_URL='http://host.docker.internal:15647',MATRIX_CACHE_SEED_PREFIX='migration-matrix-1792915827027-72889',BIGNAME_INGEST_BLOCKS_PER_BATCH='256',BIGNAME_INGEST_RPC_BATCH_SIZE='16',BIGNAME_INGEST_RPC_MAX_IN_FLIGHT='2')
with open(p/'stack-2.log','ab') as log:proc=subprocess.Popen(['node','e2e/scripts/run-replacement.mjs'],cwd=repo,env=e,stdout=log,stderr=log,start_new_session=True)
(p/'stack-2-process.json').write_text(json.dumps({'pid':proc.pid}))
while True:
 text=(p/'stack-2.log').read_text();match=re.search(r'Fresh isolated stack: (migration-matrix-[\d-]+)',text)
 if match:break
 if proc.poll() is not None:raise RuntimeError('Stack exited before startup')
 time.sleep(2)
project=match[1];r=repo/'e2e/.migration-matrix-runs'/project;compose=['docker','compose','-p',project,'-f',str(r/'compose.json'),'--profile','bigname']
while not (r/'indexer.log').exists():
 if proc.poll() is not None:raise RuntimeError('Stack exited before indexing')
 time.sleep(2)
# Wait for the first initialization to finish before restoring the isolated database.
while True:
 status=subprocess.run(['docker','inspect','--format','{{.State.Running}}',project+'-bigname-runner-1'],text=True,capture_output=True)
 if status.stdout.strip()=='true':break
 time.sleep(2)
subprocess.run(compose+['stop','bigname-api','bigname-runner'],check=True)
with open(p.parent/'execution/history-bootstrap/common-prefork.dump','rb') as dump:subprocess.run(['docker','exec','-i',project+'-bigname-postgres-1','pg_restore','-U','bigname','-d','bigname','--clean','--if-exists','--no-owner','--exit-on-error'],stdin=dump,check=True)
h='0x3e6b89df580dddc3d65bea4d7fd4c0238c5bec6820597662b099dea91ece8067';sql='SET search_path=bigname_phase,public; UPDATE chain_heads SET '+', '.join(f"{x}_block_number=11983209, {x}_block_hash='{h}'" for x in ['latest','safe','finalized'])+';'
subprocess.run(['docker','exec',project+'-bigname-postgres-1','psql','-U','bigname','-d','bigname','-c',sql],check=True)
subprocess.run(['docker','exec','-i',project+'-bigname-postgres-1','psql','-U','bigname','-d','bigname','-v','ON_ERROR_STOP=1'],input=(repo/'e2e/infra/bigname/roles.sql').read_bytes(),check=True)
c=json.loads((r/'compose.json').read_text());c['services']['bigname-rpc']['environment'].update(UPSTREAM_IN_FLIGHT='8',UPSTREAM_CHUNK='32',UPSTREAM_MIN_INTERVAL_MS='0');(r/'compose.json').write_text(json.dumps(c))
subprocess.run(compose+['up','-d','--no-deps','bigname-rpc'],check=True)
subprocess.run(compose+['start','bigname-api','bigname-runner'],check=True)
while not (r/'ready.json').exists():
 if proc.poll() is not None:raise RuntimeError('Stack exited before ready')
 time.sleep(3)
(p/'second-ready-path.txt').write_text(str(r/'ready.json'));print('Second stack ready',r,flush=True)
