import pathlib,time,os,subprocess,json
p=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
while not (p/'missing-inventory-exit.json').exists():time.sleep(5)
e=os.environ.copy();e.update(MATRIX_READY=(p/'second-ready-path.txt').read_text().strip(),MATRIX_RECORD_PROFILE='extended',MATRIX_HISTORY_RICH='1',MATRIX_TEST_HEAP_MB='8192',MATRIX_CACHE_APP_MODULES='1',MATRIX_RESOURCE_POOL=str(p/'resource-pool'),MATRIX_OUTPUT=str(p/'runs/gates-corrected'),APPROVAL_CASES='mixed-supported,zero-resolver')
e.update(MATRIX_OUTPUT=str(p/'runs/partial-verified'))
x=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs','approval-partial.spec.ts'],cwd=repo,env=e);(p/'partial-verified-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
e.update(MATRIX_OUTPUT=str(p/'runs/receipt-verified'),APPROVAL_CASES='receipt-interruption')
x=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs','approval-gates.spec.ts'],cwd=repo,env=e);(p/'receipt-verified-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
e.update(MATRIX_OUTPUT=str(p/'runs/flag-recovery-verified'),APPROVAL_CASES='flag-during-recovery')
x=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs','approval-gates.spec.ts'],cwd=repo,env=e);(p/'flag-recovery-verified-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
e.update(MATRIX_OUTPUT=str(p/'runs/grace-policy-verified'),APPROVAL_GRACE_POLICY_ONLY='1')
x=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs','approval-grace.spec.ts'],cwd=repo,env=e);(p/'grace-policy-verified-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
e.pop('APPROVAL_GRACE_POLICY_ONLY',None)
e.update(MATRIX_OUTPUT=str(p/'runs/grace-workaround'),APPROVAL_VERIFY_RENEWAL_WORKAROUND='1',MATRIX_IDS='CFG-0002,CFG-0005,CFG-0008,CFG-0010')
x=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs','v1-grace-recovery.spec.ts'],cwd=repo,env=e);(p/'grace-workaround-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
e.pop('APPROVAL_VERIFY_RENEWAL_WORKAROUND',None);e.pop('MATRIX_IDS',None)
e.update(MATRIX_OUTPUT=str(p/'runs/cleanup'),APPROVAL_CLEANUP_SOURCE=','.join(str(p/'runs'/x) for x in ['gates-verified/approval','receipt-verified/approval','grace-workaround/supplemental']))
x=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs','approval-cleanup.spec.ts'],cwd=repo,env=e);(p/'cleanup-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
# Build source envelopes from actual saved logs and final chain bindings.
source=p/'runs/second-history-source/observations';source.mkdir(parents=True,exist_ok=True)
for group in ['gates-verified','receipt-verified','flag-recovery-verified','grace','partial-verified']:
 for f in (p/'runs'/group/'approval').glob('*.json'):
  d=json.loads(f.read_text())
  if not d.get('beforeActivity') or not d.get('afterActivity'):continue
  key=f.stem
  states=d.get('finalStates',d.get('after',[]))
  if not states and d.get('finalState'):states=[{'name':d['subject'],'state':d['finalState']}]
  subject=d.get('subject',d.get('roots',[None])[0]);names=d.get('names',[subject]);d['subject']=subject;by={n['name']:n['state'] for n in states}
  d.update(configuration={'config_id':key},names=names,afterState=by.get(subject),afterRoot=by.get(names[0]),afterTreeStates=states,migrationOutcome=d.get('outcome',d.get('retryOutcome','unknown')))
  (source/('CFG-'+key+'.json')).write_text(json.dumps(d))
for f in (p/'runs/missing-inventory/supplemental').glob('resolver-import-*.json'):
 d=json.loads(f.read_text());d['configuration']['config_id']='missing-inventory';(source/'CFG-missing-inventory.json').write_text(json.dumps(d))
for f in (p/'runs/grace-workaround/supplemental').glob('v1-grace-recovery-*.json'):
 d=json.loads(f.read_text())
 if not d.get('beforeActivity') or not d.get('afterActivity'):continue
 key='workaround-'+d['configuration']['config_id'];d['configuration']['config_id']=key;(source/('CFG-'+key+'.json')).write_text(json.dumps(d))
e.update(MATRIX_OUTPUT=str(p/'runs/second-activity'),MATRIX_HISTORY_DIRS=str(source.parent));e.pop('APPROVAL_CASES',None)
x=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs','history-replay.spec.ts'],cwd=repo,env=e);(p/'second-activity-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
