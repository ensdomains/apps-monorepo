import json,pathlib,html,collections,datetime,subprocess
from zoneinfo import ZoneInfo
p=pathlib.Path(__file__).parent
m=json.loads((p/'scenarios.json').read_text()); rows=m['rows'];e=html.escape
for row in rows:
 row['status']=row.get('status','PENDING')
c=collections.Counter(r['status'] for r in rows)
completion=json.loads((p/'completion.json').read_text()) if (p/'completion.json').exists() else {}
headline=completion.get('headline', 'All 36 primary scenarios executed; final workaround checks in progress.' if all(r['status'] in ['PASS','FAIL'] for r in rows) else 'Execution in progress.')
a=json.loads((p/'accepted-findings.json').read_text())
g=a['findings'];g=g if isinstance(g,list) else g.get('gaps',list(g.values()))
body=''.join(f'<tr id="{r["id"]}"><td><a href="cases/{r["id"]}.html">{r["id"]}</a></td><td>{e(r["group"])}</td><td><b>{e(r["title"])}</b><br><small>{e(r["spec"])} · {e(r["selector"])}</small></td><td class="{r["status"].split()[0]}">{e(r["status"])}<br><small>{e(r.get("assessment",""))}</small></td><td>{e(r.get("detail","Awaiting execution on the pinned commit."))}'+('<p><b>Workaround:</b> '+e(r['workaround'])+'</p>' if r.get('workaround') else '')+''.join(f'<br><a href="{e(x)}">Evidence</a>' for x in r.get('evidence',[]))+'</td><td>'+e(', '.join(r.get('acceptedFindings',[])) or '—')+'</td></tr>' for r in rows)
accepted=''.join('<tr><td>'+e(str(x.get('id',x.get('gap_id',''))))+'</td><td>'+e(str(x.get('title','')))+'</td><td>Accepted for this approval decision; not a PASS or proof of a fix.</td></tr>' for x in g if isinstance(x,dict) and x.get('id') != 'MRT-08')
new_section=''
if (p/'new-findings.json').exists():
 new=json.loads((p/'new-findings.json').read_text())['findings']
 new_section='<h2>New findings — not accepted</h2><table><tr><th>Finding</th><th>Observed in</th><th>Result and impact</th><th>Workaround</th></tr>'
 for finding in new:
  affected=[r for r in rows if finding['id'] in r.get('newFindings',[])]
  links=', '.join('<a href="cases/'+r['id']+'.html">'+r['id']+'</a>' for r in affected)
  new_section+='<tr><td><b>'+e(finding['id']+' — '+finding['title'])+'</b></td><td>'+links+'</td><td>'+e(finding['observed'])+'<br>'+e(finding['impact'])+'</td><td>'+e(finding['workaround'])+'</td></tr>'
 new_section+='</table><p><a href="new-findings.json">New-finding evidence and source references</a></p>'
environment_rows=[r for r in rows if r.get('finding','').startswith('ENV-')]
if environment_rows:
 new_section+='<h2>Real-wallet failures — attribution and workaround</h2><table><tr><th>Scenario</th><th>Result</th><th>Verified workaround</th></tr>'+''.join('<tr><td>'+r['id']+'</td><td>'+e(r.get('detail',''))+'</td><td>'+e(r.get('workaround',''))+'</td></tr>' for r in environment_rows)+'</table>'
unit=''
if (p/'supporting-unit-results.json').exists():
 u=json.loads((p/'supporting-unit-results.json').read_text());unit=f'<p>Supporting regression tests: {u["numPassedTests"]} passed, {u["numFailedTests"]} failed. These use test doubles and do not replace the 36 scenarios. <a href="supporting-unit-results.json">Raw results</a>.</p>'
unlocked_followup=''
if (p/'unlocked-parent-results.json').exists():
 followup=json.loads((p/'unlocked-parent-results.json').read_text())
 unlocked_followup='<div class="summary"><b>Additional coverage: unlocked wrapped parent — '+e(followup['status'])+'</b><br>'+str(followup['passed'])+' of 4 fresh migration scenarios passed; '+str(followup['recordComparisons'])+' record values compared. These are additional to the original 36 scenarios. <a href="Unlocked%20parent%20recreation%20results.html">Detailed results, permissions, and retry evidence</a>.</div>'
priority_followup='<div class="summary"><b>Additional 2LD/3LD priority checks</b><br>17 focused scenarios, excluding DNS, all 4LD cases and legacy dependent stateful suites. <a href="../2ld-3ld-priority/2LD%20and%203LD%20priority%20results.html">Current results, source-change findings and corrected reruns</a>. Their counts are separate from the original 36.</div>' if (p.parent/'2ld-3ld-priority/results.json').exists() else ''
text=f'''<!doctype html><html lang="en"><meta charset="utf-8"><title>PR 1494 · 36-scenario approval report</title><style>body{{font:16px/1.5 system-ui;margin:36px;color:#183044;background:#f7f9fc}}h1{{font-size:30px}}table{{border-collapse:collapse;background:white;width:100%;margin:20px 0}}th,td{{border:1px solid #ccd6e1;padding:12px;vertical-align:top;text-align:left}}th{{background:#e8eff8;position:sticky;top:0}}small{{color:#526578}}.PASS{{color:#176b37;font-weight:bold}}.FAIL{{color:#b02828;font-weight:bold}}.BLOCKED{{color:#986000;font-weight:bold}}a{{color:#126eb3}}.summary{{background:#e8eff8;padding:16px;border-radius:10px}}@media print{{body{{margin:10px;font-size:10px}}th{{position:static}}tr{{break-inside:avoid}}}}</style><h1>PR #1494 — migration approval checks</h1><p>Candidate: <a href="https://github.com/ensdomains/apps-monorepo/pull/1494">PR #1494</a> at <code>{m['candidate']}</code>. Updated {datetime.datetime.now(ZoneInfo('Europe/Stockholm')).strftime('%Y-%m-%d %H:%M %Z')}.</p><div class="summary"><b>{e(headline)}</b> {' · '.join(f'{v} {e(k)}' for k,v in c.items())}. Total: 36 scenarios.</div><p>DNS and legacy dependent stateful suites are excluded. Each scenario starts with fresh names. Cancellation and retry steps belong to that scenario and do not depend on earlier tests. A test failure remains a failure even when its finding is accepted. FAIL means at least one assertion failed; it does not by itself mean migration, records or permissions failed. Open a scenario for the separate check results and classification. Blocked means the required check did not complete; it is not a product verdict.</p>{unlocked_followup}{priority_followup}{unit}<p>The automated browser tests use a test wallet and deterministic name/key discovery with real contract reads, transactions and receipts. Real-wallet and real-indexer checks are reported separately. Prior campaign results do not count as passes on this commit. Corrected reruns and workaround checks are supporting evidence for the same 36 scenarios. <a href="harness-adjustments.json">Test-code corrections</a> · <a href="candidate-source-check.json">Candidate source check</a>.</p><table><thead><tr><th>ID</th><th>Area</th><th>Scenario</th><th>Scenario result</th><th>Evidence / gap / workaround</th><th>Accepted findings observed</th></tr></thead><tbody>{body}</tbody></table>{new_section}<h2>Existing findings accepted separately</h2><p>{e(a['basis'])}</p><table><tr><th>ID</th><th>Finding</th><th>Disposition</th></tr>{accepted}</table><p><a href="../execution/Campaign%20status.html">Earlier full campaign</a> · <a href="scenarios.json">Machine-readable scenario results</a> · <a href="candidate.json">Candidate verification</a> · <a href="pr-final-head-check.json">Latest head recheck</a>. The tested commit was confirmed as the PR head at the start of this execution. The later recheck could not reach GitHub; this report does not claim coverage of any subsequent commits.</p></html>'''
(p/'PR approval results.html').write_text(text)
print(dict(c))

subprocess.run(['python3',str(p/'publish-cases.py')],check=True)
