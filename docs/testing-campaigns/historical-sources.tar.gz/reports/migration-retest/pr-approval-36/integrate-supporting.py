import json


def integrate(p, manifest):
    def read(path):
        try:
            return json.loads(path.read_text())
        except (OSError, ValueError):
            return None

    history = [(f, read(f)) for f in (p / 'runs').glob('*/supplemental/history-*.json')]
    cleanup = [(f, read(f)) for f in (p / 'runs').glob('*/supplemental/*-cleanup.json')]
    for row in manifest['rows']:
        evidence = row.setdefault('evidence', [])
        if row['id'] == 'APR-08':
            for source in (p / 'runs/setter-history-source/observations').glob('*.json'):
                rel = str(source.relative_to(p))
                if rel not in evidence:
                    evidence.append(rel)
        sources = [(rel, read(p / rel)) for rel in evidence if rel.endswith('.json') and not rel.endswith('results.json')]
        sources = [(rel, d) for rel, d in sources if isinstance(d, dict)]
        primary = next((d for rel, d in sources if d.get('id') == 'ROLE-SEVEN'), None)
        if primary is None:
            primary = next((d for rel, d in sources if '/observations/' in rel or '/approval/' in rel), None)
        if primary is None:
            primary = next((d for rel, d in sources if d.get('configuration') or d.get('id') == 'ROLE-SEVEN'), {})
        summary = row.setdefault('verificationSummary', [])

        if row['spec'] == 'full-configurations' and primary.get('completedAt'):
            verified = {}
            for actor in primary.get('actors', {}).values():
                for stage in ['beforeUI', 'afterUI']:
                    for view in actor.get(stage, []):
                        check = view.get('checks', {}).get('editRecords', {})
                        if check.get('result') == 'PASS' and 'Submitted a distinct record' in check.get('detail', ''):
                            verified.setdefault((stage, view['app']), []).append(actor['actor'])
            parts = []
            if 'MRT-01' in row.get('acceptedFindings', []) and ('beforeUI', 'Explorer') in verified:
                parts.append('Before migration, use Explorer for record edits; actual writes and readback passed for ' + ', '.join(verified[('beforeUI', 'Explorer')]) + '.')
            if 'MRT-05' in row.get('acceptedFindings', []) and ('afterUI', 'Manager') in verified:
                parts.append('After child recreation, use Manager for record edits; actual writes and readback passed for ' + ', '.join(verified[('afterUI', 'Manager')]) + '.')
            if 'MRT-07' in row.get('acceptedFindings', []):
                parts.append('No equivalent independent-role-edit workflow was verified; full transfer is a different action.')
            if parts:
                row['workaround'] = ' '.join(parts)

        def add(check, result, detail):
            summary[:] = [x for x in summary if x['check'] != check]
            summary.append(dict(check=check, result=result, detail=detail))

        def attach(file):
            rel = str(file.relative_to(p))
            if rel not in evidence:
                evidence.append(rel)

        names = set(primary.get('names', []))
        if primary.get('id') == 'ROLE-SEVEN':
            names.update([primary['name'], primary['otherName']])
        if primary.get('subject'):
            names.add(primary['subject'])
        matches = [(f, d) for f, d in history if d and d.get('subject') in names and d.get('completedAt')]
        if matches:
            failed = [d['subject'] for f, d in matches if d.get('assertionErrors') or not d.get('checks') or any(x.get('result') != 'PASS' for x in d['checks'].values())]
            checked = {name for f, d in matches for name in d.get('names', {d['subject']: {}}) if any(key.startswith(name + ':') for key in d.get('checks', {}))}
            result = 'FAIL' if failed else ('PASS' if names <= checked else 'PARTIAL — REMAINING NAMES PENDING')
            add('Actual indexed activity history', result, f'{len(checked)} of {len(names)} fixture names checked against the real indexer and Explorer. Failed names: ' + (', '.join(failed) or 'none.'))
            if failed:
                row['status'] = 'FAIL'
                row['detail'] = 'Primary workflow assertions: ' + row.get('workflowStatus', 'UNVERIFIED') + '. Independent actual-history assertions failed; the full scenario is not a pass.'
                if row['id'] == 'APR-17':
                    row['newFindings'] = sorted(set(row.get('newFindings', [])) | {'APR-GAP-02'})
                    row['detail'] = 'Resolver-import warning and flow assertions passed. History failed: the original legacy PubkeyChanged event exists on-chain but is absent from the indexer and Explorer. This does not prove that migration removed it or that this PR introduced the omission.'
                    row['workaround'] = 'The original receipt and event remain readable through RPC; Explorer history remains incomplete for this event.'
            for f, d in matches:
                attach(f)

        exact_sources = {str((p / rel).resolve()) for rel, d in sources}
        clean_matches = [(f, d) for f, d in cleanup if d and d.get('source') in exact_sources]
        if clean_matches:
            okay = all((d.get('status') == 'PASS' and d.get('checks')) or d.get('status') == 'NOT APPLICABLE' for f, d in clean_matches)
            applicable = any(d.get('status') != 'NOT APPLICABLE' for f, d in clean_matches)
            add('Temporary approval cleanup', ('PASS' if applicable else 'NOT APPLICABLE') if okay else 'FAIL', 'Archived contract state at scenario completion: consumed per-token approvals and removal of observed temporary V2 operator grants. Reusable MigrationHelper NFT operator approvals are outside this requirement. NOT APPLICABLE means neither temporary grant occurred in the observed transaction history.')
            for f, d in clean_matches:
                attach(f)

        if row['spec'] != 'approval-grace':
            continue
        selector = row['selector']
        policy_file = p / 'runs/grace-policy-verified/approval' / f'grace-{selector}.json'
        policy = read(policy_file)
        if policy and policy.get('completedAt'):
            checks = [view['checks']['editRecords'] for view in policy.get('graceUI', [])]
            okay = len(checks) == 2 and all(x.get('result') == 'PASS' for x in checks)
            failures = [x.get('detail', '') for x in checks if x.get('result') != 'PASS']
            add('Grace editing policy', 'PASS' if okay else 'FAIL', 'Fresh Manager and Explorer checks using the actual wallet authorization. ' + ' '.join(failures))
            # Classify only a demonstrated successful edit, not merely an editor being visible.
            if any('committed' in x.lower() and 'grace' in x.lower() for x in failures):
                row['acceptedFindings'] = sorted(set(row.get('acceptedFindings', [])) | {'MRT-10'})
            if any(view.get('checks', {}).get(action, {}).get('result') == 'FAIL' for view in policy.get('graceUI', []) for action in ['independentOwnerEdit', 'independentManagerEdit']):
                row['acceptedFindings'] = sorted(set(row.get('acceptedFindings', [])) | {'MRT-07'})
            attach(policy_file)

        work_file = p / 'runs/grace-workaround-final/supplemental' / f'v1-grace-recovery-{selector}.json'
        corrected_work_file = p / 'runs/grace-workaround-complete/supplemental' / f'v1-grace-recovery-{selector}.json'
        if corrected_work_file.exists():
            work_file = corrected_work_file
        verified_work_file = p / 'runs/grace-workaround-verified/supplemental' / f'v1-grace-recovery-{selector}.json'
        if verified_work_file.exists():
            work_file = verified_work_file
        asserted_work_file = p / 'runs/grace-workaround-asserted/supplemental' / f'v1-grace-recovery-{selector}.json'
        if asserted_work_file.exists():
            work_file = asserted_work_file
        work = read(work_file)
        reconnect_error = bool(work and ('connect( login)' in work.get('error', '') or 'PostHog' in work.get('error', '')))
        if not work or not work.get('completedAt') or reconnect_error:
            detail = ('Separate renewal passed, but the driver failed its wallet/feature-flag setup before migration. A corrected fresh run uses a new wallet context and waits for the local feature flags.' if reconnect_error else 'Corrected driver is queued or running on fresh names; no completed workaround is claimed yet. Earlier driver failures and corrections are retained separately.')
            add('Separate renewal then migration workaround', 'RERUN PENDING — TEST CODE', detail)
            row['workaround'] = 'Separate renewal then migration is not yet fully verified. ' + detail
            if reconnect_error:
                attach(work_file)
            old_file = p / 'runs/grace-workaround/supplemental' / f'v1-grace-recovery-{selector}.json'
            old = read(old_file)
            if old:
                attach(old_file)
                if old.get('checks', {}).get('Explorer exposes renewal for a renewable V1 name in grace', {}).get('result') == 'FAIL':
                    row['acceptedFindings'] = sorted(set(row.get('acceptedFindings', [])) | {'MRT-14'})
        if work and work.get('completedAt') and not reconnect_error:
            old_file = p / 'runs/grace-workaround/supplemental' / f'v1-grace-recovery-{selector}.json'
            if old_file.exists():
                prior = row.setdefault('priorAttempts', [])
                rel = str(old_file.relative_to(p))
                if rel not in prior:
                    prior.append(rel)
            check = work.get('checks', {}).get('Separate renewal then migration preserves records and owner', {})
            okay = check.get('result') == 'PASS' and work.get('migrationOutcome') == 'success'
            add('Separate renewal then migration workaround', 'PASS' if okay else 'FAIL / NOT COMPLETED', check.get('detail', work.get('error', 'No completed migration evidence.')))
            row['workaround'] = ('Verified on a fresh fixture: renew separately, then return to Manager and migrate. Original integrated-flow failure remains FAIL.' if okay else 'Separate renewal then migration was attempted but did not complete; see its raw evidence. It is not a verified workaround.')
            if work.get('checks', {}).get('Explorer exposes renewal for a renewable V1 name in grace', {}).get('result') == 'FAIL':
                row['acceptedFindings'] = sorted(set(row.get('acceptedFindings', [])) | {'MRT-14'})
            attach(work_file)
            if work.get('originalSource'):
                prior = row.setdefault('priorAttempts', [])
                rel = str(__import__('pathlib').Path(work['originalSource']).relative_to(p))
                if rel not in prior:
                    prior.append(rel)
            for hf, hd in history:
                if hd and hd.get('subject') == work.get('subject') and hd.get('completedAt'):
                    okay_history = hd.get('checks') and not hd.get('assertionErrors') and all(v.get('result') == 'PASS' for v in hd['checks'].values())
                    add('Separate-renewal workaround history', 'PASS' if okay_history else 'FAIL', 'Real indexer and Explorer checked the fresh workaround fixture after its actual renewal and migration.')
                    attach(hf)
            for cf, cd in cleanup:
                if cd and cd.get('source') == str(work_file.resolve()):
                    add('Separate-renewal workaround approval cleanup', cd.get('status', 'UNVERIFIED'), cd.get('scope', ''))
                    attach(cf)

    finding_file = p / 'new-findings.json'
    findings = read(finding_file)
    if findings:
        grace = [r for r in manifest['rows'] if r['spec'] == 'approval-grace']
        outcomes = {r['id']: next((v['result'] for v in r.get('verificationSummary', []) if v['check'] == 'Separate renewal then migration workaround'), 'PENDING') for r in grace}
        passed = [key for key, value in outcomes.items() if value == 'PASS']
        failed = [key for key, value in outcomes.items() if value.startswith('FAIL')]
        pending = [key for key, value in outcomes.items() if 'PENDING' in value]
        for finding in findings['findings']:
            if finding['id'] != 'APR-GAP-01':
                continue
            finding['evidence'] = [rel for row in grace for rel in row.get('evidence', []) if '/grace/approval/' in rel or '/grace-workaround' in rel]
            if passed or failed:
                finding['workaround'] = ('Separate renewal then migration verified for: ' + (', '.join(passed) or 'none') + '. Attempted but not completed: ' + (', '.join(failed) or 'none') + '. Pending: ' + (', '.join(pending) or 'none') + '. The integrated-flow failure remains open.')
        finding_file.write_text(json.dumps(findings, indent=2))

