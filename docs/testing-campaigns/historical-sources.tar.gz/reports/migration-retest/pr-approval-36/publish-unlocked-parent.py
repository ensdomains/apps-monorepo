import datetime
import html
import json
from pathlib import Path

p = Path(__file__).parent
core = p / 'runs/unlocked-parent-core-verified'
post = p / 'runs/unlocked-parent-postchecks'
ids = ['CFG-0707', 'CFG-0711', 'CFG-0755', 'CFG-0763']
context = json.loads((core / 'run-context.json').read_text())
overrides = json.loads((p / 'unlocked-parent-sources.json').read_text()) if (p / 'unlocked-parent-sources.json').exists() else {}
rows = []
for case_id in ids:
    case_core = Path(overrides.get(case_id, str(core)))
    observation = json.loads((case_core / 'observations' / f'{case_id}.json').read_text())
    extra = json.loads((post / 'supplemental' / f'{case_id}.json').read_text())
    config = observation['configuration']
    records = [record for name in observation.get('afterTreeRecords', []) for record in name['records']]
    assertions = observation.get('retentionAssertions', [])
    passed = (observation.get('migrationOutcome') == 'success'
              and observation.get('completedAt') and not observation.get('assertionErrors')
              and len(records) == 36 and all(r['got'] == r['want'] for r in records)
              and assertions and all(a['result'] == 'PASS' for a in assertions)
              and extra['status'] == 'PASS')
    rows.append({
        'id': case_id,
        'childType': config['wrapping'],
        'wallets': 'Same wallet' if (config['name_holder'] == 'W1' or config['name_manager'] == 'W1') else 'Different wallets',
        'result': 'PASS' if passed else 'FAIL',
        'name': observation['subject'],
        'names': observation['names'],
        'recordComparisons': len(records),
        'matchingRecords': sum(r['got'] == r['want'] for r in records),
        'retentionAssertions': len(assertions),
        'extraChecks': extra['checks'],
        'evidence': [str((case_core / 'observations' / f'{case_id}.json').relative_to(p)), str((post / 'supplemental' / f'{case_id}.json').relative_to(p))],
        'rerun': case_core != core,
        'errors': observation.get('assertionErrors', []),
        'error': observation.get('error'),
    })

summary = {
    'candidate': context['candidateCommit'],
    'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'requirement': 'Direct-child recreation under an active unlocked wrapped .eth parent',
    'status': 'PASS' if all(r['result'] == 'PASS' for r in rows) else 'FAIL',
    'passed': sum(r['result'] == 'PASS' for r in rows),
    'failed': sum(r['result'] == 'FAIL' for r in rows),
    'recordComparisons': sum(r['recordComparisons'] for r in rows),
    'rows': rows,
    'scope': 'Fresh independently seeded names, actual Manager migrations with headless test wallets, direct before/after contract reads and allowed/denied contract simulations. Discovery uses the exact seeded inventory. Supplementary assertions read the same fixture and its archived premigration block. No Explorer editing workflows or real-indexer activity assertions were rerun.',
    'excluded': ['DNS', 'legacy dependent stateful suites'],
    'setupAttempt': 'The first attempt used an unavailable old RPC and stopped during fixture setup. No product migration was attempted. Original evidence retained under runs/unlocked-parent-core.',
    'acceptedFindings': 'No accepted findings were suppressed or used to pass these checks. This focused test does not retest earlier accepted UI findings.',
    'retry': 'The initial CFG-0755 run exceeded the test deadline while the app showed fee estimation; no migration had been submitted. A fresh fixture was rerun with readiness polling corrected for the temporarily absent Upgrade button and a bounded 300-second estimate allowance. All migration, permission and record assertions stayed unchanged. The initial failure is retained and is not classified as a confirmed product defect or silently converted to a pass.',
}
(p / 'unlocked-parent-results.json').write_text(json.dumps(summary, indent=2) + '\n')
e = html.escape
table = ''.join('<tr><td>'+e(r['id'])+'</td><td>'+e(r['childType'])+'</td><td>'+e(r['wallets'])+'</td><td class="'+r['result']+'">'+r['result']+'</td><td>'+str(r['matchingRecords'])+'/'+str(r['recordComparisons'])+'</td><td>'+str(r['retentionAssertions'])+' passed</td><td>'+''.join('<a href="'+e(link)+'">'+('Migration evidence' if i == 0 else 'Independent state checks')+'</a><br>' for i, link in enumerate(r['evidence']))+'</td></tr>' for r in rows)
details = ''.join('<details><summary>'+e(r['id']+' — '+r['name'])+'</summary><table><tr><th>Check</th><th>Result</th><th>Observed state</th></tr>'+''.join('<tr><td>'+e(c['check'])+'</td><td>'+e(c['result'])+'</td><td><pre>'+e(json.dumps(c.get('actual'), indent=2))+'</pre></td></tr>' for c in r['extraChecks'])+'</table></details>' for r in rows)
text = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Unlocked wrapped parent — recreation results</title><style>body{{font:16px/1.55 system-ui;margin:36px;color:#183044;background:#f7f9fc}}table{{border-collapse:collapse;background:white;width:100%;margin:20px 0}}th,td{{border:1px solid #ccd6e1;padding:12px;vertical-align:top;text-align:left}}th{{background:#e8eff8}}.PASS{{color:#176b37;font-weight:bold}}.FAIL{{color:#b02828;font-weight:bold}}a{{color:#126eb3}}.summary{{background:#e8eff8;padding:16px;border-radius:10px}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}}details{{margin:18px 0}}@media print{{body{{margin:10px;font-size:11px}}tr{{break-inside:avoid}}}}</style></head><body>
<h1>Direct-child recreation under an unlocked wrapped parent</h1>
<p>Tested PR #1494 commit <code>{e(summary['candidate'])}</code>. Completed {e(summary['completedAt'])}.</p>
<div class="summary"><b>{summary['status']} — {summary['passed']} of 4 scenarios passed.</b> {summary['recordComparisons']} record values compared across four parents and four children. Additional checks follow the same fresh fixtures; they are not extra migration scenarios.</div>
<p>Every parent was active and wrapped before migration, with the CANNOT_UNWRAP fuse unset. The child variants below cover an unwrapped registry controller and a wrapped child holder with no burned fuses. “Different wallets” means parent wallet W1 and child wallet W2.</p>
<table><tr><th>Case</th><th>V1 child type</th><th>Parent / child wallets</th><th>Result</th><th>Records preserved</th><th>Retention assertions</th><th>Evidence</th></tr>{table}</table>
<p>The Manager upgrade was submitted and mined for every passing case. Independent reads confirmed the canonical UserRegistry, full root control for the parent owner and HCA, the original child holder, ALL child token roles, maximum child expiry, and the exact retained child resolver. The existing contract permission checks compare allowed and denied operations for the parent, child, operator, resolver delegate and unrelated wallets.</p>
<p>{e(summary['scope'])} DNS and legacy dependent stateful suites remain excluded. These results close this specific coverage gap; they do not close the other ticket requirements or provide release approval.</p>
<h2>Independent state verification</h2>{details}
<h2>Gaps, workarounds and accepted findings</h2><p>{e(summary['acceptedFindings'])}</p><p>{e(summary['setupAttempt'])}</p>
<p>{e(summary['retry'])}</p>
<p><a href="unlocked-parent-results.json">Machine-readable results</a> · <a href="runs/unlocked-parent-core-verified/strict-results.json">Initial core test results, including timeout</a> · <a href="runs/unlocked-parent-wrapped-retry/strict-results.json">Fresh CFG-0755 rerun</a> · <a href="runs/unlocked-parent-postchecks/strict-results.json">Supplementary assertion results</a> · <a href="PR%20approval%20results.html">Original 36-scenario report</a></p></body></html>'''
(p / 'Unlocked parent recreation results.html').write_text(text)
print(json.dumps({k: summary[k] for k in ['status', 'passed', 'failed', 'recordComparisons']}))
