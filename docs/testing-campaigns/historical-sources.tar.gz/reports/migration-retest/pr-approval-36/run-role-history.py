import pathlib,json,os,time,subprocess
p=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
e=os.environ.copy();e.update(MATRIX_READY=str(repo/'e2e/.migration-matrix-runs/migration-matrix-1792915827027-72889/ready.json'),MATRIX_RECORD_PROFILE='extended',MATRIX_HISTORY_RICH='1',MATRIX_CACHE_APP_MODULES='1',MATRIX_RESOURCE_POOL=str(p/'resource-pool'))
for key in ['CFG-0015','CFG-0019','CFG-0035','CFG-0036']:
 f=p/'runs/roles/observations'/(key+'.json')
 while True:
  try:d=json.loads(f.read_text())
  except (OSError,ValueError):d={}
  if d.get('completedAt'):break
  time.sleep(5)
 source=p/'runs'/('history-source-'+key)/'observations';source.mkdir(parents=True,exist_ok=True);(source/f.name).write_text(json.dumps(d))
 e.update(MATRIX_HISTORY_DIRS=str(source.parent),MATRIX_OUTPUT=str(p/'runs'/('activity-live-'+key)))
 result=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs','history-replay.spec.ts'],cwd=repo,env=e)
 (p/('activity-live-'+key+'-exit.json')).write_text(json.dumps({'exitCode':result.returncode}))
