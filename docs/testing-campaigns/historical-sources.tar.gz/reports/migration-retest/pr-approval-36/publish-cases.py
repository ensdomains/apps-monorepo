import pathlib,json,html,re
from urllib.parse import quote

p=pathlib.Path(__file__).parent
e=html.escape
out=p/'cases';out.mkdir(exist_ok=True)
manifest=json.loads((p/'scenarios.json').read_text())
style='body{font:15px/1.5 system-ui;margin:32px;color:#183044}table{border-collapse:collapse;width:100%;margin:18px 0}th,td{border:1px solid #ccd6e1;padding:9px;text-align:left;vertical-align:top}th{background:#e8eff8}pre{white-space:pre-wrap;overflow-wrap:anywhere}.PASS{color:#176b37}.FAIL{color:#b02828}small{color:#526578}td{overflow-wrap:anywhere}details{max-width:900px}'
def val(v):
 s=v if isinstance(v,str) else json.dumps(v,ensure_ascii=False)
 return e(s) if len(s)<260 else '<details><summary>Show value</summary><pre>'+e(s)+'</pre></details>'
def table(headers,rows):
 if not rows:return '<p>No separate evidence for this section yet.</p>'
 return '<table><tr>'+''.join('<th>'+e(x)+'</th>' for x in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+val(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</table>'
history=[]
for f in (p/'runs').glob('*/supplemental/history-*.json'):
 try:history.append((f,json.loads(f.read_text())))
 except (ValueError,OSError):pass
for r in manifest['rows']:
 sources=[]
 for rel in r.get('evidence',[]):
  if not rel.endswith('.json') or rel.endswith('results.json'):continue
  try:
   d=json.loads((p/rel).read_text())
   if isinstance(d,dict):sources.append((rel,d))
  except (ValueError,OSError):pass
 primary=next((d for rel,d in sources if 'configuration' in d or d.get('id')=='ROLE-SEVEN'),next((d for rel,d in sources if d.get('expectedMigrated') and d.get('after')),sources[-1][1] if sources else {}))
 config=primary.get('configuration',{})
 basics=[(k.replace('_',' '),v) for k,v in config.items() if k!='actors']
 body='<p><a href="../PR%20approval%20results.html">Back to all 36 scenarios</a></p><h1>'+e(r['id']+' — '+r['title'])+'</h1><p><b>Actual scenario result: '+e(r['status'])+'</b></p><p>'+e(r.get('detail','Execution pending.'))+'</p><p>Accepted findings observed: '+e(', '.join(r.get('acceptedFindings',[])) or 'None recorded')+'. An accepted finding does not turn a failed assertion into a pass.</p>'
 if r.get('workaround'):body+='<p><b>Workaround:</b> '+e(r['workaround'])+'</p>'
 if r.get('verificationSummary'):body+='<h2>What passed and what failed</h2>'+table(['Check','Result / disposition','Explanation'],[[v['check'],v['result'],v['detail']] for v in r['verificationSummary']])
 if basics:body+='<h2>Initial test configuration</h2>'+table(['Dimension','Value'],basics)
 names=primary.get('names',[])
 if names:body+='<p>Fresh test names: '+e(', '.join(names))+'</p>'
 actions=[]
 for a in primary.get('appChecks',[]):actions.append([a.get(k,'') for k in ['stage','app','actor','action','result','detail']])
 for a in primary.get('actors',{}).values():
  for stage in ['beforeUI','afterUI']:
   for app in a.get(stage,[]):
    for key,check in app.get('checks',{}).items():actions.append([stage.replace('UI',''),app.get('app',''),a.get('actor',''),key,check.get('result',''),check.get('detail','')])
 if actions:
  for stage in ['before','after']:
   body+='<h2>'+stage.capitalize()+' migration — app actions</h2>'+table(['Stage','App','Wallet','Action','Result','Evidence / limitation'],[x for x in actions if x[0]==stage])
 date_proof=[d for rel,d in sources if '/corrected-dates/' in rel]
 if date_proof:
  date_rows=[[a.get(k,'') for k in ['stage','app','actor','action','result','detail']] for d in date_proof for a in d.get('appChecks',[]) if 'expiry and grace display' in a.get('action','')]
  body+='<h2>Corrected date-display rerun</h2><p>Fresh names with the same ownership configuration. The initial raw failures above remain visible; this rerun accepts the correct abbreviated month format while still checking the exact date.</p>'+table(['Stage','App','Wallet','Action','Result','Evidence'],date_rows)
 policy_proof=[d for rel,d in sources if '/grace-policy-verified/' in rel]
 if policy_proof:
  policy_rows=[[view.get('app',''),key,check.get('result',''),check.get('detail','')] for d in policy_proof for view in d.get('graceUI',[]) for key,check in view.get('checks',{}).items()]
  body+='<h2>Fresh grace-period policy check</h2><p>The required assertion is renewal before record editing. The shared helper also records other visible actions below; those observations are not additional completed action workflows. Contract authorization and app behavior are tested separately.</p>'+table(['App','Action','Result','Evidence'],policy_rows)
 workaround_proof=[d for rel,d in sources if '/grace-workaround' in rel and not rel.endswith('-cleanup.json') and '/supplemental/v1-grace-recovery-' in rel]
 if workaround_proof:
  body+='<h2>Separate renewal then migration — workaround test</h2><p>This uses a fresh fixture. A successful workaround does not change the failed combined renewal-and-upgrade result.</p>'
  for d in workaround_proof:
   if d.get('originalSource'):body+='<p>'+e(d.get('scope',''))+'</p>'
   body+=table(['Assertion','Result','Evidence'],[[key,value.get('result',''),value.get('detail','')] for key,value in d.get('checks',{}).items()])
   if d.get('error'):body+='<p>'+e(d['error'])+'</p>'
   body+=table(['Record','Expected','After migration','Comparison'],[[v.get('what',''),v.get('want',''),v.get('got',''),'MATCH' if v.get('want')==v.get('got') else 'DIFFERENT'] for v in d.get('afterRecords',[])])
   permission_rows=[]
   owner_transfer='unsafeTransfer' if d.get('transferOracle') else 'transfer'
   for actor,field,actions in [('Owner','ownerAfter',['records','setResolver',owner_transfer]),('Unrelated wallet','unrelatedAfter',['records','setResolver',owner_transfer]),('Retained manager','managerAfter',['records','setResolver','unsafeTransfer','grantResolverRole'])]:
    if actor=='Retained manager' and d.get('configuration',{}).get('retain_manager')!='Keep':continue
    for action in actions:
     check=d.get(field,{}).get(action,{}) if d.get(field) else {}
     if check:
      expected='ALLOWED' if actor=='Owner' or (actor=='Retained manager' and action in ['records','setResolver']) else 'DENIED'
      permission_rows.append([actor,action,expected,check.get('result',''),'PASS' if check.get('result')==expected else 'FAIL'])
   if permission_rows:body+='<p>Permissions below were asserted using real contract authorization simulations after migration. They do not commit another transfer or record change.</p>'+table(['Wallet','Action','Expected','Actual','Assertion'],permission_rows)
 cleanup_proof=[d for rel,d in sources if rel.endswith('-cleanup.json')]
 if cleanup_proof:
  body+='<h2>Temporary approval cleanup</h2>'
  for d in cleanup_proof:body+='<p>'+e(d.get('scope',''))+'</p>'+table(['Overall result','Completion block','Actual archived checks'],[[d.get('status',''),d.get('blockNumber',''),d.get('checks',[])]])
 checks=primary.get('retentionAssertions',[])
 if checks:body+='<h2>Ownership, permission and record assertions</h2>'+table(['Assertion','Wallet case','Result','Expected','Actual'],[[c.get('check',''),c.get('actor',''),c.get('result',''),c.get('expected',''),c.get('actual','')] for c in checks])
 named_checks=primary.get('checks',{})
 if isinstance(named_checks,dict) and named_checks:body+='<h2>Scenario assertions</h2>'+table(['Check','Result','Evidence'],[[key,value.get('result',''),value.get('detail',value.get('evidence',''))] for key,value in named_checks.items() if isinstance(value,dict)])
 before=primary.get('beforeTreeRecords',primary.get('before',[]))
 after=primary.get('afterTreeRecords',primary.get('finalStates',primary.get('after',[])))
 if not isinstance(before,list):before=[]
 if not isinstance(after,list):after=[]
 if not before and primary.get('beforeRecords'):
  records=primary['beforeRecords'];before=records if isinstance(records[0],dict) and 'records' in records[0] else [{'name':primary.get('subject',''),'records':records}]
 if not after and primary.get('finalRecords'):after=[{'name':primary.get('subject',''),'records':primary['finalRecords']}]
 prior={x.get('name'): {v.get('what'):v.get('got') for v in x.get('records',[])} for x in before if isinstance(x,dict)}
 record_rows=[]
 for x in after:
  if not isinstance(x,dict):continue
  for value in x.get('records',[]):
   previous=prior.get(x.get('name'),{}).get(value.get('what'),value.get('want','Not captured'))
   record_rows.append([x.get('name',''),value.get('what',''),previous,value.get('got',''), 'MATCH' if previous==value.get('got') else 'DIFFERENT — see scenario assertions'])
 if record_rows:body+='<h2>Resolved record values</h2><p>Values after the tested attempt are compared with the captured baseline (or seeded expected value). A blocked attempt is not a completed migration. An expected change in empty-resolver fallback is explained by its scenario assertions.</p>'+table(['Name','Record','Before / expected','After attempt','Comparison'],record_rows)
 if primary.get('assertionErrors'):
  body+='<h2>Failed assertions</h2><p>These are the raw assertion failures. Date presentation mismatches and accepted findings are triaged separately in the main report.</p>'+''.join('<details><summary>Failure '+str(i+1)+'</summary><pre>'+e(re.sub(r'\x1b\[[0-9;]*m','',str(x)))+'</pre></details>' for i,x in enumerate(primary['assertionErrors']))
 evidence_names=set(names)
 for rel,d in sources:
  evidence_names.update(d.get('names',[]))
  if d.get('subject'):evidence_names.add(d['subject'])
 matches=[(f,d) for f,d in history if d.get('subject') in evidence_names or d.get('subject')==primary.get('subject')]
 if matches:
  body+='<h2>Actual indexed history</h2>'
  for f,d in matches:
   body+='<p><a href="../'+quote(str(f.relative_to(p)))+'">Raw history evidence</a></p>'+table(['Check','Result','Detail'],[[k,v.get('result',''),v.get('detail','')] for k,v in d.get('checks',{}).items()])
 body+='<h2>Raw evidence</h2><ul>'+''.join('<li><a href="../'+quote(rel)+'">'+e(rel)+'</a></li>' for rel in r.get('evidence',[]))+'</ul><p>Candidate '+e(manifest['candidate'])+'. DNS and dependent legacy stateful suites excluded. Fresh-fixture cancellation/retry steps remain inside their scenario.</p>'
 if r.get('priorAttempts'):body+='<details><summary>Earlier attempts affected by corrected test code</summary><ul>'+''.join('<li><a href="../'+quote(rel)+'">'+e(rel)+'</a></li>' for rel in r['priorAttempts'])+'</ul></details>'
 (out/(r['id']+'.html')).write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>'+e(r['id'])+'</title><style>'+style+'</style>'+body+'</html>')
