import urllib.request,json,time
while True:
 try:
  req=urllib.request.Request('http://127.0.0.1:23545',data=json.dumps({'jsonrpc':'2.0','id':1,'method':'anvil_mine','params':['0x1','0x1']}).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=30) as r: result=json.load(r)
  if 'error' in result: print(result,flush=True)
 except Exception as error:print(str(error),flush=True)
 time.sleep(1)
