import json,os,pathlib,time,subprocess
p=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
while not (p/'imports-exit.json').exists():time.sleep(5)
e=os.environ.copy();e.update(MATRIX_READY=str(repo/'e2e/.migration-matrix-runs/migration-matrix-1792915827027-72889/ready.json'),MATRIX_RECORD_PROFILE='extended',MATRIX_HISTORY_RICH='1',MATRIX_CACHE_APP_MODULES='1',MATRIX_OUTPUT=str(p/'runs/corrected-dates'),MATRIX_RESOURCE_POOL=str(p/'resource-pool'))
x=subprocess.run(['node','e2e/scripts/run-migration-matrix.mjs','--layer=dates','--ids=CFG-0001,CFG-0003,CFG-0004,CFG-0015,CFG-0019,CFG-0035,CFG-0036'],cwd=repo,env=e);(p/'corrected-dates-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
e.update(MATRIX_OUTPUT=str(p/'runs/role-cleanup'),APPROVAL_CLEANUP_SOURCE=str(p/'runs/roles/observations'))
if not (p/'role-cleanup-exit.json').exists():
 x=subprocess.run(['node','e2e/scripts/run-prepared-matrix.mjs','approval-cleanup.spec.ts'],cwd=repo,env=e);(p/'role-cleanup-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
source=p/'runs/import-history-source/observations';source.mkdir(parents=True,exist_ok=True)
for f in (p/'runs/imports/supplemental').glob('resolver-import-*.json'):
 d=json.loads(f.read_text());d['configuration']['config_id']='import-'+d['variant'];(source/('CFG-import-'+d['variant']+'.json')).write_text(json.dumps(d))
# Reuse completed exact-fixture history checks rather than repeat successful ones.
role_source=p/'runs/remaining-role-history/observations';role_source.mkdir(parents=True,exist_ok=True)
for f in (p/'runs/roles/observations').glob('CFG-*.json'):
 d=json.loads(f.read_text());done=False
 for h in (p/'runs').glob('activity*/supplemental/history-*.json'):
  checked=json.loads(h.read_text())
  if checked.get('subject')==d.get('subject') and checked.get('completedAt') and checked.get('checks') and all(v.get('result')=='PASS' for v in checked['checks'].values()) and not checked.get('assertionErrors'):done=True
 if not done:(role_source/f.name).write_text(json.dumps(d))
e.update(MATRIX_OUTPUT=str(p/'runs/activity'),MATRIX_HISTORY_DIRS=','.join(str(p/'runs'/x) for x in ['remaining-role-history','trees','corrected-dates','import-history-source']))
x=subprocess.run(['node','e2e/scripts/run-migration-matrix.mjs','--layer=history'],cwd=repo,env=e);(p/'activity-exit.json').write_text(json.dumps({'exitCode':x.returncode}))
