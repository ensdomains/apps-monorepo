import pathlib,json,subprocess
p=pathlib.Path(__file__).parent;m=json.loads((p/'scenarios.json').read_text())
for r in m['rows']:
 if r['spec']=='manual-wallet':
  manual=json.loads((p/'manual-results.json').read_text()) if (p/'manual-results.json').exists() else {}
  if r['id'] in manual:r.update(manual[r['id']])
  continue
 spec=r['spec'];selector=r['selector']
 r.pop('verificationSummary',None)
 group={'full-configurations':'roles','retained-manager':'setters','configurations':'trees','resolver-import':'imports','approval-gates':'gates','approval-grace':'grace','approval-partial':'partial'}[spec]
 if selector=='missing-inventory':group='missing-inventory'
 if spec=='approval-partial' and (p/'runs/partial-verified/run.log').exists():group='partial-verified'
 if spec=='approval-gates' and selector!='mixed-unsupported':group='gates-verified'
 if selector=='receipt-interruption' and (p/'runs/receipt-verified/run.log').exists():group='receipt-verified'
 if selector=='flag-during-recovery' and (p/'runs/flag-recovery-verified/run.log').exists():group='flag-recovery-verified'
 if selector=='receipt-interruption' and (p/'runs/receipt-final/run.log').exists():group='receipt-final'
 if selector=='receipt-interruption' and (p/'runs/receipt-verified-recovery/run.log').exists():group='receipt-verified-recovery'
 run=p/'runs'/group; candidates=[]
 if spec in ['full-configurations','configurations']:candidates=[run/'observations'/f'{selector}.json']
 elif spec=='approval-gates':candidates=[run/'approval'/f'{selector}.json']
 elif spec=='approval-grace':candidates=[run/'approval'/f'grace-{selector}.json']
 elif spec=='approval-partial':candidates=[run/'approval/partial-tree.json']
 elif spec=='resolver-import':candidates=list((run/'supplemental').glob(f'resolver-import-CFG-0011-{selector}-*.json'))
 elif spec=='retained-manager':candidates=list((run/'supplemental').glob('*.json'))
 candidates=[x for x in candidates if x.exists()]
 statuses=[]
 for name in ['progress-results.json','strict-results.json']:
  if (run/name).exists():statuses=json.loads((run/name).read_text())
 found=next((s for s in statuses if selector in s['title'] or spec in ['retained-manager','approval-partial']),None)
 if found:
  r['status']='PASS' if found['status']=='passed' else 'FAIL'
  r['detail']=f'Executed: {found["status"]}. '+('All assertions in this scenario passed.' if found['status']=='passed' else 'Failed assertions retained; finding triage in progress.')
  r['evidence']=[str((run/'strict-results.json' if (run/'strict-results.json').exists() else run/'progress-results.json').relative_to(p))]
 elif candidates:r['status']='RUNNING';r['evidence']=[]
 else:
  log=run/'run.log'
  if log.exists() and any('[matrix-capacity] admitted ' in line and (selector in line or spec in ['retained-manager','approval-partial']) for line in log.read_text(errors='replace').splitlines()):
   r['status']='RUNNING';r['detail']='Fresh fixture setup is running; no completed scenario verdict yet.';r['evidence']=[str(log.relative_to(p))]
  continue
 for f in candidates:
  try:d=json.loads(f.read_text())
  except json.JSONDecodeError:continue
  r['evidence'].append(str(f.relative_to(p)))
  if not found:r['detail']='Current phase: '+d.get('phase','executing')
  elif d.get('error'):r['detail']+=' '+str(d['error']).split('\n')[0][:320]
  accepted=set(r.get('acceptedFindings',[]));failureDetails=[]
  for v in d.get('actors',{}).values():
   for stage in ['beforeUI','afterUI']:
    for app in v.get(stage,[]):
     for action,result in app.get('checks',{}).items():
      if result.get('result')!='FAIL':continue
      if action in ['independentOwnerEdit','independentManagerEdit']:accepted.add('MRT-07')
      elif stage=='beforeUI' and app.get('app')=='Manager' and action=='editRecords':accepted.add('MRT-01')
      elif stage=='beforeUI' and app.get('app')=='Manager' and action=='ownerDisplay':accepted.add('MRT-02')
      elif stage=='afterUI' and app.get('app')=='Explorer' and action=='editRecords' and selector in ['CFG-0015','CFG-0019','CFG-0035','CFG-0036']:accepted.add('MRT-05')
      failureDetails.append({'stage':stage,'app':app.get('app'),'actor':v.get('actor'),'action':action,'detail':result.get('detail')})
  if accepted:r['acceptedFindings']=sorted(accepted)
  r['observedFailures']=failureDetails
  if spec=='approval-gates' and group in ['gates-verified','receipt-verified'] and selector=='receipt-interruption' and found and found['status']!='passed':
   r['detail']='The intended receipt outage was not injected in this attempt (test-code timing/transport error). Migration completed, but interruption recovery was not tested by that attempt. Raw failure preserved; corrected fresh rerun pending.'
   r['verificationSummary']=[{'check':'Outage injection','result':'FAIL — TEST CODE','detail':'The test checked migration state before the submitted transaction was mined, so no receipt outage was injected.'},{'check':'Interruption/reload recovery','result':'UNVERIFIED','detail':'A fresh run with receipt-time injection is queued.'}]
  if spec=='approval-gates' and selector=='receipt-interruption' and group in ['receipt-final','receipt-verified-recovery']:
   if d.get('completedAt') and d.get('blockedReceiptRequests',0)>0:
    r['verificationSummary']=[{'check':k,**v} for k,v in d.get('checks',{}).items()]
    if 'No eligible names found' in d.get('finalUI','') and not (d.get('checks',{}).get('Completion or recovery offered after reload',{}).get('result')=='PASS'):
     r['newFindings']=['APR-GAP-03']
     r['detail']='Migration mined, then the test blocked its receipt and reloaded. The page showed no eligible names instead of completion or recovery. Names and resolved values remain present; independent checks distinguish retention from this recovery-display failure.'
     r['workaround']='Use Explorer to verify the migrated names and their records. No recovery confirmation within the upgrade page was verified.'
   elif not found:
    r['detail']='Fresh receipt-outage verification is running. The preceding attempt reproduced missing completion/recovery after reload; this run also asserts retention and no duplicate submission even if the UI check fails.'
  if spec=='approval-gates' and group=='gates-verified' and selector=='flag-during-recovery' and found and found['status']!='passed':
   r['detail']='Retry after disabling subname recreation remained at “Checking your subnames” until the first test’s 60-second wait expired. Names remained unmigrated. A fresh run allows the full impact-check timeout and captures the recovery state; cause not yet classified.'
  if spec=='approval-partial' and group=='partial-verified' and found and found['status']=='passed':
   total=len(d.get('names',[]));partial=sum((x.get('state') or {}).get('status')==2 for x in d.get('partialStates',[]));records=[v for x in d.get('after',[]) for v in x.get('records',[])]
   r['detail']=f'PASS: interrupted after {partial} of {total} names migrated, then resumed successfully. All {len(records)} resolved values match; exact owners, all-or-nothing affected trees and no duplicate completed submissions were asserted.'
   r['verificationSummary']=[{'check':'Interrupted migration and recovery','result':'PASS','detail':r['detail']}]
  if spec=='approval-partial' and group=='partial' and d.get('completedAt'):
   r['detail']='Initial attempt stopped before migration because the test waited for a bulk-selection button that the app had removed. Individual root checkboxes were available. Test helper corrected; fresh execution pending.'
   r['verificationSummary']=[{'check':'Migration and recovery','result':'UNVERIFIED','detail':'No migration was attempted. The initial failure was in test selection logic, not a retention assertion.'},{'check':'Corrected fresh execution','result':'PENDING','detail':'Exact roots will be selected using the available individual controls.'}]
  if spec=='approval-grace' and d.get('completedAt'):
   fee_failure=any(x.get('error',{}).get('reason')=='source-expiry-changed' and x.get('key',[''])[0]=='migration-grace-gas-estimate' for x in d.get('queryFailures',[]))
   if fee_failure:
    r['newFindings']=['APR-GAP-01']
    r['detail']='Renew-and-upgrade is blocked before submission: fee estimation rejects the projected renewed expiry as a changed V1 expiry. Migration did not run; post-migration retention is UNVERIFIED. This is a new finding, not covered by the accepted MRT findings.'
    r['verificationSummary']=[
     {'check':'Integrated renewal and migration','result':'FAIL — NEW FINDING','detail':'APR-GAP-01: disabled Upgrade action with “Couldn’t estimate the network fee”; source-expiry-changed in the fee query.'},
     {'check':'Actual migration','result':'NOT REACHED','detail':'V2 remains reserved rather than registered to a migrated owner.'},
     {'check':'Resolution before versus after blocked attempt','result':'PASS' if d.get('beforeRecords')==d.get('finalRecords') else 'REVIEW REQUIRED','detail':'Compares the actual values resolving in grace before and after the attempt. It is not proof of post-migration retention.'},
     {'check':'Post-migration records and roles','result':'UNVERIFIED','detail':'The app blocked the migration; no migrated state exists for these assertions.'},
     {'check':'Grace editing policy','result':'RECHECK PENDING','detail':'Fresh check uses the actual contract authorization before testing the renewal-first app policy.'},
    ]
  if spec=='full-configurations' and d.get('completedAt'):
   retention=d.get('retentionAssertions',[])
   appchecks=d.get('appChecks',[])
   dates=[x for x in appchecks if x.get('result')=='FAIL' and 'expiry and grace display' in x.get('action','')]
   other=[x for x in appchecks if x.get('result')=='FAIL' and x not in dates]
   known=[x for x in failureDetails if (x['stage']=='beforeUI' and ((x['action'] in ['independentOwnerEdit','independentManagerEdit']) or (x['app']=='Manager' and x['action'] in ['editRecords','ownerDisplay']))) or (x['stage']=='afterUI' and x['app']=='Explorer' and x['action']=='editRecords' and selector in ['CFG-0015','CFG-0019','CFG-0035','CFG-0036'])]
   unclassified=[x for x in failureDetails if x not in known]+other
   reruns=p/'runs/corrected-dates/strict-results.json'
   if not reruns.exists():reruns=p/'runs/corrected-dates/progress-results.json'
   date_result=next((x for x in json.loads(reruns.read_text()) if selector in x['title']),None) if reruns.exists() else None
   date_pass=bool(date_result and date_result['status']=='passed')
   if date_result:
    r['evidence'].append(str(reruns.relative_to(p)))
    date_observation=p/'runs/corrected-dates/observations'/f'{selector}.json'
    if date_observation.exists():r['evidence'].append(str(date_observation.relative_to(p)))
   date_detail=('Initial month-name expectation corrected; fresh before/after date-display rerun passed.' if date_pass else 'Initial test expected full month names; app displayed the matching dates with abbreviated months. Test expectation corrected; fresh rerun pending.')
   r['verificationSummary']=[
    {'check':'Migration','result':'PASS' if d.get('migrationOutcome')=='success' else str(d.get('migrationOutcome','UNVERIFIED')),'detail':'Actual transaction outcome; separate from the complete scenario verdict.'},
    {'check':'Ownership, permissions and record retention','result':'PASS' if retention and all(x.get('result')=='PASS' for x in retention) else 'REVIEW REQUIRED','detail':f'{sum(x.get("result")=="PASS" for x in retention)} of {len(retention)} saved assertions passed.'},
    {'check':'Accepted product findings','result':'FAIL — ACCEPTED' if known else 'None observed','detail':', '.join(sorted(accepted))+f'; {len(known)} failed app assertions.'},
    {'check':'Manager date presentation','result':('PASS — CORRECTED RERUN' if date_pass else ('RERUN FAILED — REVIEW REQUIRED' if date_result else 'RERUN PENDING')) if dates else 'PASS','detail':date_detail if dates else 'No date-display failure recorded.'},
    {'check':'Other product failures','result':'REVIEW REQUIRED' if unclassified else 'None identified','detail':f'{len(unclassified)} failed app assertions still require classification. This is not a verdict for unexecuted scenarios.'},
   ]
   histories=[]
   for hf in (p/'runs').glob('activity*/supplemental/history-*.json'):
    hd=json.loads(hf.read_text())
    if hd.get('subject')==d.get('subject') and hd.get('completedAt'):histories.append((hf,hd))
   if histories:
    hf,hd=histories[-1];okay=bool(hd.get('checks')) and all(v.get('result')=='PASS' for v in hd['checks'].values()) and not hd.get('assertionErrors')
    r['verificationSummary'].append({'check':'Actual indexed activity history','result':'PASS' if okay else 'FAIL','detail':'Separate replay against the real indexer and Explorer completed.'})
    r['evidence'].append(str(hf.relative_to(p)))
   if found and not unclassified and len(d.get('assertionErrors',[]))==len(known)+len(dates):
    r['detail']='Migration and retention checks passed. Product failures are limited to '+', '.join(sorted(accepted))+'. '+(('Date-format assertion corrected; fresh rerun passed.' if date_pass else 'Date-format assertion error is separate; corrected rerun '+('failed and needs review.' if date_result else 'pending.')) if dates else 'No other assertion failures recorded.')
for r in m['rows']:r['workflowStatus']=r['status']
import runpy
runpy.run_path(str(p/'integrate-supporting.py'))['integrate'](p,m)
for r in m['rows']:
 if r['status']=='PASS':r['assessment']='All required checks passed'
 elif r['status'] in ['RUNNING','PENDING']:r['assessment']='Verification still running'
 elif r.get('newFindings'):r['assessment']='New finding: '+', '.join(r['newFindings'])
 elif r['spec']=='manual-wallet':r['assessment']='Wallet failure; workaround verified'
 elif r.get('acceptedFindings') and r['spec']=='full-configurations':r['assessment']='Accepted findings only; retention passed'
 else:r['assessment']='See the individual check results'
(p/'scenarios.json').write_text(json.dumps(m,indent=2))
subprocess.run(['python3',str(p/'publish.py')],check=True)
