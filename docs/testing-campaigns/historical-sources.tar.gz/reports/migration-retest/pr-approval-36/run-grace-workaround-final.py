import json, os, pathlib, subprocess, time

p = pathlib.Path(__file__).parent
repo = pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
while not (p / 'second-activity-exit.json').exists():
    time.sleep(5)
e = os.environ.copy()
e.update(MATRIX_READY=(p / 'second-ready-path.txt').read_text().strip(), MATRIX_RECORD_PROFILE='extended', MATRIX_HISTORY_RICH='1', MATRIX_TEST_HEAP_MB='8192', MATRIX_CACHE_APP_MODULES='1', MATRIX_RESOURCE_POOL=str(p / 'resource-pool'), MATRIX_OUTPUT=str(p / 'runs/grace-workaround-final'), MATRIX_IDS='CFG-0002,CFG-0005,CFG-0008,CFG-0010', APPROVAL_VERIFY_RENEWAL_WORKAROUND='1')
r = subprocess.run(['node', 'e2e/scripts/run-prepared-matrix.mjs', 'v1-grace-recovery.spec.ts'], cwd=repo, env=e)
(p / 'grace-workaround-final-exit.json').write_text(json.dumps({'exitCode': r.returncode}))
e.pop('MATRIX_IDS'); e.pop('APPROVAL_VERIFY_RENEWAL_WORKAROUND')
e.update(MATRIX_OUTPUT=str(p / 'runs/grace-workaround-final-cleanup'), APPROVAL_CLEANUP_SOURCE=str(p / 'runs/grace-workaround-final/supplemental'))
r = subprocess.run(['node', 'e2e/scripts/run-prepared-matrix.mjs', 'approval-cleanup.spec.ts'], cwd=repo, env=e)
(p / 'grace-workaround-final-cleanup-exit.json').write_text(json.dumps({'exitCode': r.returncode}))
source = p / 'runs/grace-workaround-final-history-source/observations'
source.mkdir(parents=True, exist_ok=True)
for f in (p / 'runs/grace-workaround-final/supplemental').glob('v1-grace-recovery-*.json'):
    d = json.loads(f.read_text())
    if not d.get('beforeActivity') or not d.get('afterActivity'):
        continue
    (source / d['configuration']['config_id']).with_suffix('.json').write_text(json.dumps(d))
e.update(MATRIX_OUTPUT=str(p / 'runs/grace-workaround-final-history'), MATRIX_HISTORY_DIRS=str(source.parent))
r = subprocess.run(['node', 'e2e/scripts/run-prepared-matrix.mjs', 'history-replay.spec.ts'], cwd=repo, env=e)
(p / 'grace-workaround-final-history-exit.json').write_text(json.dumps({'exitCode': r.returncode}))
