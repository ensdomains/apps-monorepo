import json, os, pathlib, subprocess, time

p = pathlib.Path(__file__).parent
repo = pathlib.Path('/Users/sg/ens/worktrees/pr1494-approval-36')
while True:
    if (p / 'activity-exit.json').exists():
        ready = repo / 'e2e/.migration-matrix-runs/migration-matrix-1792915827027-72889/ready.json'
        break
    time.sleep(5)
e = os.environ.copy()
e.update(MATRIX_READY=str(ready), MATRIX_OUTPUT=str(p / 'runs/receipt-verified-recovery'), MATRIX_RECORD_PROFILE='extended', MATRIX_HISTORY_RICH='1', MATRIX_TEST_HEAP_MB='8192', MATRIX_CACHE_APP_MODULES='1', MATRIX_RESOURCE_POOL=str(p / 'resource-pool'), APPROVAL_CASES='receipt-interruption')
(p / 'receipt-verified-recovery-ready-path.txt').write_text(str(ready))
r = subprocess.run(['node', 'e2e/scripts/run-prepared-matrix.mjs', 'approval-gates.spec.ts'], cwd=repo, env=e)
(p / 'receipt-verified-recovery-exit.json').write_text(json.dumps({'exitCode': r.returncode}))
e.update(MATRIX_OUTPUT=str(p / 'runs/receipt-verified-recovery-cleanup'), APPROVAL_CLEANUP_SOURCE=str(p / 'runs/receipt-verified-recovery/approval'))
r = subprocess.run(['node', 'e2e/scripts/run-prepared-matrix.mjs', 'approval-cleanup.spec.ts'], cwd=repo, env=e)
(p / 'receipt-verified-recovery-cleanup-exit.json').write_text(json.dumps({'exitCode': r.returncode}))
source = p / 'runs/receipt-verified-recovery-history-source/observations'
source.mkdir(parents=True, exist_ok=True)
d = json.loads((p / 'runs/receipt-verified-recovery/approval/receipt-interruption.json').read_text())
states = d['finalStates']
by_name = {s['name']: s['state'] for s in states}
subject = d['names'][0]
d.update(configuration={'config_id': 'receipt-interruption'}, subject=subject, afterState=by_name[subject], afterRoot=by_name[subject], afterTreeStates=states, migrationOutcome='success' if d.get('phase') == 'complete' else 'unknown')
(source / 'CFG-receipt-interruption.json').write_text(json.dumps(d))
e.update(MATRIX_OUTPUT=str(p / 'runs/receipt-verified-recovery-history'), MATRIX_HISTORY_DIRS=str(source.parent))
r = subprocess.run(['node', 'e2e/scripts/run-prepared-matrix.mjs', 'history-replay.spec.ts'], cwd=repo, env=e)
(p / 'receipt-verified-recovery-history-exit.json').write_text(json.dumps({'exitCode': r.returncode}))
