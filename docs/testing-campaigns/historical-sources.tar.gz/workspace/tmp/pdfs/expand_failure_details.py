from pathlib import Path
p=Path('tmp/pdfs/build_record_results.py')
s=p.read_text()
needle="counts=collections.Counter(r['result'] for r in rows)\nsummary="
insert='''counts=collections.Counter(r['result'] for r in rows)
expectations={
 'RP04':'Grandchild eligibility not established by earlier checks; observed continuity failure, intended exclusion unverified.',
 'RP06':'Expected exclusion in current implementation: other-wallet descendants are not copied. Equivalent role reconstruction remains a known gap.',
 'RP07':'Known failing copy route in tested checkout (wrapped descendants below unwrapped root, including zero-expiry fixture). Newer-main changes not verified.',
 'RP08':'Earlier checks prove root renewal/migration only. Descendant exclusion reason and intended eligibility unverified.',
 'RP09':'Earlier checks prove root renewal/migration only. Descendant exclusion reason and intended eligibility unverified.'}
for r in rows:
 if r['result'] not in ('FAIL','NOT MIGRATED'):continue
 proof=ind.get(r['name']); total=len(r['records']); matched=sum(v['result']=='PASS' for v in r['records'])
 beforeOk=sum(v['got']==v['want'] for v in proof['before']) if proof else total
 old=proof.get('oldResolverReadback',[]) if proof else []
 oldErrors=sum('error' in v for v in old)
 migrated=r.get('v2Status')==2
 r['failureBreakdown']={
 'Before migration':f'{beforeOk}/{total} seeded records resolved to expected values through the name.',
 'Did this name migrate?':('YES - independent V2 status check confirms migration.' if migrated else 'NO - independent V2 status check does not show a migrated name; ancestor migration completed.') if proof else 'Migration workflow executed; no separate per-name V2 status snapshot retained for this focused test.',
 'After migration':f'{matched}/{total} seeded records still resolve unchanged; {total-matched} fail preservation.',
 'What failed':'; '.join(v['record'] for v in r['records'] if v['result']=='FAIL'),
 'Was the name totally lost?':('NO evidence of total name loss: V2 migration confirmed and other seeded records still resolve.' if migrated and matched else 'All seeded record lookups fail continuity. This does NOT establish permanent name loss, ownership loss or impossibility of recreation.') if proof else ('Some records still resolve; total name loss is not supported.' if matched else 'Both seeded values disappeared from resolution; total name loss is not established by these checks.'),
 'Old resolver data':f'UNVERIFIED - {oldErrors}/{len(old)} saved direct old-resolver reads returned errors. Cannot confirm intact storage or deletion.' if old else 'UNVERIFIED - no independent direct old-resolver readback retained.',
 'Expected exclusion or gap':expectations.get(r['id'],'Migrated-name record-preservation failure.') if not migrated and proof else ('Deliberately incomplete key inventory: confirms data-loss behavior under that input, not real-indexer frequency.' if 'stale' in r['name'] else 'Record-preservation gap; successful migration does not imply every record was copied.'),
 'Recovery / ownership': 'NOT TESTED - recovery, recreation and post-migration ownership/permission continuity were not exercised in this record test.',
 }
summary='''
assert needle in s;s=s.replace(needle,insert)
needle="parts.append('</table><h2>Executed test cases</h2>"
pos=s.index(needle)
# Insert after closing overview table, before test cases.
s=s[:pos]+'''parts.append('</table><h2 id="failure-breakdown">Failed cases: migration, resolution and name survival</h2><p><b>Evidence correction:</b> previous conversational statements that old records were confirmed intact are withdrawn. The saved direct old-resolver reads returned errors. Storage survival and recoverability remain unverified. Resolution failure is not proof of permanent name or ownership loss.</p>')
for i,r in enumerate(rows):
 if 'failureBreakdown' not in r:continue
 parts.append('<section id="failure-'+str(i)+'"><h3>'+e(r['id']+' / '+r['name'])+'</h3><p>'+e(r['scenario'])+'</p><table><tr><th>Question</th><th>Actual result / limit</th></tr>')
 for k,v in r['failureBreakdown'].items():parts.append('<tr><th>'+e(k)+'</th><td>'+e(v)+'</td></tr>')
 parts.append('</table><p><a href="#values-'+str(i)+'">Exact before/after values</a> | <a href="'+e(r['evidence'])+'">Raw test evidence</a> | <a href="independent-readback.json">Independent readback</a></p></section>')
''' + s[pos:]
s=s.replace("for r in rows:\n parts.append('<details><summary>'", "for i,r in enumerate(rows):\n parts.append('<details id=\"values-'+str(i)+'\"><summary>'")
p.write_text(s)
p=Path('tmp/pdfs/build_report.py');s=p.read_text();needle="page();title('Appendix: legacy case register')"
insert='''page();title('Failed records: how to interpret name survival')
para('Evidence correction: earlier conversational statements that old resolver records were confirmed intact are withdrawn. Saved direct reads returned errors. This report distinguishes lost resolution from proven storage deletion, ownership loss and permanent name loss; the latter three are NOT established.')
para('The following tables cover every failed name outcome, including descendants not migrated. Before/after values and chain blocks are retained in Record preservation results.html and results-summary.json. DNS and legacy stateful suites remain excluded. No new chain tests were run for this reporting expansion.')
failures=[r for r in json.loads((R/'execution/record-preservation/results-summary.json').read_text())['names'] if 'failureBreakdown' in r]
for r in failures:
 page();title(r['id']+' - individual failed-name breakdown')
 para(r['name']);para(r['scenario'])
 tab(['Question','Observed result / evidence limit'],list(r['failureBreakdown'].items()),[125,365])
 para('Evidence: '+r['evidence']+'. Before block '+str(r.get('beforeBlock'))+'; after block '+str(r.get('afterBlock'))+'. Exact record values are available in the accompanying HTML report.')
'''
assert needle in s;s=s.replace(needle,insert+needle);p.write_text(s)
