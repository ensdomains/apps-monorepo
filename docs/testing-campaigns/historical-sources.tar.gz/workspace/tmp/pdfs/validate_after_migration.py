import json
from pathlib import Path
D=Path('/Users/sg/Documents/ChatGPT/ENS/replacement-readiness/execution/after-migration')
s=json.loads((D/'summary.json').read_text())
assert len(s['rows'])==21
assert sorted(r['row'] for r in s['rows'])==list(range(1,22))
assert sum(s['actionCounts'].values())==105
assert len(json.loads((D/'dates-recheck.json').read_text()))==21
assert all(len(row)==5 for row in s['matrix'])
for r in s['rows']:
 assert all(k in r['checks'] for k in ['send','edit','roles','sync','dates'])
 for k in ['send','edit','roles']:
  c=r['checks'][k]
  if c['status']=='PASS' and k=='edit': assert r['observations'].get('ethWrite')
  if c['status']=='PASS' and k=='send' and r['row']!=3: assert r['observations'].get('ownerAfterSend')
  if c['status']=='PASS' and k=='roles': assert r['observations'].get('grantedRoles')
print(json.dumps({'rows':len(s['rows']),'checks':s['actionCounts'],'migrated':sum(r.get('v2Status')==2 for r in s['rows']),'notMigrated':sum(isinstance(r.get('v2Status'),int) and r.get('v2Status')!=2 for r in s['rows'])},indent=2))
