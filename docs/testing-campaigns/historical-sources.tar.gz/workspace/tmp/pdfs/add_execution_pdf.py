from pathlib import Path
p=Path('tmp/pdfs/build_report.py');s=p.read_text();a=s.index("page();title('Record preservation: a separate migration acceptance gate')")
block='''# Actual record-preservation execution, separate from the older 131-case ledger.
record_path=R/'execution/record-preservation/results-summary.json'
if record_path.exists():
 executed=json.loads(record_path.read_text())
 page();title('Record preservation: actual execution results')
 para('<b>Local execution on 23 October 2026.</b> The app performed migration transactions on the fork. Every seeded value was resolved through the UniversalResolver before migration and compared afterwards. Names and record keys came from a fixture inventory. DNS and legacy stateful suites were excluded.')
 para('<b>Name outcomes:</b> '+esc(', '.join(str(v)+' '+k for k,v in executed['nameResults'].items()))+'. <b>Individual record comparisons:</b> '+esc(', '.join(str(v)+' '+k for k,v in executed['recordResults'].items()))+'. These counts are additional to the 131 legacy cases, not replacements for them.')
 tab(['Finding','Actual evidence / interpretation'],[
 ['FAIL: public-key and interface records','Public-key and interface values stopped resolving on completed migrations. Other populated record types can pass for the same name; the all-records result still fails. See per-name results below.'],
 ['FAIL: descendant resolution','In the emancipated-child and separate-child-holder scenarios, some descendants were not migrated. Their seeded records no longer resolved after ancestor migration. This is a resolution-path failure, not proof that the old stored bytes were deleted.'],
 ['Harness correction','The original mock omitted contenthash and ABI types from resolver inventory. That run was excluded from final results. Corrected runs advertise those fields consistently; a separate deliberate stale-inventory test remains.'],
 ['NOT VERIFIED: real indexer and UI','The real indexer was stopped with a chain-history mismatch. These results do not certify record discovery by it, or complete record rendering in Manager and Explorer.'],
 ['Evidence and reproducibility','Exact fixture names, before/after values, chain blocks and per-record statuses are saved in Record preservation results.html and results-summary.json in execution/record-preservation. Test source and raw run outputs are retained.']],[175,562])
 entries=executed['names']
 for start in range(0,len(entries),7):
  page();title('Executed record comparisons: names '+str(start+1)+'-'+str(min(start+7,len(entries))))
  para('PASS requires every tested record to match. NOT MIGRATED identifies a name outside the completed V2 migration; its resolution outcome is still reported. Fixture IDs identify the exact names in the companion HTML evidence.')
  table_rows=[]
  for item in entries[start:start+7]:
   rec=item['records'];passed=sum(r['result']=='PASS' for r in rec);failed=[r['record'] for r in rec if r['result']=='FAIL']
   label=item['id']+' / '+(['.eth name','child','grandchild'][item.get('depth',0)] if item['id']!='TYPE' else item['scenario'])
   context=item['scenario'] if item['id']!='TYPE' else 'Focused record-format check'
   verdict=item['result']+('; resolution '+str(item.get('resolutionResult')) if item['result']=='NOT MIGRATED' else '')
   table_rows.append([label,context,verdict,str(passed)+' / '+str(len(rec)),', '.join(failed) if failed else 'None in completed comparisons' if rec and passed==len(rec) else 'Comparison incomplete'])
  tab(['Fixture / name level','Name state or check','Result','Records matching','Records that did not match'],table_rows,[135,190,110,80,222])
 para('The root, child and grandchild are checked independently. The tested inventory covers fixed seeded records; this is not a claim that all possible custom resolvers, off-chain records, wildcard behaviour or reverse records are covered.')
'''
s=s[:a]+block+s[a:]
s=s.replace('This document consolidates existing local test evidence; preparing the PDF did not run new tests.', 'This document combines earlier ownership evidence with new local record-preservation execution, reported separately.')
s=s.replace('No new browser execution was performed for this PDF.', 'The record-preservation section adds a separate local execution run.')
s=s.replace('<b>Current result: NOT VERIFIED for complete record preservation across all migrated names.</b> Existing checks prove selected profile or child-record readbacks only. They do not establish a complete before-and-after inventory for every name, resolver and record type. No new migration tests were run for this report update.', '<b>Acceptance criteria and remaining scope.</b> Actual execution results appear in the preceding tables. Complete preservation cannot pass while the reproduced record and descendant-resolution failures remain. Broader resolver discovery and display coverage is still not verified.')
s=s.replace('NOT VERIFIED across the full matrix.', 'Seeded fixture baselines executed; real-indexer completeness NOT VERIFIED.')
s=s.replace('Selected record readbacks exist; complete comparison NOT VERIFIED.', 'Seeded comparisons executed; see actual per-name PASS/FAIL results.')
s=s.replace('Full descendant and split-wallet intersection NOT VERIFIED.', 'Executed cases include descendant-resolution failures; other intersections remain NOT VERIFIED.')
p.write_text(s)
