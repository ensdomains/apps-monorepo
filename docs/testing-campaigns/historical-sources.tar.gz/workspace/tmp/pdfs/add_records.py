from pathlib import Path
p=Path('tmp/pdfs/build_report.py');s=p.read_text();a=s.index("page();title('Remaining tests before claiming full parity')")
s=s[:a]+'''page();title('Record preservation: a separate migration acceptance gate')
para('<b>Current result: NOT VERIFIED for complete record preservation across all migrated names.</b> Existing checks prove selected profile or child-record readbacks only. They do not establish a complete before-and-after inventory for every name, resolver and record type. No new migration tests were run for this report update.')
tab(['Check for every name and descendant','Required comparison / evidence','Current coverage'],[
['Capture the complete baseline','Before migration, save each known record key, type and value, the resolver, chain, block and name. Use fixture definitions plus available history/inventory; a UI list alone cannot prove completeness.','NOT VERIFIED across the full matrix.'],
['Compare actual resolved values','After migration, resolve the same name and record keys through the supported public resolution path. Compare addresses as bytes, text exactly and binary records by their encoded values. A successful old-resolver read is insufficient.','Selected record readbacks exist; complete comparison NOT VERIFIED.'],
['Keep records reachable','Check root, child and grandchild names after parent migration and after each supported migration order. Records left on an old resolver but unreachable through the name do not pass preservation.','Full descendant and split-wallet intersection NOT VERIFIED.'],
['Check both app displays','Manager and Explorer must load and show the retained records without losing fields or failing the whole records page. Distinguish an indexing/display delay from changed resolved values.','Full record-type matrix NOT VERIFIED.'],
['Check permission repairs','Re-run the same comparison after resolver replacement or role recovery. An empty-profile recovery test cannot establish preservation of populated profiles.','Populated-profile recovery NOT VERIFIED.'],
['Keep unrelated values unchanged','When separately testing an authorized edit, change one chosen record and compare all the others. Verify the previous manager and unrelated wallet cannot silently overwrite records.','Requires dedicated authorized state-changing checks; excluded suites remain excluded.']],[177,390,170])
page();title('Record checklist and precise pass / fail rules')
tab(['Record or condition','What must survive'],[
['ETH and other chain addresses','Every populated coin-type address, including records absent from the app display. Do not check only the main ETH address.'],
['Text records','All standard and custom keys, including profile, URL, email, avatar and social records when present. Retain exact values and distinguish missing from intentionally empty values.'],
['Content hash','The complete stored content identifier, not just the displayed link.'],
['ABI records','Every stored content type used by the fixture; retain content and successful resolution. Include the legacy JSON-object case. Stored bytes, resolved values and editor acceptance are separate assertions.'],
['Other resolver capabilities','Public keys, supported custom records, wildcard/inherited resolution and off-chain records where present. Record unsupported cases explicitly; do not silently omit them.'],
['Primary name / reverse lookup','Check separately from forward records: the wallet still resolves to the intended primary name and forward verification succeeds where required. Ownership alone does not prove this.'],
['Name state and wallet combinations','Repeat for active names, grace names after renewal, wrapped/unwrapped names, children and grandchildren, and same-wallet / split-wallet ownership. DNS stays excluded.']],[190,547])
sub('Two results per name - never a single ambiguous missing label')
para('<b>Record preservation:</b> PASS only when the captured inventory is complete for that test fixture and every required value still resolves. FAIL when a previously resolving record disappears, changes unexpectedly or becomes unreachable. NOT VERIFIED when the baseline or comparison is incomplete. A read error is a failed resolution check, not proof that stored data was deleted.')
para('<b>App display:</b> record PASS, PASS WITH WORKAROUND, FAIL or NOT VERIFIED independently. Required evidence per record: name, key/type, before value, after value, resolution result, display result, evidence location and any workaround. A changed resolver address is acceptable only if the required records remain correctly resolvable.')
''' +s[a:]
s=s.replace("['Resolver recovery with existing records','Check populated profiles survive any resolver replacement or permission-repair workaround.']", "['Record preservation for every migrated name','Capture and compare the complete known record inventory before/after migration and resolver recovery, through actual resolution and both app displays. See the record-preservation tables.']")
p.write_text(s)
