from pathlib import Path
import json, re, html, collections
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
R=Path('/Users/sg/Documents/ChatGPT/ENS/replacement-readiness')
d=json.loads((R/'parity-ledger.json').read_text()); by={c['id']:c for c in d['tests']}
after=json.loads(Path('/Users/sg/Documents/ChatGPT/ENS/tmp/pdfs/after-preview-summary.json').read_text())
# Read the report builder's definitions only; do not rewrite the original report.
src=Path('/tmp/build-ownership-report.py').read_text().split('sections=[]')[0]
ns={};exec(src,ns)
rows=ns['rows']; migrations=ns['migrations']; selected=ns['selected']
def clean(t):
 t=re.sub(r'<br\s*/?>',' | ',t);t=re.sub('<[^>]+>','',t);t=html.unescape(t)
 return t.replace('—',' - ').replace('–','-').replace('→',' / ').replace('’',"'").replace('“','"').replace('”','"').replace('×',' x ').replace('·','; ')
def esc(t):return html.escape(clean(t))
styles=getSampleStyleSheet()
for n in ['Normal','BodyText']:styles[n].fontName='Helvetica';styles[n].fontSize=10;styles[n].leading=14
styles.add(ParagraphStyle(name='TitleX',fontName='Helvetica-Bold',fontSize=29,leading=34,textColor=colors.HexColor('#123b39'),spaceAfter=20))
styles.add(ParagraphStyle(name='HeadX',fontName='Helvetica-Bold',fontSize=18,leading=23,textColor=colors.HexColor('#123b39'),spaceAfter=12))
styles.add(ParagraphStyle(name='SubX',fontName='Helvetica-Bold',fontSize=12,leading=16,textColor=colors.HexColor('#123b39'),spaceBefore=8,spaceAfter=6))
styles.add(ParagraphStyle(name='SmallX',fontName='Helvetica',fontSize=8,leading=11))
styles.add(ParagraphStyle(name='CellX',fontName='Helvetica',fontSize=9,leading=12))
styles.add(ParagraphStyle(name='ScenarioX',fontName='Helvetica',fontSize=11,leading=15))
story=[]
def p(t,style='BodyText'):return Paragraph(t,styles[style])
def para(t):story.extend([p(t),Spacer(1,8)])
def title(t):story.append(p(t,'HeadX'))
def sub(t):story.append(p(t,'SubX'))
def page():story.append(PageBreak())
def tab(headers,data,widths):
 vals=[[p(esc(x),'CellX') for x in headers]]+[[p(esc(x),'CellX') for x in row] for row in data]
 widths=[w*737/sum(widths) for w in widths]
 t=Table(vals,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dcebe7')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,-1),.4,colors.HexColor('#ccd9d5')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f5f8f7')])]))
 story.append(t)
story.append(p('ENS ownership and migration','TitleX'));para('<b>Testing report | 23 October 2026</b>')
para('What existing V1 name holders can do in the new Manager and Explorer apps, and what is preserved when names move to V2.')
sub('Main conclusion')
para('<b>Full preservation of every wallet\'s permissions has not been demonstrated.</b> Several existing V1 tasks work through Explorer, sometimes with extra steps. Migration can keep a separate manager, but the tested grant only lets that wallet change the resolver. It does not automatically let the manager edit records on the new resolver.')
para('For unwrapped subnames controlled by a different wallet, the flow does not automatically recreate the parent holder and the separate manager with equivalent V2 permissions.')
tab(['Existing selected tests','Result'],[['Passed','41'],['Passed using a workaround','59'],['Failed','31'],['Total unique cases','131']],[335,155])
para('These counts describe the selected legacy cases. They are not a completion percentage for the full ownership, grace-period and migration matrix.')
para('<b>New after-migration execution:</b> '+str(len(after['rows']))+' matrix scenarios attempted. '+str(sum(r.get('v2Status')==2 for r in after['rows']))+' targets migrated; '+str(sum(isinstance(r.get('v2Status'),int) and r.get('v2Status')!=2 for r in after['rows']))+' targets did not migrate. Exact action outcomes appear in the matching five-column tables.')
sub('Scope and confidence')
para('DNS and the excluded stateful test suites are outside scope. This document combines earlier ownership evidence with new local record-preservation and after-migration action execution, reported separately. Results do not certify a deployed release or Sepolia.')
page();title('Reading the results')
para('The legacy app is the existing ENS V1 manager. The new apps are Manager and Explorer, which support V2 and retain workflows for existing V1 names.')
tab(['Term','Meaning in this report'],[
['Owner - unwrapped .eth name','The registration holder. May be a different wallet from the manager.'],['Manager - unwrapped name','The registry controller. Usually handles resolver and subname operations; record editing also depends on resolver permissions.'],['Parent owner - subname still controlled by its parent','The wallet controlling the parent. It may be the parent manager rather than the .eth registration owner.'],['Unwrapped subname','Has a registry controller but no separate registrar ownership token. Legacy labels must not be treated as two independent ownership slots.'],['Wrapped / emancipated','Wrapped names have fuse-based restrictions. An emancipated child is protected from parent control; its own holder matters.'],['Grace period','The period after registration expiry when renewal remains possible. Root expiry, child expiry and parent grace are different conditions.'],['Resolver / records','The resolver stores or serves information such as addresses and text. Permission to change the resolver does not itself grant permission to edit its records.'],['2LD / 3LD / 4LD','A .eth name, a child beneath it, and a child of that child.']],[142,348])
sub('Result labels')
para('<b>Pass:</b> the tested outcome succeeded, including expected denial. <b>Workaround:</b> the outcome needed another route or extra steps. <b>Fail:</b> the expected outcome was not completed. <b>Not tested:</b> no matching runtime proof is available.')
para('Most positive V1 workflows below were verified in Explorer. Manager-only availability is not separately certified for each row. A successful full transfer does not prove that owner and manager can be edited independently. New after-migration action results are scoped to their stated operations; they do not certify every permission or descendant workflow.')
page();title('Status key: test result and gap classification')
tab(['Test result','Meaning'],[
['PASS','The specific tested outcome succeeded, including an expected restriction.'],
['PASS WITH WORKAROUND','The tested outcome succeeded through a different route or extra steps.'],
['FAIL','A completed test attempt did not achieve its expected outcome. This alone does not establish the root cause.'],
['NOT VERIFIED','There is no sufficient matching runtime evidence. Do not read this as a product failure.'],['NOT MIGRATED','The target did not become a V2 name. This is a migration outcome; post-migration parity cannot be assumed.'],['BLOCKED','An attempted check could not finish because a prerequisite or test step failed.'],['N/A','The legacy operation has no direct V2 equivalent, such as syncing the V1 manager slot.']],[170,567])
sub('A separate classification explains the gap')
tab(['Gap classification','Meaning'],[
['CONFIRMED MISSING','A required control or permission grant is absent according to recorded UI inspection, code inspection or implementation confirmation. State which evidence supports it.'],
['OBSERVED FAILURE','The test failed, but missing functionality has not been established as its cause.'],
['NOT VERIFIED','The behaviour still needs a matching test. It may already work.'],
['NONE ESTABLISHED','No confirmed missing functionality is established by the evidence cited. This is not a full parity pass.']],[170,567])
para('A subname still controlled by its parent is one whose parent retains control over it. An emancipated subname is protected from parent control by its wrapper permissions. This distinction concerns control, not whether the name looks like a normal subname.')
# Compare like-for-like cases in landscape matrices.
for start in range(0,len(rows),7):
 page();title('Before migration: actions in the new apps')
 para('Scenarios '+str(start+1)+'-'+str(min(start+7,len(rows)))+' of 21. Results below describe Explorer. Manager is not separately certified for each scenario. Case IDs link outcomes to the test register.')
 data=[]
 for j in range(start,min(start+7,len(rows))):
  r=rows[j]
  cells=[]
  for k in range(1,5):
   ids=re.findall(r'L\d{3}',clean(r[k])); statuses=list(dict.fromkeys(by[i]['results']['v1']['status'].upper() for i in ids))
   result=' / '.join(statuses) if statuses else 'NOT VERIFIED'
   detail=clean(r[k]).replace('Tested outcome completed via Transfer / records; not an independent role editor','Adapted Transfer / records flow; independent editing not proved').replace('Legacy date/reminder requirements incomplete','Incomplete legacy dates/reminders').replace('Transfer completed via Explorer; adapted workflow','Adapted transfer completed')
   cells.append(result+' | '+detail)
  data.append([str(j+1)+'. '+clean(r[0])]+cells)
 tab(['Name type / connected wallet','Send / transfer','Edit roles / ETH record','Sync manager','Dates / renewal'],data,[155,135,180,117,150])
 para('Hidden as expected = verified restriction. An adapted flow can pass the original outcome without reproducing every legacy control. Owner-only means parent-owner-only for subname still controlled by its parents.')
# Exact before/after column layout; populated only from this run's saved action evidence.
def action_cell(r,key):
 c=r.get('checks',{}).get(key,{'status':'NOT RUN','detail':'No retained result.'})
 status=c['status']
 if key=='sync' and status=='N/A':return 'N/A | V2 has no V1 controller slot to sync. Role grants checked separately.'
 if key=='dates':return status+' | '+clean(c['detail'])
 if status=='PASS':
  if key=='send' and r['row']==3:return 'PASS | Expected denial: manager-only wallet cannot transfer registration ownership.'
  texts={'send':'Explorer transfer completed; new owner verified on chain.','edit':'Explorer ETH-record update verified through name resolution.','roles':'Explorer Set Resolver grant to another wallet verified on chain; audit grant cleaned up before transfer.'}
  return status+' | '+texts.get(key,c['detail'])+(' Former owner/parent-only wallet now has direct edit access; separate manager preservation is not proved.' if key=='edit' and r['row'] in [2,9,12,14,18,19] else '')
 return status+' | '+clean(c['detail'])[:155]+(' '+clean(c['error'])[:110] if c.get('error') else '')
for start in range(0,len(after['rows']),2):
 page();title('After migration: actions in the new apps')
 para('Same rows and action columns as before migration. Actual local execution; fixture indexer inventory, real UI writes and chain readbacks. DNS and legacy stateful suites excluded. PASS applies to the stated action, not the entire former manager permission bundle.')
 data=[]
 for r in after['rows'][start:start+2]:
  state=('Migrated with gas-limit workaround' if 'gas-limit' in r.get('migration','') else 'Migrated') if r.get('v2Status')==2 else 'Not migrated' if isinstance(r.get('v2Status'),int) else 'Migration blocked'
  data.append([str(r['row'])+'. '+r['scenario']+' | '+state,action_cell(r,'send'),'ETH: '+action_cell(r,'edit')+' Role grant: '+action_cell(r,'roles'),action_cell(r,'sync'),action_cell(r,'dates')])
 tab(['Name type / connected wallet','Send / transfer','Edit roles / ETH record','Sync manager','Dates / renewal'],data,[155,135,180,117,150])
 para('Role grant means Set Resolver only. Subnames do not require reminders. NOT MIGRATED is separate from action failure. Detailed evidence: After migration action results.html.')
page();title('After migration: execution scope and remaining limits')
para('Action counts: '+str(after['actionCounts'])+'. These count five subchecks per fixture (transfer, ETH edit, role grant, sync and dates); the report combines ETH and role grants in one column to match the before-migration layout. Runner success means evidence collection finished, not that every product check passed.')
para('Manager profile controls were inspected and its renewal entry was attempted. Most writes were executed in Explorer. Registry Set Resolver grants were submitted through Explorer and read back on chain; audit grants were then revoked directly on chain to isolate transfer. UI revocation is not claimed.')
para('The suite exercises the 21 existing matrix scenarios, including renewal-before-migration for grace roots and separate wallets for split ownership. It does not certify every resolver permission, child creation/deletion, every migration order, primary-name continuity, reminder delivery, or a real indexer/deployed build. Those are distinct checks, not silently converted into passes.')
para('Fixture correction: row 13 explicitly uses a wrapped child under an unwrapped parent with different holders. The extracted legacy sync fixture contradicted that scenario title. For emancipated children, the independent child holder is the connected actor; the historical row label must not imply that wallet also holds the parent.')
page();title('Key gaps and practical workarounds')
tab(['Finding','Observed outcome and practical consequence'],[
['FAIL - CONFIRMED MISSING: independent role edits (G05)','Full handover and reclaim-to-self work, but arbitrary owner-only or manager-only changes are not equivalent to these flows. Failed cases: L094, L174-L176.'],
['FAIL - CONFIRMED MISSING: child deletion controls (G02)','Parent-authorized deletion of a child still controlled by its parent passed. Child-holder-only deletion failed; emancipated child owners were also blocked. Failed cases: L040, L043, L045, L046, L192, L198.'],
['FAIL - CONFIRMED MISSING: parent controls (G17)','Expected parent actions to extend child expiry and remove parent control were missing. L193-L194.'],
['FAIL - CONFIRMED MISSING: dates/reminders (G20)','Legacy date/reminder requirements are incomplete. Some cases can use parent navigation or renewal routes; that does not restore every missing display.'],
['FAIL - OBSERVED FAILURE: grace editing (G22)','The original ETH-record update flow did not reach editor controls for unwrapped and wrapped grace fixtures. L101, L105.'],
['FAIL - CONFIRMED MISSING: unwrap entry (G16)','Expected unwrap entry points were missing for a live child whose parent is in grace. L303-L304.'],
['PASS WITH WORKAROUND: transfer options','Some ETH-address updates and profile resets require separate record-editing steps before transfer. L163, L166-L167, L169, L171-L172.'],
['WORKAROUND OBSERVED: stale displays (G10)','Some completed changes needed indexer catch-up and a reload after about 65 seconds in prior testing. A stale display should not be mistaken for proof that the transaction failed.']],[137,353])
sub('Access checks that did behave as expected')
para('Explorer showed Edit records for a manager-only wallet (L229), while owner-only access was hidden and direct editor access blocked (L230). These checks establish access boundaries, not successful saves for every record type. Parent-only deletion of an emancipated child was correctly denied (L044).')
page();title('Migration summary: preserved powers and gaps')
tab(['Situation','Current behaviour','Gap / workaround'],[
['Separate owner and manager','Owner initiates. Keep manager is optional and off by default. Opt-in grants registry Set Resolver only.','Record-writing on the new resolver, child management and delegation are not restored as an equivalent bundle.'],
['Manager cannot edit migrated profile','Registry permission to replace a resolver does not confer record-writing permission on it.','Empty-profile recovery was verified through Explorer resolver replacement, then Manager editing. Existing populated profiles were not covered by this workaround.'],
['Same-wallet dependent children','Eligible children can be copied through a complete parent migration route; copied child belongs to the migrating wallet.','Executed transfer, ETH-edit and Set Resolver delegation results are in the matching after-migration rows. These operations do not certify every legacy permission.'],
['Different parent and child controllers','Automatic reconstruction of an unwrapped child with equivalent roles for both wallets is missing.','Independently emancipated / locked children have separate restriction-sensitive paths and must be tested separately.'],
['Grace period','Tested route renews the name first, then migrates.','Every split-wallet and descendant combination is not covered.'],
['Affected-subname warnings','Newer inspected code adds warning, acknowledgement and Explorer recreation guidance.','Warnings do not restore permissions; deletion wording alone does not prove physical removal of old-chain state.']],[150,285,302])
# Actual record-preservation execution, separate from the older 131-case ledger.
record_path=R/'execution/record-preservation/results-summary.json'
if record_path.exists():
 executed=json.loads(record_path.read_text())
 page();title('Record preservation: actual execution results')
 para('<b>Local execution on 23 October 2026.</b> The app performed migration transactions on the fork. Every seeded value was resolved through the UniversalResolver before migration and compared afterwards. Names and record keys came from a fixture inventory. Grace fixtures were populated and read while active, then advanced into grace for renewal and migration. DNS and legacy stateful suites were excluded.')
 para('<b>Executed test cases: 17 - 5 PASS, 12 FAIL.</b> Expected failures in the runner are counted as product failures here. No tested record mismatch is converted to a pass.')
 para('<b>Name outcomes:</b> '+esc(', '.join(str(v)+' '+k for k,v in executed['nameResults'].items()))+'. <b>Individual record comparisons:</b> '+esc(', '.join(str(v)+' '+k for k,v in executed['recordResults'].items()))+'. These counts are additional to the 131 legacy cases, not replacements for them.')
 tab(['Finding','Actual evidence / interpretation'],[
 ['FAIL: public-key and interface records','Public keys (cryptographic keys) and interface records (addresses implementing a contract interface) stopped resolving on completed migrations. Other populated record types can pass for the same name; the all-records result still fails. See per-name results below.'],
 ['FAIL: descendant resolution','In emancipated-child, separate-child-holder, wrapped-child-under-unwrapped-parent and grace-renewal scenarios, some descendants were not migrated. Their seeded records no longer resolved after ancestor migration. This is a resolution-path failure, not proof that the old stored bytes were deleted.'],
 ['FAIL: stale record inventory','A deliberate stale-key test migrated a name while omitting its existing text/address keys from discovery. The post-migration reads lost those values. This proves the response to that supplied fault, not how often the real indexer enters it.'],
 ['Harness correction','The original mock omitted contenthash and ABI types from resolver inventory. That run was excluded from final results. Corrected runs advertise those fields consistently; a separate deliberate stale-inventory test remains.'],
 ['NOT VERIFIED: real indexer and UI','The real indexer was stopped with a chain-history mismatch. These results do not certify record discovery by it, or complete record rendering in Manager and Explorer.'],
 ['Evidence','Exact names, before/after values, chain blocks and statuses: Record preservation results.html and results-summary.json in execution/record-preservation.']],[175,562])
 entries=executed['names']
 for start in range(0,len(entries),7):
  page();title('Executed record comparisons: names '+str(start+1)+'-'+str(min(start+7,len(entries))))
  para('PASS requires every tested record to match. NOT MIGRATED identifies a name outside the completed V2 migration; its resolution outcome is still reported. Fixture IDs identify the exact names in the companion HTML evidence.')
  table_rows=[]
  for item in entries[start:start+7]:
   rec=item['records'];passed=sum(r['result']=='PASS' for r in rec);failed=[r['record'] for r in rec if r['result']=='FAIL']
   label=item['id']+' / '+(['.eth name','child','grandchild'][item.get('depth',0)] if item['id']!='TYPE' else item['scenario'])
   context=item['scenario'] if item['id']!='TYPE' else 'Focused record-format check'
   verdict=item['result']+('; resolution '+str(item.get('resolutionResult')) if item['result']=='NOT MIGRATED' else '')
   table_rows.append([label,context,verdict,str(passed)+' / '+str(len(rec)),', '.join(failed) if failed else 'Empty-profile control' if not rec and item['result']=='PASS' else 'None in completed comparisons' if rec and passed==len(rec) else 'Comparison incomplete'])
  tab(['Fixture / name level','Name state or check','Result','Records matching','Records that did not match'],table_rows,[135,190,110,80,222])
 para('The root, child and grandchild are checked independently. The tested inventory covers fixed seeded records; this is not a claim that all possible custom resolvers, off-chain records, wildcard behaviour or reverse records are covered.')
if record_path.exists():
 page();title('Focused record-format tests: actual results')
 para('These tests complement the per-name tree matrix. An assertion marked as an expected failure in the runner is still reported here as a product FAIL when it fails. Incomplete runs are not converted into passes.')
 tab(['Test','Actual result'],[[t['title'],t['result']] for t in executed.get('testRuns',[]) if t['source']=='root-records-corrected.json'],[590,147])
page();title('Record preservation: a separate migration acceptance gate')
para('<b>Acceptance criteria and remaining scope.</b> Actual execution results appear in the preceding tables. Complete preservation cannot pass while the reproduced record and descendant-resolution failures remain. Broader resolver discovery and display coverage is still not verified.')
tab(['Check for every name and descendant','Required comparison / evidence','Current coverage'],[
['Capture the complete baseline','Before migration, save each known record key, type and value, the resolver, chain, block and name. Use fixture definitions plus available history/inventory; a UI list alone cannot prove completeness.','Seeded fixture baselines executed; real-indexer completeness NOT VERIFIED.'],
['Compare actual resolved values','After migration, resolve the same name and record keys through the supported public resolution path. Compare addresses as bytes, text exactly and binary records by their encoded values. A successful old-resolver read is insufficient.','Seeded comparisons executed; see actual per-name PASS/FAIL results.'],
['Keep records reachable','Check root, child and grandchild names after parent migration and after each supported migration order. Records left on an old resolver but unreachable through the name do not pass preservation.','Executed cases include descendant-resolution failures; other intersections remain NOT VERIFIED.'],
['Check both app displays','Manager and Explorer must load and show the retained records without losing fields or failing the whole records page. Distinguish an indexing/display delay from changed resolved values.','Full record-type matrix NOT VERIFIED.'],
['Check permission repairs','Re-run the same comparison after resolver replacement or role recovery. An empty-profile recovery test cannot establish preservation of populated profiles.','Populated-profile recovery NOT VERIFIED.'],
['Keep unrelated values unchanged','When separately testing an authorized edit, change one chosen record and compare all the others. Verify the previous manager and unrelated wallet cannot silently overwrite records.','Requires dedicated authorized state-changing checks; excluded suites remain excluded.']],[177,390,170])
page();title('Record checklist and precise pass / fail rules')
tab(['Record or condition','What must survive'],[
['ETH and other chain addresses','Every populated coin-type address, including records absent from the app display. Do not check only the main ETH address.'],
['Text records','All standard and custom keys, including profile, URL, email, avatar and social records when present. Retain exact values and distinguish missing from intentionally empty values.'],
['Content hash','The complete stored content identifier, not just the displayed link.'],
['ABI records','Every stored content type used by the fixture; retain content and successful resolution. Include the legacy JSON-object case. Stored bytes, resolved values and editor acceptance are separate assertions.'],
['Other resolver capabilities','Public keys, supported custom records, wildcard/inherited resolution and off-chain records where present. Record unsupported cases explicitly; do not silently omit them.'],
['Primary name / reverse lookup','Check separately from forward records: the wallet still resolves to the intended primary name and forward verification succeeds where required. Ownership alone does not prove this.'],
['Name state and wallet combinations','Repeat for active names, grace names after renewal, wrapped/unwrapped names, children and grandchildren, and same-wallet / split-wallet ownership. DNS stays excluded.']],[190,547])
sub('Two results per name - never a single ambiguous missing label')
para('<b>Record preservation:</b> PASS only when the captured inventory is complete for that test fixture and every required value still resolves. FAIL when a previously resolving record disappears, changes unexpectedly or becomes unreachable. NOT VERIFIED when the baseline or comparison is incomplete. A read error is a failed resolution check, not proof that stored data was deleted.')
para('<b>App display:</b> record PASS, PASS WITH WORKAROUND, FAIL or NOT VERIFIED independently. Required evidence per record: name, key/type, before value, after value, resolution result, display result, evidence location and any workaround. A changed resolver address is acceptable only if the required records remain correctly resolvable.')
page();title('Remaining tests before claiming full parity')
tab(['Scenario','Checks still needed'],[
['Grace .eth names','Test owner-only, manager-only and combined roles separately: renewal, restrictions, records and post-migration actions.'],['Children and grandchildren still controlled by their parent','Vary parent holder, child controller and grandchild controller. Include parent grace and separate child expiry.'],['Wrapped parent-controlled children','Test parent-only, child-only and same-wallet cases with wrapped/unwrapped parents and relevant fuse restrictions.'],['Emancipated children','Test child-only owner and parent-only denial, plus migration order and independent expiry where supported.'],['Split root and descendants','Use four wallets: root owner, root manager, child controller, grandchild controller. The root manager may be the effective parent controller.'],['Retained manager after migration','Perform actual record writes, child creation, transfers, delegation and revocation. Verify denied actions as well as permitted ones.'],['Record preservation for every migrated name','Capture and compare the complete known record inventory before/after migration and resolver recovery, through actual resolution and both app displays. See the record-preservation tables.'],['Both apps','Record Available, Hidden, Disabled, Redirect, Error or Workaround independently in Manager and Explorer.']],[151,339])
sub('Acceptance rule')
para('A preservation result should pass only when the same wallet can complete every required allowed action after migration, still cannot perform prohibited actions, and the expected records and descendants remain usable. Ownership labels or a successful migration transaction alone are insufficient.')
sub('Launch interpretation')
para('This evidence identifies concrete gaps and useful working routes. It does not support signing off complete legacy ownership parity or complete permission preservation. Product decisions are needed for intentional differences; remaining behaviours need direct tests.')
page();title('Evidence, dates and limitations')
para('The ownership screenshot supplied for the audit is the legacy reference, excluding its DNS columns. The 131-case register that follows is drawn from the existing parity ledger and ownership report.')
tab(['Evidence','Scope'],[
['Legacy browser execution','Collected around 21-22 October 2026 on the local parity checkout. The record-preservation section adds a separate local execution run.'],['Focused migration unit tests','168 passed on 23 October. These test decision logic and transaction planning, not every wallet\'s browser experience.'],['Legacy permission unit cases','73 passed; two TODO cases remain for unwrapped child-holder / parent-holder combinations.'],['Migration runtime evidence','Original batch had mixed results. Isolated grace rechecks passed seven checks; wrapped-manager and retained-manager recovery had targeted rechecks. These do not make the whole batch a pass.'],['Code snapshots','Parity checkout: e64a94a1a. Legacy app: 6d87a2be9475. Newer locally available main: 481417a8a. Remote refresh failed; this is not a claim about the latest deployed release.'],['Coverage location','Expanded manager, grace and subname end-to-end checks exist on the coverage checkout; not all were present in the inspected main snapshot.'],['Excluded evidence','DNS and excluded stateful suites. The separate manual ABI fixture inventory is not permission-matrix evidence.']],[151,339])
sub('How to trace a result')
para('L-prefixed identifiers refer to original legacy cases. G-prefixed identifiers refer to findings in the replacement-readiness report. The following register preserves original test descriptions and recorded outcomes; a description such as Edit Roles may represent an adapted transfer flow rather than an independent role editor.')
para('Supporting source files: V1 ownership test report.html; parity-ledger.json; Roles and migration audit.html; roles-audit-unit-results.json; roles-audit-legacy-unit-results.json; fullhistory-migration.json; fullhistory-migration-grace-isolated.json; fullhistory-migration-selection-recheck.json; fullhistory-parity-recheck.json. These are retained in the local replacement-readiness report folder. This PDF states the conclusions without requiring those files to be opened.')
page();title('Failed records: how to interpret name survival')
para('Evidence correction: earlier conversational statements that old resolver records were confirmed intact are withdrawn. Saved direct reads returned errors. This report distinguishes lost resolution from proven storage deletion, ownership loss and permanent name loss; the latter three are NOT established.')
para('The following tables cover every failed name outcome, including descendants not migrated. Before/after values and chain blocks are retained in Record preservation results.html and results-summary.json. DNS and legacy stateful suites remain excluded. No new chain tests were run for this reporting expansion.')
failures=[r for r in json.loads((R/'execution/record-preservation/results-summary.json').read_text())['names'] if 'failureBreakdown' in r]
for r in failures:
 page();title(r['id']+' - individual failed-name breakdown')
 para(r['name']);para(r['scenario'])
 tab(['Question','Observed result / evidence limit'],list(r['failureBreakdown'].items()),[125,365])
 para('Evidence: '+r['evidence']+'. Before block '+str(r.get('beforeBlock'))+'; after block '+str(r.get('afterBlock'))+'. Exact record values are available in the accompanying HTML report.')
page();title('Appendix: legacy case register')
para('131 selected unique cases. Results use full status labels. These are legacy outcome results, not full post-migration preservation results. Scenario-level context and workarounds are explained in the preceding pages.')
data=[]
for id in selected:
 c=by[id];r=c['results']['v1'];status=r['status'].upper()
 data.append([id,status,c['legacy_title']])
tab(['Case','Result','Original test description'],data,[47,110,333])
out=Path('/Users/sg/Documents/ChatGPT/ENS/tmp/pdfs/after-preview.pdf')
def footer(c,doc):
 c.setStrokeColor(colors.HexColor('#ccd9d5'));c.line(42,35,800,35);c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#526762'));c.drawString(42,23,'ENS | Ownership and migration testing | 23 October 2026');c.drawRightString(800,23,str(doc.page))
doc=SimpleDocTemplate(str(out),pagesize=(841.89,595.28),rightMargin=52,leftMargin=52,topMargin=32,bottomMargin=48,title='ENS ownership and migration test report',author='ENS testing report')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(out)
