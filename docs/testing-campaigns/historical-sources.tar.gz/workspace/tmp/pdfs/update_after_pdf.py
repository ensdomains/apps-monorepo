from pathlib import Path
p=Path('tmp/pdfs/build_report.py');s=p.read_text();start=s.index('for start in range(0,len(rows),5):');end=s.index("page();title('Key gaps and practical workarounds')",start)
block='''# Exact before/after column layout; populated only from this run's saved action evidence.
after=json.loads((R/'execution/after-migration/summary.json').read_text())
def action_cell(r,key):
 c=r.get('checks',{}).get(key,{'status':'NOT RUN','detail':'No retained result.'})
 status=c['status']
 if key=='sync' and status=='N/A':return 'N/A | V2 has no V1 controller slot to sync. Role grants checked separately.'
 if key=='dates':return status+' | Legacy reminder control absent on Explorer ownership page. Manager renewal entry: '+('opened' if r.get('observations',{}).get('managerRenewOpened') else 'not reached')+'. No renewal transaction claimed.'
 if status=='PASS':
  texts={'send':'Explorer transfer verified by chain owner readback; manager-only case passes expected denial.','edit':'Explorer ETH-record update verified through name resolution.','roles':'Explorer Set Resolver grant to another wallet verified on chain; audit grant cleaned up before transfer.'}
  return status+' | '+texts.get(key,c['detail'])
 return status+' | '+clean(c['detail'])[:155]+(' '+clean(c['error'])[:110] if c.get('error') else '')
for start in range(0,len(after['rows']),4):
 page();title('After migration: actions in the new apps')
 para('Same rows and action columns as before migration. Actual local execution; fixture indexer inventory, real UI writes and chain readbacks. DNS and legacy stateful suites excluded. PASS applies to the stated action, not the entire former manager permission bundle.')
 data=[]
 for r in after['rows'][start:start+4]:
  state='Migrated' if r.get('v2Status')==2 else 'Not migrated' if isinstance(r.get('v2Status'),int) else 'Migration blocked'
  data.append([str(r['row'])+'. '+r['scenario']+' | '+state,action_cell(r,'send'),'ETH: '+action_cell(r,'edit')+' Role grant: '+action_cell(r,'roles'),action_cell(r,'sync'),action_cell(r,'dates')])
 tab(['Name type / connected wallet','Send / transfer','Edit roles / ETH record','Sync manager','Dates / renewal'],data,[155,135,180,117,150])
 para('BLOCKED is a test/infrastructure prerequisite failure, not a product FAIL. Role-grant PASS is Set Resolver delegation, not proof of full V1 manager restoration. Dates FAIL is incomplete legacy UI parity; Manager may supply the renewal route. Detailed screenshots, exact fixtures, readbacks and transaction logs: after-migration/After migration action results.html.')
page();title('After migration: execution scope and remaining limits')
para('Action counts: '+str(after['actionCounts'])+'. These count five subchecks per fixture (transfer, ETH edit, role grant, sync and dates); the report combines ETH and role grants in one column to match the before-migration layout. Runner success means evidence collection finished, not that every product check passed.')
para('Manager profile controls were inspected and its renewal entry was attempted. Most writes were executed in Explorer. Registry Set Resolver grants were submitted through Explorer and read back on chain; audit grants were then revoked directly on chain to isolate transfer. UI revocation is not claimed.')
para('The suite exercises the 21 existing matrix scenarios, including renewal-before-migration for grace roots and separate wallets for split ownership. It does not certify every resolver permission, child creation/deletion, every migration order, primary-name continuity, reminder delivery, or a real indexer/deployed build. Those are distinct checks, not silently converted into passes.')
para('Fixture correction: row 13 explicitly uses a wrapped child under an unwrapped parent with different holders. The extracted legacy sync fixture contradicted that scenario title. For emancipated children, the independent child holder is the connected actor; the historical row label must not imply that wallet also holds the parent.')
'''
s=s[:start]+block+s[end:]
s=s.replace('No migration scenario below is a complete per-wallet, per-action preservation pass.','New after-migration action results are scoped to their stated operations; they do not certify every permission or descendant workflow.')
s=s.replace('This document combines earlier ownership evidence with new local record-preservation execution, reported separately.','This document combines earlier ownership evidence with new local record-preservation and after-migration action execution, reported separately.')
p.write_text(s)
