from pathlib import Path
p=Path('tmp/pdfs/build_report.py');s=p.read_text()
s=s.replace("t=Table(vals,colWidths=widths", "widths=[w*737/sum(widths) for w in widths]\n t=Table(vals,colWidths=widths")
a=s.index('# Two scenarios per page');b=s.index("page();title('Key gaps",a)
s=s[:a]+'''# Compare like-for-like cases in landscape matrices.
for start in range(0,len(rows),5):
 page();title('Before migration: actions in the new apps')
 para('Scenarios '+str(start+1)+'-'+str(min(start+5,len(rows)))+' of 21. Results below describe Explorer. Manager is not separately certified for each scenario. Case IDs link outcomes to the test register.')
 data=[]
 for j in range(start,min(start+5,len(rows))):
  r=rows[j]
  data.append([str(j+1)+'. '+clean(r[0])]+[clean(r[k]).replace('Tested outcome completed via Transfer / records; not an independent role editor','Completed via Transfer / records; independent editing not proved').replace('Legacy date/reminder requirements incomplete','Incomplete legacy dates/reminders').replace('Transfer completed via Explorer; adapted workflow','Completed through adapted transfer flow') for k in range(1,5)])
 tab(['Name type / connected wallet','Send / transfer','Edit roles / ETH record','Sync manager','Dates / renewal'],data,[155,135,180,117,150])
 para('Hidden as expected = verified restriction. An adapted flow can pass the original outcome without reproducing every legacy control. Owner-only means parent-owner-only for ordinary subnames.')
for start in range(0,len(rows),4):
 page();title('After migration: what each wallet retains')
 para('Scenarios '+str(start+1)+'-'+str(min(start+4,len(rows)))+' of 21. No row is a full permission-preservation pass. Existing proof is limited to the completed related tests.')
 tab(['Name type / connected wallet','Migration path','What existing tests establish','Missing or unverified'],[[str(j+1)+'. '+clean(migrations[j][0])]+[clean(migrations[j][k]) for k in range(1,4)] for j in range(start,min(start+4,len(rows)))],[151,175,190,221])
''' +s[b:]
a=s.index("page();title('What migration preserves");b=s.index("page();title('Remaining tests",a)
s=s[:a]+'''page();title('Migration summary: preserved powers and gaps')
tab(['Situation','Current behaviour','Gap / workaround'],[
['Separate owner and manager','Owner initiates. Keep manager is optional and off by default. Opt-in grants registry Set Resolver only.','Record-writing on the new resolver, child management and delegation are not restored as an equivalent bundle.'],
['Manager cannot edit migrated profile','Registry permission to replace a resolver does not confer record-writing permission on it.','Empty-profile recovery was verified through Explorer resolver replacement, then Manager editing. Existing populated profiles were not covered by this workaround.'],
['Same-wallet dependent children','Eligible children can be copied through a complete parent migration route; copied child belongs to the migrating wallet.','This does not recreate a separate manager. Full per-action preservation remains unverified.'],
['Different parent and child controllers','Automatic reconstruction of an unwrapped child with equivalent roles for both wallets is missing.','Independently emancipated / locked children have separate restriction-sensitive paths and must be tested separately.'],
['Grace period','Tested route renews the name first, then migrates.','Every split-wallet and descendant combination is not covered.'],
['Affected-subname warnings','Newer inspected code adds warning, acknowledgement and Explorer recreation guidance.','Warnings do not restore permissions; deletion wording alone does not prove physical removal of old-chain state.']],[150,285,302])
''' +s[b:]
s=s.replace("c.line(42,42,553,42)","c.line(42,35,800,35)").replace("c.drawString(42,29", "c.drawString(42,23").replace("c.drawRightString(553,29", "c.drawRightString(800,23")
s=s.replace("pagesize=(595.28,841.89)","pagesize=(841.89,595.28)").replace('topMargin=43,bottomMargin=57','topMargin=32,bottomMargin=48')
p.write_text(s)
