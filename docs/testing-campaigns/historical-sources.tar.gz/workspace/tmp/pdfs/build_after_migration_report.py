import json,html,re,collections
from pathlib import Path
D=Path('/Users/sg/Documents/ChatGPT/ENS/replacement-readiness/execution/after-migration'); E=D.parent
rows=[json.loads(p.read_text()) for p in sorted(D.glob('AM[0-9][0-9].json'))]
date_checks={r['row']:r for r in json.loads((D/'dates-recheck.json').read_text())} if (D/'dates-recheck.json').exists() else {}
groups=[(85,88),(89,92),(93,95),(96,98),(99,102),(103,106),(107,110),(111,114),(115,118),(119,122),(123,126),(127,130),(131,134),(135,136),(137,140),(141,144),(145,148),(149,152),(153,154),(155,158),(159,162)]
for r in rows:
 start,end=groups[r['row']-1];r['legacyCaseIds']=[f'L{i:03}' for i in range(start,end+1)]
 if r['row'] in [15,21]:
  r['legacyScenario']=r['scenario'];r['scenario']='Emancipated '+('3LD - Child owner; parent held by another wallet' if r['row']==15 else '4LD - Grandchild owner; ancestors held by another wallet')
 role_text=D/f"AM{r['row']:02}-roles.txt"
 if role_text.exists() and 'Only 2LD and 3LD .eth names are supported' in role_text.read_text() and r.get('checks',{}).get('roles',{}).get('status')=='FAIL':
  r['checks']['roles']['detail']='Explorer Roles page rejects the grandchild: Only 2LD and 3LD .eth names are supported. Registry role grant could not be performed.'
 if r['row'] in date_checks:
  r['dateFollowup']=date_checks[r['row']]
  r.setdefault('checks',{})['dates']={'status':date_checks[r['row']]['status'],'detail':date_checks[r['row']].get('detail','No detail retained')}
 if r['row'] in [2,9,12,14,18,19] and r.get('checks',{}).get('edit',{}).get('status')=='PASS':
  r['checks']['edit']['detail']+=' Direct edit access is now observed for the former owner-only/parent-only wallet; this is a capability change, not proof of the former separate manager retaining rights.'
 # Missing V2 target is a migration outcome, not a failed V2 sync operation.
 if isinstance(r.get('v2Status'),int) and r['v2Status']!=2:
  r['checks']['sync']={'status':'NOT MIGRATED','detail':'No V2 target. The absence of a V1 sync button is not independently counted as a product failure.'}
  if r['row'] in [14,19]:
   for k in ['send','edit','roles']:
    if r['checks'].get(k,{}).get('status')=='FAIL':r['checks'][k]={'status':'NOT MIGRATED','detail':'Legacy parent-only action was restricted. UI denial was observed, but no V2 target exists; this cannot establish post-migration permission preservation.'}
 for k in ['send','edit','roles','sync','dates']:
  if k not in r.setdefault('checks',{}):r['checks'][k]={'status':'BLOCKED' if r.get('error') else 'NOT RUN','detail':'Migration prerequisite failed: '+r.get('error','No evidence retained')}
e=html.escape
def val(r,k):
 c=r.get('checks',{}).get(k,{'status':'NOT RUN','detail':'No result retained.'})
 return c['status']+' - '+c['detail']+((' Error: '+c['error']) if c.get('error') else '')
def migration(r):return (('Migrated with gas-limit workaround' if 'gas-limit' in r.get('migration','') else 'Migrated') if r.get('v2Status')==2 else 'Not migrated' if isinstance(r.get('v2Status'),int) else 'Migration blocked / not verified')
matrix=[]
for r in rows:
 matrix.append([str(r['row'])+'. '+r['scenario']+' | '+r['legacyCaseIds'][0]+'–'+r['legacyCaseIds'][-1]+' | '+migration(r),val(r,'send'),'ETH: '+val(r,'edit')+' Role grant: '+val(r,'roles'),val(r,'sync'),val(r,'dates')])
counts=collections.Counter(c['status'] for r in rows for k,c in r.get('checks',{}).items() if k in ['send','edit','roles','sync','dates'])
summary={'scope':'Local fork, fixture indexer inventory, actual UI operations and chain readback. DNS and excluded legacy stateful suites not run.','nameCount':len(rows),'migrationCounts':{'migrated':sum(r.get('v2Status')==2 for r in rows),'notMigrated':sum(isinstance(r.get('v2Status'),int) and r.get('v2Status')!=2 for r in rows),'blocked':sum(not isinstance(r.get('v2Status'),int) for r in rows)},'actionCounts':dict(counts),'rows':rows,'matrix':matrix}
(D/'summary.json').write_text(json.dumps(summary,indent=2))
headers=['Name type / connected wallet','Send / transfer','Edit roles / ETH record','Sync manager','Dates / renewal']
def table(h,rs):return '<table><thead><tr>'+''.join('<th>'+e(x)+'</th>' for x in h)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+e(str(x))+'</td>' for x in row)+'</tr>' for row in rs)+'</tbody></table>'
intro='<p><strong>'+str(len(rows))+' scenarios; '+str(sum(r.get('v2Status')==2 for r in rows))+' targets migrated.</strong> Five action subchecks per scenario: '+e(', '.join(str(n)+' '+k for k,n in counts.items()))+'.</p><p>Executed action checks use the same scenario rows and columns as the before-migration report. PASS is scoped to the operation stated in the cell. Successful new access is identified separately; PASS does not mean every legacy permission restriction is unchanged. BLOCKED is not a product failure. N/A means the V1 controller slot no longer exists in V2. A Set Resolver grant is not the full legacy manager permission bundle.</p><p>'+e(summary['scope'])+'</p><p>Most transaction actions were exercised in Explorer. Manager profile controls and its renewal route were checked separately. UI role revocation, every resolver role, child creation/deletion and complete owner/manager equivalence are not certified by these four columns. Temporary role grants are cleaned up on chain before testing transfer; that cleanup is not counted as a UI revoke pass.</p><p>Dates/renewal is checked against each name type: reminders are expected for roots, not subnames. V2 child expiry is checked on chain; parent expiry can be reached by parent navigation. Cells distinguish the Manager renewal route. No reminder-delivery or renewal transaction is claimed. Historical registration timestamps are not certified by fixture inventory.</p>'
body='<h1>After migration: actual action results</h1>'+intro+table(headers,matrix)
for r in rows:
 id=f"AM{r['row']:02}"
 body+='<section id="'+id+'"><h2>'+e(id+' '+r['scenario'])+'</h2><p>'+e(r.get('name','Fixture not created'))+' | '+e(migration(r))+'</p>'
 body+=table(['Check','Actual result'],[[k,val(r,k)] for k in ['manager','send','edit','roles','sync','dates']])
 if r.get('error'):body+='<p>Prerequisite error: '+e(r['error'])+'</p>'
 body+='<p><a href="'+id+'.json">Raw evidence</a></p><details><summary>Fixture, chain readbacks and transaction log</summary><pre>'+e(json.dumps(r,indent=2))+'</pre></details></section>'
page='<!doctype html><html><head><meta charset="utf-8"><title>After migration action results</title><style>body{font:15px/1.5 system-ui;margin:28px;color:#19392f}table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:12px;border:1px solid #ccd9d5;vertical-align:top;text-align:left}th{background:#e5efea}pre{white-space:pre-wrap;overflow-wrap:anywhere}section{margin-top:32px}</style></head><body>'+body+'</body></html>'
(D/'After migration action results.html').write_text(page)
p=E/'V1 ownership test report.html';s=p.read_text()
section='<section id="after"><h2>2. After migration: actions in the new apps</h2>'+intro+table(headers,matrix)+'<p><a href="after-migration/After migration action results.html">Individual action evidence and screenshots</a></p></section>'
s,n=re.subn(r'<section id="after">.*?</section>',lambda _:section,s,count=1,flags=re.S)
assert n==1
s=s.replace('This reorganizes existing execution evidence; it is not a new browser test run.','The before-migration section uses existing evidence; the after-migration section includes a new local action run.')
s=s.replace('These cells stay <strong>Not tested</strong> until executed.', 'This earlier checklist includes broader combinations beyond the executed action matrix above; use the exact action results above for completed coverage.')
p.write_text(s)
ledger=E.parent/'parity-ledger.json';d=json.loads(ledger.read_text());d.setdefault('execution',{})['after_migration_actions']={'report':'execution/after-migration/After migration action results.html','summary':'execution/after-migration/summary.json','scope':summary['scope'],'actionCounts':dict(counts)};ledger.write_text(json.dumps(d,indent=2))
print(json.dumps({'rows':len(rows),'counts':dict(counts)}))
