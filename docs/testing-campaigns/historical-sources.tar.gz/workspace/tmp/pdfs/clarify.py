from pathlib import Path
p=Path('tmp/pdfs/build_report.py');s=p.read_text()
s=s.replace('ordinary subname','subname still controlled by its parent').replace('Ordinary children and grandchildren','Children and grandchildren still controlled by their parent').replace('Ordinary parent-authorized deletion','Parent-authorized deletion of a child still controlled by its parent')
a=s.index('# Compare like-for-like')
s=s[:a]+'''page();title('Status key: test result and gap classification')
tab(['Test result','Meaning'],[
['PASS','The specific tested outcome succeeded, including an expected restriction.'],
['PASS WITH WORKAROUND','The tested outcome succeeded through a different route or extra steps.'],
['FAIL','A completed test attempt did not achieve its expected outcome. This alone does not establish the root cause.'],
['NOT VERIFIED','There is no sufficient matching runtime evidence. Do not read this as a product failure.']],[170,567])
sub('A separate classification explains the gap')
tab(['Gap classification','Meaning'],[
['CONFIRMED MISSING','A required control or permission grant is absent according to recorded UI inspection, code inspection or implementation confirmation. State which evidence supports it.'],
['OBSERVED FAILURE','The test failed, but missing functionality has not been established as its cause.'],
['NOT VERIFIED','The behaviour still needs a matching test. It may already work.'],
['NONE ESTABLISHED','No confirmed missing functionality is established by the evidence cited. This is not a full parity pass.']],[170,567])
para('A subname still controlled by its parent is one whose parent retains control over it. An emancipated subname is protected from parent control by its wrapper permissions. This distinction concerns control, not whether the name looks like a normal subname.')
''' +s[a:]
a=s.index("  data.append([str(j+1)+'. '+clean(r[0])]");b=s.index("\n tab(['Name type",a)
s=s[:a]+'''  cells=[]
  for k in range(1,5):
   ids=re.findall(r'L\\d{3}',clean(r[k])); statuses=list(dict.fromkeys(by[i]['results']['v1']['status'].upper() for i in ids))
   result=' / '.join(statuses) if statuses else 'NOT VERIFIED'
   detail=clean(r[k]).replace('Tested outcome completed via Transfer / records; not an independent role editor','Adapted Transfer / records flow; independent editing not proved').replace('Legacy date/reminder requirements incomplete','Incomplete legacy dates/reminders').replace('Transfer completed via Explorer; adapted workflow','Adapted transfer completed')
   cells.append(result+' | '+detail)
  data.append([str(j+1)+'. '+clean(r[0])]+cells)''' +s[b:]
a=s.index('for start in range(0,len(rows),7):',s.index("para('Hidden as expected"));b=s.index("page();title('Key gaps",a)
s=s[:a]+'''for start in range(0,len(rows),5):
 page();title('After migration: result, confirmed gaps and open tests')
 para('Scenarios '+str(start+1)+'-'+str(min(start+5,len(rows)))+' of 21. Result refers to full permission preservation for that scenario. A confirmed implementation gap is identified separately from a failed browser test.')
 data=[]
 for j in range(start,min(start+5,len(rows))):
  m=migrations[j];result='NOT VERIFIED';missing='NONE ESTABLISHED by the cited evidence.'
  if j in [1,2]:
   result='FAIL for retained-manager record editing; full action set NOT VERIFIED'
   missing='CONFIRMED MISSING: automatic record-write grant on the new resolver. Implementation confirmation + retained-manager runtime check; Set Resolver only is granted.'
  elif j in [7,8,16,17,18,19]:
   missing='CONFIRMED MISSING: automatic recreation of an unwrapped child with separate parent-holder and equivalent manager roles. Implementation confirmation; no exact per-row browser preservation check.'
  pending='All actions and restrictions for this exact wallet/name combination after migration.'
  if j in [1,2]:pending='Child creation, delegation and revocation per wallet; populated-record preservation during resolver recovery.'
  elif j in [4,5]:pending='Separate owner-only, manager-only and combined-role checks through grace, renewal and migration.'
  elif j in [10,11,12,13]:pending='Exact split-wallet wrapped-child behaviour, fuse restrictions and post-migration rights. Do not infer missing support from exclusion of a different fixture.'
  data.append([str(j+1)+'. '+clean(m[0]),result,missing,pending,clean(m[2])])
 tab(['Name / wallet','Test result','Confirmed missing functionality','Not verified - tests still needed','Existing evidence (limited)'],data,[142,110,185,160,140])
''' +s[b:]
# Make the appendix readable without single-letter result codes.
s=s.replace("P = Pass; W = Pass with workaround; F = Fail.","Results use full status labels.")
s=s.replace("status={'Pass':'P','Pass with workaround':'W','Fail':'F'}[r['status']]","status=r['status'].upper()")
s=s.replace("data,[47,45,398]","data,[47,110,333]")
# Tag findings without pretending each failure proves missing implementation.
s=s.replace("['Independent role edits (G05)'","['FAIL - CONFIRMED MISSING: independent role edits (G05)'")
s=s.replace("['Child deletion (G02)'","['FAIL - CONFIRMED MISSING: child deletion controls (G02)'")
s=s.replace("['Parent controls (G17)'","['FAIL - CONFIRMED MISSING: parent controls (G17)'")
s=s.replace("['Dates and reminders (G20)'","['FAIL - CONFIRMED MISSING: dates/reminders (G20)'")
s=s.replace("['Grace record editing (G22)'","['FAIL - OBSERVED FAILURE: grace editing (G22)'")
s=s.replace("['Child unwrap during parent grace (G16)'","['FAIL - CONFIRMED MISSING: unwrap entry (G16)'")
s=s.replace("['Transfer options'","['PASS WITH WORKAROUND: transfer options'")
s=s.replace("['Stale displays (G10)'","['WORKAROUND OBSERVED: stale displays (G10)'")
p.write_text(s)
