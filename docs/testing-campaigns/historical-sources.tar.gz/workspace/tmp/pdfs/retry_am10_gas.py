import json,time,urllib.request
from pathlib import Path
D=Path('/Users/sg/Documents/ChatGPT/ENS/replacement-readiness/execution/after-migration')
def rpc(method,params):
 r=json.load(urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8545',json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),{'Content-Type':'application/json'})))
 if 'error' in r:raise RuntimeError(r['error'])
 return r['result']
original='0x0cc26cd3d6c82174b47e770f50013026d716a94c67bc89c7f0e60484a81bcbc9'
t=rpc('eth_getTransactionByHash',[original]);request={'from':t['from'],'to':t['to'],'data':t['input'],'value':t['value'],'gas':'0x300000'}
simulation=rpc('eth_call',[request,'latest'])
h=rpc('eth_sendTransaction',[request]);receipt=None
for _ in range(60):
 receipt=rpc('eth_getTransactionReceipt',[h])
 if receipt:break
 time.sleep(.5)
evidence={'originalTransaction':original,'originalGas':t['gas'],'workaround':'Replay same migration call with higher gas limit on local fork','request':request,'simulation':simulation,'retryTransaction':h,'receipt':receipt}
(D/'AM10-gas-retry.json').write_text(json.dumps(evidence,indent=2))
print(json.dumps({'transaction':h,'status':receipt['status'] if receipt else None}))
assert receipt and receipt['status']=='0x1'
