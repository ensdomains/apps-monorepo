import json,html,collections
from pathlib import Path
D=Path('/Users/sg/Documents/ChatGPT/ENS/replacement-readiness/execution/record-preservation')
ind={n['name']:n for n in json.loads((D/'independent-readback.json').read_text())} if (D/'independent-readback.json').exists() else {}
rows=[]
for f in sorted(D.glob('RP[0-9][0-9].json')):
 a=json.loads(f.read_text())
 if not a['names']:rows.append(dict(id=a['id'],name='Fixture not created',scenario=a['title'],result='BLOCKED',details=(a.get('error') or '')[:400],records=[]));continue
 for n in a['names']:
  proof=ind.get(n['name']);after=proof['after'] if proof else n.get('after');before=n['before'];rec=[]
  for b in before:
   aft=next((x for x in after or [] if x['what']==b['what']),None)
   status='NOT VERIFIED' if not aft else 'PASS' if aft['got']==b['got']==b['want'] else 'FAIL'
   rec.append(dict(record=b['what'],before=b['got'],after=aft['got'] if aft else None,result=status))
  migrated=proof['v2Status']==2 if proof else a['migration']=='COMPLETED'
  overall=('PASS' if all(r['result']=='PASS' for r in rec) else 'FAIL') if migrated and after else 'BLOCKED' if a['migration']!='COMPLETED' else 'NOT MIGRATED' if proof and proof['v2Status']!=2 else 'NOT VERIFIED'
  rows.append(dict(id=a['id'],scenario=a['title'],name=n['name'],depth=n['depth'],migration=a['migration'],v2Status=proof['v2Status'] if proof else None,result=overall,resolutionResult=proof.get('resolutionResult') if proof else None,records=rec,beforeBlock=n.get('beforeBlock'),afterBlock=proof['afterBlock'] if proof else n.get('afterBlock'),details=a.get('error'),evidence=f.name))
# Original record-type tests have their own before/after reads. Keep them distinct from tree cases.
groups=collections.defaultdict(list)
if (D/'record-readbacks.jsonl').exists():
 for line in (D/'record-readbacks.jsonl').read_text().splitlines():
  q=json.loads(line);groups[q['name']].append(q)
for name,reads in groups.items():
 b=reads[0];a=reads[-1] if len(reads)>1 else None;rec=[]
 for v in b['records']:
  x=next((r for r in a['records'] if r['what']==v['what']),None) if a else None
  rec.append(dict(record=v['what'],before=v['got'],after=x['got'] if x else None,result='NOT VERIFIED' if x is None else 'PASS' if x['got']==v['got']==v['want'] else 'FAIL'))
 rows.append(dict(id='TYPE',scenario=b['test'],name=name,depth=0,result='NOT VERIFIED' if not a else 'PASS' if all(r['result']=='PASS' for r in rec) else 'FAIL',records=rec,beforeBlock=b['block'],afterBlock=a['block'] if a else None,evidence='record-readbacks.jsonl'))
counts=collections.Counter(r['result'] for r in rows);rr=collections.Counter(x['result'] for r in rows for x in r['records'])
testRuns=[]
def walk(suites,source):
 for suite in suites:
  for spec in suite.get('specs',[]):
   for test in spec.get('tests',[]):
    if source=='extra-records.json' and not spec['title'].startswith('RP10'):continue
    r=(test.get('results') or [{}])[-1];raw=r.get('status','not run')
    testRuns.append(dict(title=spec['title'],result={'passed':'PASS','failed':'FAIL','timedOut':'BLOCKED / TIMEOUT','skipped':'NOT VERIFIED'}.get(raw,raw),expectedStatus=test.get('expectedStatus'),source=source))
  walk(suite.get('suites',[]),source)
for filename in ['audit-tests.json','root-records-corrected.json','grace-records.json','extra-records.json']:
 if (D/filename).exists():walk(json.loads((D/filename).read_text()).get('suites',[]),filename)
for row in rows:
 if row['id']=='TYPE' and not row['records']:
  matched=next((t for t in testRuns if t['title']==row['scenario']),None)
  if matched and matched['result']=='PASS':row['result']='PASS';row['details']='Empty-profile control: no populated records; resolver change and no record-write events verified.'
counts=collections.Counter(r['result'] for r in rows)
expectations={
 'RP04':'Grandchild eligibility not established by earlier checks; observed continuity failure, intended exclusion unverified.',
 'RP06':'Expected exclusion in current implementation: other-wallet descendants are not copied. Equivalent role reconstruction remains a known gap.',
 'RP07':'Known failing copy route in tested checkout (wrapped descendants below unwrapped root, including zero-expiry fixture). Newer-main changes not verified.',
 'RP08':'Earlier checks prove root renewal/migration only. Descendant exclusion reason and intended eligibility unverified.',
 'RP09':'Earlier checks prove root renewal/migration only. Descendant exclusion reason and intended eligibility unverified.'}
for r in rows:
 if r['result'] not in ('FAIL','NOT MIGRATED'):continue
 proof=ind.get(r['name']); total=len(r['records']); matched=sum(v['result']=='PASS' for v in r['records'])
 beforeOk=sum(v['got']==v['want'] for v in proof['before']) if proof else total
 old=proof.get('oldResolverReadback',[]) if proof else []
 oldErrors=sum('error' in v for v in old)
 migrated=r.get('v2Status')==2
 r['failureBreakdown']={
 'Before migration':f'{beforeOk}/{total} seeded records resolved to expected values through the name.',
 'Did this name migrate?':('YES - independent V2 status check confirms migration.' if migrated else 'NO - independent V2 status check does not show a migrated name; ancestor migration completed.') if proof else 'Migration workflow executed; no separate per-name V2 status snapshot retained for this focused test.',
 'After migration':f'{matched}/{total} seeded records still resolve unchanged; {total-matched} fail preservation.',
 'What failed':'; '.join(v['record'] for v in r['records'] if v['result']=='FAIL'),
 'Was the name totally lost?':('NO evidence of total name loss: V2 migration confirmed and other seeded records still resolve.' if migrated and matched else 'All seeded record lookups fail continuity. This does NOT establish permanent name loss, ownership loss or impossibility of recreation.') if proof else ('Some records still resolve; total name loss is not supported.' if matched else 'Both seeded values disappeared from resolution; total name loss is not established by these checks.'),
 'Old resolver data':f'UNVERIFIED - {oldErrors}/{len(old)} saved direct old-resolver reads returned errors. Cannot confirm intact storage or deletion.' if old else 'UNVERIFIED - no independent direct old-resolver readback retained.',
 'Expected exclusion or gap':expectations.get(r['id'],'Migrated-name record-preservation failure.') if not migrated and proof else ('Deliberately incomplete key inventory: confirms data-loss behavior under that input, not real-indexer frequency.' if 'stale' in r['name'] else 'Record-preservation gap; successful migration does not imply every record was copied.'),
 'Recovery / ownership': 'NOT TESTED - recovery, recreation and post-migration ownership/permission continuity were not exercised in this record test.',
 }
summary=dict(testRuns=testRuns,scope='Local fork, fixture inventory, actual app migration and UniversalResolver reads; DNS and legacy stateful suites excluded.',nameResults=dict(counts),recordResults=dict(rr),names=rows)
(D/'results-summary.json').write_text(json.dumps(summary,indent=2))
e=html.escape
parts=['<!doctype html><meta charset="utf-8"><title>Migration record preservation - execution results</title><style>body{font:15px/1.5 system-ui;margin:30px;color:#173d37}table{border-collapse:collapse;width:100%;margin:15px 0}td,th{border:1px solid #cdd;padding:9px;text-align:left;vertical-align:top}th{background:#e4f0eb}pre{white-space:pre-wrap;overflow-wrap:anywhere}details{margin:16px 0}small{color:#566}</style><h1>Migration record preservation - actual execution</h1><p>23 October 2026. '+e(summary['scope'])+'</p><p><b>Real indexer discovery and complete Manager/Explorer display parity are not certified.</b> Inventory keys are supplied by the test, while values and migration transactions are real on the local fork. Source/resolution errors are not automatically proof that old stored data was deleted.</p><p>'+e(str(dict(counts)))+' name outcomes; '+e(str(dict(rr)))+' record comparisons.</p><table><tr><th>Scenario</th><th>Name</th><th>Result</th><th>Record comparison</th></tr>']
for r in rows:
 passed=sum(v['result']=='PASS' for v in r['records']);bad=', '.join(v['record'] for v in r['records'] if v['result']=='FAIL')
 parts.append('<tr><td>'+e(r['id']+' '+r['scenario'])+'</td><td>'+e(r['name'])+'</td><td>'+e(r['result'])+'</td><td>'+str(passed)+'/'+str(len(r['records']))+' match'+('; failed: '+e(bad) if bad else '')+'</td></tr>')
parts.append('</table><h2 id="failure-breakdown">Failed cases: migration, resolution and name survival</h2><p><b>Evidence correction:</b> previous conversational statements that old records were confirmed intact are withdrawn. The saved direct old-resolver reads returned errors. Storage survival and recoverability remain unverified. Resolution failure is not proof of permanent name or ownership loss.</p>')
for i,r in enumerate(rows):
 if 'failureBreakdown' not in r:continue
 parts.append('<section id="failure-'+str(i)+'"><h3>'+e(r['id']+' / '+r['name'])+'</h3><p>'+e(r['scenario'])+'</p><table><tr><th>Question</th><th>Actual result / limit</th></tr>')
 for k,v in r['failureBreakdown'].items():parts.append('<tr><th>'+e(k)+'</th><td>'+e(v)+'</td></tr>')
 parts.append('</table><p><a href="#values-'+str(i)+'">Exact before/after values</a> | <a href="'+e(r['evidence'])+'">Raw test evidence</a> | <a href="independent-readback.json">Independent readback</a></p></section>')
parts.append('<h2>Executed test cases</h2><p>Expected failures are shown as FAIL when their assertions fail, rather than being presented as product passes.</p><table><tr><th>Test</th><th>Actual result</th><th>Evidence</th></tr>')
for t in testRuns:parts.append('<tr><td>'+e(t['title'])+'</td><td>'+e(t['result'])+'</td><td><a href="'+e(t['source'])+'">Raw run</a></td></tr>')
parts.append('</table><h2>Exact values and evidence</h2>')
for i,r in enumerate(rows):
 parts.append('<details id="values-'+str(i)+'"><summary>'+e(r['id']+' '+r['name']+' - '+r['result'])+'</summary><p>Blocks '+e(str(r.get('beforeBlock')))+' to '+e(str(r.get('afterBlock')))+'. <a href="'+e(r.get('evidence','audit-tests.json'))+'">Raw evidence</a></p><table><tr><th>Record</th><th>Before</th><th>After</th><th>Result</th></tr>')
 for v in r['records']:parts.append('<tr>'+''.join('<td><pre>'+e(str(v[k]))+'</pre></td>' for k in ['record','before','after','result'])+'</tr>')
 parts.append('</table></details>')
parts.append('<h2>Remaining coverage</h2><p>DNS and legacy stateful suites were excluded. Real-indexer record discovery, wildcard/off-chain/custom resolver combinations beyond the executed tests, reverse/primary-name continuity and complete records display in both apps remain not verified. A public-key/interface failure makes the all-records result fail even when the other eight records match.</p>')
(D/'Record preservation results.html').write_text(''.join(parts))
print(json.dumps({'names':dict(counts),'records':dict(rr)}))
