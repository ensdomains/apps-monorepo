const ts=require('/Users/sg/ens/ens-app-v3/node_modules/typescript');
const fs=require('fs'),path=require('path');
const roots=['/Users/sg/ens/ens-app-v3/e2e','/Users/sg/ens/apps-monorepo/e2e'];
const out=[];
function scan(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(e.name==='node_modules'||e.name==='playwright-report'||e.name==='test-results')continue;const p=path.join(dir,e.name);if(e.isDirectory())scan(p);else if(e.name.endsWith('.spec.ts'))parse(p);}}
function parse(p){const text=fs.readFileSync(p,'utf8'),sf=ts.createSourceFile(p,text,ts.ScriptTarget.Latest,true);function visit(n){if(ts.isCallExpression(n)&&/^test(?:\.(?:skip|fixme|only|fail))?$/.test(n.expression.getText(sf))&&n.arguments.length>=2){const a=n.arguments[0];if(ts.isStringLiteralLike(a)||ts.isTemplateExpression(a)){out.push({file:p,line:sf.getLineAndCharacterOfPosition(n.getStart(sf)).line+1,end:sf.getLineAndCharacterOfPosition(n.end).line+1,kind:n.expression.getText(sf),title:a.getText(sf),body:n.getText(sf),tags:[...n.getText(sf).matchAll(/@(?:scenario|inv):[\w.-]+/g)].map(x=>x[0])});}}ts.forEachChild(n,visit)}visit(sf);}
roots.forEach(scan);fs.writeFileSync('/Users/sg/Documents/ChatGPT/ENS/evidence/source-tests.json',JSON.stringify(out,null,2));console.log(out.reduce((a,r)=>(a[r.file.includes('ens-app-v3')?'legacy':'new']++,a),{legacy:0,new:0}));
